// ================================================================
// api.js - مدیریت ارتباط با بک‌اند (نسخه امن با CSRF و JWT)
// ================================================================

// ===== 1. تنظیمات پایه =====
const API_CONFIG = {
    // ⚠️ کلیدها از اینجا حذف شدند - درخواست‌ها به بک‌اند پروکسی می‌شوند
    BASE_URL: 'https://api.pulset.io/api',
    WS_BASE: 'wss://api.pulset.io/ws',
};

// ===== 2. توکن CSRF =====
let csrfToken = null;

async function fetchCSRFToken() {
    try {
        const response = await fetch(`${API_CONFIG.BASE_URL}/csrf-token`, {
            credentials: 'include'
        });
        if (!response.ok) throw new Error('Failed to fetch CSRF token');
        const data = await response.json();
        csrfToken = data.token;
        return csrfToken;
    } catch (e) {
        console.warn('CSRF token fetch failed:', e);
        return null;
    }
}

// ===== 3. توکن احراز هویت =====
function getToken() {
    return localStorage.getItem('pulset_token') || '';
}

function setToken(token) {
    localStorage.setItem('pulset_token', token);
}

function getRefreshToken() {
    return localStorage.getItem('pulset_refresh_token') || '';
}

function getLang() {
    return localStorage.getItem('pulset_lang') || 'fa';
}

// ===== 4. درخواست اصلی (با CSRF و JWT) =====
async function apiRequest(endpoint, method = 'GET', data = null, requiresAuth = true) {
    const url = API_CONFIG.BASE_URL + endpoint;
    const headers = {
        'Content-Type': 'application/json',
        'Accept-Language': getLang(),
    };

    // CSRF Token برای درخواست‌های غیر GET
    if (method !== 'GET' && csrfToken) {
        headers['X-CSRF-Token'] = csrfToken;
    }

    // توکن احراز هویت
    if (requiresAuth) {
        const token = getToken();
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }
    }

    const options = {
        method,
        headers,
        credentials: 'include',
    };
    
    if (data) {
        options.body = JSON.stringify(data);
    }

    try {
        const response = await fetch(url, options);

        // اگر توکن منقضی شده، سعی در refresh
        if (response.status === 401 && requiresAuth) {
            const refreshed = await refreshAccessToken();
            if (refreshed) {
                // دوباره امتحان با توکن جدید
                headers['Authorization'] = `Bearer ${getToken()}`;
                const retryResponse = await fetch(url, { ...options, headers });
                if (retryResponse.ok) {
                    return await retryResponse.json();
                }
            }
            // اگر refresh نشد، کاربر را به صفحه ورود ببر
            localStorage.removeItem('pulset_token');
            localStorage.removeItem('pulset_profile');
            window.location.href = 'pulset.html?session_expired=true';
            throw new Error('Session expired');
        }

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || `HTTP ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

// ===== 5. Refresh Token =====
async function refreshAccessToken() {
    try {
        const refreshToken = getRefreshToken();
        if (!refreshToken) return false;
        
        const response = await fetch(`${API_CONFIG.BASE_URL}/auth/refresh`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ refreshToken }),
            credentials: 'include',
        });
        
        if (response.ok) {
            const data = await response.json();
            if (data.token) {
                setToken(data.token);
                if (data.refreshToken) {
                    localStorage.setItem('pulset_refresh_token', data.refreshToken);
                }
                return true;
            }
        }
        return false;
    } catch (e) {
        console.warn('Refresh token failed:', e);
        return false;
    }
}

// ===== 6. سرویس احراز هویت (Auth) =====
const AuthAPI = {
    login: (email, password) => {
        return apiRequest('/auth/login', 'POST', { email, password }, false);
    },
    register: (data) => {
        return apiRequest('/auth/register', 'POST', data, false);
    },
    forgotPassword: (email) => {
        return apiRequest('/auth/forgot-password', 'POST', { email }, false);
    },
    resetPassword: (token, newPassword) => {
        return apiRequest('/auth/reset-password', 'POST', { token, newPassword }, false);
    },
    getMe: () => {
        return apiRequest('/auth/me', 'GET', null, true);
    },
    refreshToken: refreshAccessToken,
    logout: () => {
        localStorage.removeItem('pulset_token');
        localStorage.removeItem('pulset_refresh_token');
        localStorage.removeItem('pulset_profile');
        window.location.href = 'pulset.html';
    }
};

// ===== 7. سرویس پست‌ها (Posts) =====
const PostsAPI = {
    get: (tab = 'for-you', page = 1, limit = 10) =>
        apiRequest(`/posts?tab=${tab}&page=${page}&limit=${limit}`),
    create: (data) => {
        // اگر data شامل فایل باشد، از FormData استفاده می‌کنیم
        if (data instanceof FormData) {
            return fetch(`${API_CONFIG.BASE_URL}/posts`, {
                method: 'POST',
                headers: { 'Authorization': `Bearer ${getToken()}` },
                body: data,
                credentials: 'include',
            }).then(res => {
                if (!res.ok) throw new Error('Upload failed');
                return res.json();
            });
        }
        return apiRequest('/posts', 'POST', data);
    },
    update: (id, data) => apiRequest(`/posts/${id}`, 'PUT', data),
    delete: (id) => apiRequest(`/posts/${id}`, 'DELETE'),
    like: (id) => apiRequest(`/posts/${id}/like`, 'POST'),
    bookmark: (id) => apiRequest(`/posts/${id}/bookmark`, 'POST'),
    repost: (id, type = 'instant') => apiRequest(`/posts/${id}/repost`, 'POST', { type }),
    getComments: (id) => apiRequest(`/posts/${id}/comments`),
    addComment: (id, text) => apiRequest(`/posts/${id}/comments`, 'POST', { text }),
    report: (id, reason) => apiRequest(`/posts/${id}/report`, 'POST', { reason }),
    quote: (parentId, text) => apiRequest('/posts', 'POST', { type: 'quote', parentId, text }),
    getUserPosts: (userId) => apiRequest(`/posts/user/${userId}`),
};

// ===== 8. سرویس سیگنال‌ها (Signals) =====
const SignalsAPI = {
    get: (tab = 'public', page = 1, limit = 10) =>
        apiRequest(`/signals?tab=${tab}&page=${page}&limit=${limit}`),
    createPublic: (data) => apiRequest('/signals', 'POST', data),
    createMarket: (data) => apiRequest('/signals/market', 'POST', data),
    purchase: (id) => apiRequest(`/signals/${id}/purchase`, 'POST'),
    like: (id) => apiRequest(`/signals/${id}/like`, 'POST'),
    bookmark: (id) => apiRequest(`/signals/${id}/bookmark`, 'POST'),
    repost: (id, type = 'instant') => apiRequest(`/signals/${id}/repost`, 'POST', { type }),
    getComments: (id) => apiRequest(`/signals/${id}/comments`),
    addComment: (id, text) => apiRequest(`/signals/${id}/comments`, 'POST', { text }),
    report: (id, reason) => apiRequest(`/signals/${id}/report`, 'POST', { reason }),
    quote: (parentId, text) => apiRequest('/posts', 'POST', { type: 'quote', parentId, text }),
    getUserSignals: (userId) => apiRequest(`/signals/user/${userId}`),
    update: (id, data) => apiRequest(`/signals/${id}`, 'PUT', data),
};

// ===== 9. سرویس هوش مصنوعی (AI) - با پروکسی به بک‌اند =====
const AIAPI = {
    quickSignal: (symbol, name, price) => {
        return apiRequest('/ai/quick-signal', 'POST', { symbol, name, price, lang: getLang() });
    },
    premiumSignal: (symbol, name, price, timeframe) => {
        const level = window.Permissions?.getSignalAccessLevel?.() || 'free';
        return apiRequest('/ai/premium-signal', 'POST', { 
            symbol, name, price, timeframe, 
            lang: getLang(),
            level: level
        });
    },
    chat: (message, model = 'openai') => {
        return apiRequest('/ai/chat', 'POST', { message, model, lang: getLang() });
    },
    analyzeNews: (title, summary) => {
        return apiRequest('/ai/analyze-news', 'POST', { title, summary, lang: getLang() });
    },
    compare: (assets, settings) => {
        return apiRequest('/ai/compare', 'POST', { assets, settings, lang: getLang() });
    }
};

// ===== 10. سرویس بازار (Markets) =====
const MarketsAPI = {
    get: (type = 'all', query = '', page = 1, limit = 20) =>
        apiRequest(`/markets?type=${type}&q=${encodeURIComponent(query)}&page=${page}&limit=${limit}`),
    getBySymbol: (symbol) => apiRequest(`/markets/${encodeURIComponent(symbol)}`),
    getHistory: (symbol, interval = '1d') => apiRequest(`/markets/${encodeURIComponent(symbol)}/history?interval=${interval}`),
};

// ===== 11. سرویس اخبار (News) =====
const NewsAPI = {
    get: (category = 'all', query = '') =>
        apiRequest(`/news?category=${category}&q=${encodeURIComponent(query)}&lang=${getLang()}`),
    analyze: (title, summary) => AIAPI.analyzeNews(title, summary),
    like: (id) => apiRequest(`/news/${id}/like`, 'POST'),
    bookmark: (id) => apiRequest(`/news/${id}/bookmark`, 'POST'),
};

// ===== 12. سرویس چت (Chat) =====
const ChatAPI = {
    getChats: () => apiRequest('/chats'),
    getMessages: (chatId) => apiRequest(`/chats/${chatId}/messages`),
    sendMessage: (chatId, text) => apiRequest(`/chats/${chatId}/messages`, 'POST', { text }),
    createChat: (userId) => apiRequest('/chats', 'POST', { userId }),
};

// ===== 13. سرویس اعلان‌ها (Notifications) =====
const NotificationsAPI = {
    get: () => apiRequest('/notifications'),
    markRead: (id) => apiRequest(`/notifications/${id}/read`, 'POST'),
    markAllRead: () => apiRequest('/notifications/read-all', 'POST'),
    delete: (id) => apiRequest(`/notifications/${id}`, 'DELETE'),
    reply: (id, text) => apiRequest(`/notifications/${id}/reply`, 'POST', { text }),
};

// ===== 14. سرویس کیف پول (Wallet) =====
const WalletAPI = {
    get: () => apiRequest('/wallet'),
    deposit: (amount) => apiRequest('/wallet/deposit', 'POST', { amount }),
    withdraw: (data) => apiRequest('/wallet/withdraw', 'POST', data),
    buyStars: (packageId) => apiRequest('/wallet/buy-stars', 'POST', { packageId }),
    sellStars: (stars) => apiRequest('/wallet/sell-stars', 'POST', { stars }),
    getTransactions: (filter = 'all') => apiRequest(`/wallet/transactions?filter=${filter}`),
};

// ===== 15. سرویس پروفایل (Profile) =====
const ProfileAPI = {
    get: () => apiRequest('/profile'),
    getByUsername: (username) => apiRequest(`/profile/${username}`),
    update: (data) => apiRequest('/profile', 'PUT', data),
    changePassword: (oldPassword, newPassword) =>
        apiRequest('/profile/password', 'PUT', { oldPassword, newPassword }),
    follow: (userId) => apiRequest(`/profile/${userId}/follow`, 'POST'),
    unfollow: (userId) => apiRequest(`/profile/${userId}/unfollow`, 'POST'),
};

// ===== 16. سرویس تنظیمات (Settings) =====
const SettingsAPI = {
    get: () => apiRequest('/settings'),
    update: (data) => apiRequest('/settings', 'PUT', data),
};

// ===== 17. سرویس پشتیبانی (Support) =====
const SupportAPI = {
    getTickets: () => apiRequest('/tickets'),
    createTicket: (data) => apiRequest('/tickets', 'POST', data),
    reply: (id, text) => apiRequest(`/tickets/${id}/reply`, 'POST', { text }),
    getTicket: (id) => apiRequest(`/tickets/${id}`),
};

// ===== 18. سرویس فروشگاه (Shop) =====
const ShopAPI = {
    getProducts: (category = 'all') => apiRequest(`/shop/products?category=${category}`),
    getProduct: (id) => apiRequest(`/shop/products/${id}`),
    getCart: () => apiRequest('/shop/cart'),
    addToCart: (productId, qty = 1) => apiRequest('/shop/cart', 'POST', { productId, qty }),
    updateCart: (items) => apiRequest('/shop/cart', 'PUT', { items }),
    clearCart: () => apiRequest('/shop/cart', 'DELETE'),
    checkout: (data) => apiRequest('/shop/checkout', 'POST', data),
    gift: (productId, recipient) => apiRequest('/shop/gift', 'POST', { productId, recipient }),
    getOrders: () => apiRequest('/shop/orders'),
    getSubscription: () => apiRequest('/shop/subscription'),
    applyPurchase: (productId) => {
        return apiRequest('/shop/purchase', 'POST', { productId });
    }
};

// ===== 19. سرویس مدیریت (Admin) =====
const AdminAPI = {
    login: (username, password) => apiRequest('/admin/login', 'POST', { username, password }, false),
    verify: () => apiRequest('/admin/verify', 'GET', null, true),
    getStats: () => apiRequest('/admin/stats'),
    getUsers: () => apiRequest('/admin/users'),
    blockUser: (id) => apiRequest(`/admin/users/${id}/block`, 'PUT'),
    unblockUser: (id) => apiRequest(`/admin/users/${id}/unblock`, 'PUT'),
    deletePost: (id) => apiRequest(`/admin/posts/${id}`, 'DELETE'),
    announce: (data) => apiRequest('/admin/announce', 'POST', data),
    getShopSettings: () => apiRequest('/admin/shop/settings'),
    updateShopSettings: (data) => apiRequest('/admin/shop/settings', 'PUT', data),
    addProduct: (data) => apiRequest('/admin/shop/products', 'POST', data),
    updateProduct: (id, data) => apiRequest(`/admin/shop/products/${id}`, 'PUT', data),
    deleteProduct: (id) => apiRequest(`/admin/shop/products/${id}`, 'DELETE'),
    getOrders: () => apiRequest('/admin/shop/orders'),
    updateOrderStatus: (id, status) => apiRequest(`/admin/shop/orders/${id}`, 'PUT', { status }),
    addAdmin: (data) => apiRequest('/admin/admins', 'POST', data),
    updateAdmin: (id, data) => apiRequest(`/admin/admins/${id}`, 'PUT', data),
    deleteAdmin: (id) => apiRequest(`/admin/admins/${id}`, 'DELETE'),
    addLog: (data) => apiRequest('/admin/logs', 'POST', data),
};

// ===== 20. WebSocket Manager =====
class WebSocketManager {
    constructor() {
        this.connections = {};
        this.handlers = {};
        this.reconnectTimers = {};
        this.heartbeatIntervals = {};
    }

    connect(namespace, onMessage) {
        const token = getToken();
        if (!token) {
            console.warn('No token, cannot connect WebSocket');
            return null;
        }
        if (this.connections[namespace]) {
            this.connections[namespace].close();
            delete this.connections[namespace];
        }
        const url = `${API_CONFIG.WS_BASE}/${namespace}?token=${token}`;
        const ws = new WebSocket(url);
        
        ws.onopen = () => {
            console.log(`🔌 WebSocket connected to ${namespace}`);
            if (this.reconnectTimers[namespace]) {
                clearTimeout(this.reconnectTimers[namespace]);
                delete this.reconnectTimers[namespace];
            }
            // ارسال heartbeat هر ۳۰ ثانیه
            this.heartbeatIntervals[namespace] = setInterval(() => {
                if (ws.readyState === WebSocket.OPEN) {
                    ws.send(JSON.stringify({ type: 'ping' }));
                }
            }, 30000);
        };
        
        ws.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                // پاسخ به heartbeat
                if (data.type === 'pong') return;
                if (this.handlers[namespace]) {
                    this.handlers[namespace].forEach(handler => handler(data));
                }
                if (onMessage) onMessage(data);
            } catch (e) {
                console.warn('WS parse error:', e);
            }
        };
        
        ws.onerror = (e) => {
            console.warn(`WS error (${namespace}):`, e);
        };
        
        ws.onclose = () => {
            console.warn(`WS closed (${namespace})`);
            delete this.connections[namespace];
            if (this.heartbeatIntervals[namespace]) {
                clearInterval(this.heartbeatIntervals[namespace]);
                delete this.heartbeatIntervals[namespace];
            }
            if (!this.reconnectTimers[namespace]) {
                this.reconnectTimers[namespace] = setTimeout(() => {
                    console.log(`🔄 Reconnecting to ${namespace}...`);
                    this.connect(namespace);
                }, 5000);
            }
        };
        
        this.connections[namespace] = ws;
        return ws;
    }

    subscribe(namespace, handler) {
        if (!this.handlers[namespace]) {
            this.handlers[namespace] = [];
        }
        this.handlers[namespace].push(handler);
        if (!this.connections[namespace]) {
            this.connect(namespace);
        }
        return () => {
            this.handlers[namespace] = this.handlers[namespace].filter(h => h !== handler);
            if (this.handlers[namespace].length === 0) {
                this.disconnect(namespace);
            }
        };
    }

    disconnect(namespace) {
        if (this.connections[namespace]) {
            this.connections[namespace].close();
            delete this.connections[namespace];
        }
        if (this.reconnectTimers[namespace]) {
            clearTimeout(this.reconnectTimers[namespace]);
            delete this.reconnectTimers[namespace];
        }
        if (this.heartbeatIntervals[namespace]) {
            clearInterval(this.heartbeatIntervals[namespace]);
            delete this.heartbeatIntervals[namespace];
        }
        if (this.handlers[namespace]) {
            delete this.handlers[namespace];
        }
    }

    send(namespace, data) {
        const ws = this.connections[namespace];
        if (ws && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify(data));
            return true;
        }
        return false;
    }

    isConnected(namespace) {
        const ws = this.connections[namespace];
        return ws && ws.readyState === WebSocket.OPEN;
    }
}

const WS = new WebSocketManager();

// ===== 21. دریافت CSRF Token در شروع =====
fetchCSRFToken();

// ===== 22. خروجی =====
window.API = {
    Auth: AuthAPI,
    Posts: PostsAPI,
    Signals: SignalsAPI,
    AI: AIAPI,
    Markets: MarketsAPI,
    News: NewsAPI,
    Chat: ChatAPI,
    Notifications: NotificationsAPI,
    Wallet: WalletAPI,
    Profile: ProfileAPI,
    Settings: SettingsAPI,
    Support: SupportAPI,
    Shop: ShopAPI,
    Admin: AdminAPI,
    WS: WS,
    getToken,
    setToken,
    getLang,
    fetchCSRFToken,
};

console.log('✅ API Module loaded successfully (secure version)');
