// ================================================================
// main.js - توابع عمومی (قابل استفاده در همه صفحات)
// ================================================================

// ===== 1. زبان و ترجمه =====
function getCurrentLang() {
    return localStorage.getItem('pulset_lang') || 'fa';
}

function setLang(lang) {
    localStorage.setItem('pulset_lang', lang);
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    // اعمال مجدد ترجمه‌ها (هر صفحه باید این کار را انجام دهد)
    if (window.applyPageTranslations) {
        window.applyPageTranslations();
    }
}

function toggleLang() {
    const current = getCurrentLang();
    const next = current === 'fa' ? 'en' : 'fa';
    setLang(next);
    // به‌روزرسانی دکمه زبان در دراور
    const label = document.getElementById('drawerLangLabel');
    if (label) label.textContent = next === 'fa' ? 'فارسی' : 'English';
    // به‌روزرسانی دکمه بستن دراور
    const closeBtn = document.getElementById('drawerCloseBtn');
    if (closeBtn) {
        closeBtn.innerHTML = next === 'en' ?
            `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none"><polyline points="9 18 15 12 9 6"/></svg>` :
            `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none"><polyline points="15 18 9 12 15 6"/></svg>`;
    }
    // اعمال مجدد ترجمه‌های صفحه
    if (window.applyPageTranslations) {
        window.applyPageTranslations();
    }
    if (window.renderPage) {
        window.renderPage();
    }
}

// ===== 2. تم =====
function getCurrentTheme() {
    const dark = localStorage.getItem('pulset_dark') === 'true';
    return dark ? 'dark' : 'light';
}

function setTheme(theme) {
    const isDark = theme === 'dark';
    document.body.classList.toggle('dark', isDark);
    localStorage.setItem('pulset_dark', String(isDark));
    // به‌روزرسانی برچسب تم در دراور
    const label = document.getElementById('drawerThemeLabel');
    if (label) {
        label.textContent = isDark ? (getCurrentLang() === 'fa' ? 'تاریک' : 'Dark') : (getCurrentLang() === 'fa' ? 'روشن' : 'Light');
    }
    // به‌روزرسانی آیکون تم در هدر
    const themeIcon = document.querySelector('.header-action .theme-icon');
    if (themeIcon) {
        themeIcon.className = isDark ? 'fas fa-sun theme-icon' : 'fas fa-moon theme-icon';
    }
    if (window.renderPage) {
        window.renderPage();
    }
}

function toggleDark() {
    const current = getCurrentTheme();
    const next = current === 'dark' ? 'light' : 'dark';
    setTheme(next);
}

function initTheme() {
    const saved = localStorage.getItem('pulset_dark');
    if (saved !== null) {
        document.body.classList.toggle('dark', saved === 'true');
    } else {
        const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        document.body.classList.toggle('dark', prefersDark);
    }
    // به‌روزرسانی برچسب تم
    const label = document.getElementById('drawerThemeLabel');
    if (label) {
        const isDark = document.body.classList.contains('dark');
        label.textContent = isDark ? (getCurrentLang() === 'fa' ? 'تاریک' : 'Dark') : (getCurrentLang() === 'fa' ? 'روشن' : 'Light');
    }
}

// ===== 3. توست =====
function showToast(msg, duration = 2500) {
    let toast = document.querySelector('.toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.className = 'toast';
        document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(window.toastTimer);
    window.toastTimer = setTimeout(() => {
        toast.classList.remove('show');
    }, duration);
}

// ===== 4. کاربر =====
function getUser() {
    try {
        const s = JSON.parse(localStorage.getItem('pulset_profile') || '{}');
        return {
            name: s.displayName || 'کاربر',
            avatar: s.avatar || '',
            followers: s.followers || '۱.۲K',
            following: s.following || '۳۲۰',
            username: s.username || '@user',
            bio: s.bio || '',
            verified: s.verified || false,
            badges: s.badges || [],
            experience: s.experience || [],
            education: s.education || [],
            links: s.links || {},
            successRate: s.successRate || '--',
            signalCount: s.signalCount || '--',
            location: s.location || 'تهران، ایران',
            privacy: s.privacy || { followers_visible: true }
        };
    } catch (e) {
        return { name: 'کاربر', avatar: '', followers: '۱.۲K', following: '۳۲۰', username: '@user', bio: '', verified: false, badges: [], experience: [], education: [], links: {}, successRate: '--', signalCount: '--', location: 'تهران، ایران', privacy: { followers_visible: true } };
    }
}

function getInitials(name) {
    if (!name) return 'ع';
    const parts = name.trim().split(' ');
    if (parts.length >= 2) return parts[0][0] + parts[1][0];
    return name[0] || 'ع';
}

function formatTime(ts, lang) {
    const d = Math.floor((Date.now() - ts) / 1000);
    const l = lang || getCurrentLang();
    if (l === 'en') {
        if (d < 60) return 'just now';
        if (d < 3600) return Math.floor(d / 60) + 'm ago';
        if (d < 86400) return Math.floor(d / 3600) + 'h ago';
        return new Date(ts).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }
    if (d < 60) return 'لحظاتی پیش';
    if (d < 3600) return Math.floor(d / 60) + ' دقیقه پیش';
    if (d < 86400) return Math.floor(d / 3600) + ' ساعت پیش';
    return new Date(ts).toLocaleDateString('fa-IR');
}

// ===== 5. دراور =====
function toggleDrawer() {
    const o = document.getElementById('drawerOverlay');
    if (!o) return;
    o.classList.toggle('open');
    document.body.style.overflow = o.classList.contains('open') ? 'hidden' : '';
    // به‌روزرسانی اطلاعات کاربر در دراور
    const u = getUser();
    const av = document.querySelector('.drawer-av');
    if (av) {
        if (u.avatar && u.avatar.startsWith('data:image')) {
            av.innerHTML = `<img src="${u.avatar}" alt="${u.name}">`;
        } else {
            av.textContent = getInitials(u.name);
        }
    }
    const un = document.querySelector('.drawer-un');
    if (un) un.textContent = u.name;
    const fol = document.getElementById('drawerFollowers');
    if (fol) fol.textContent = u.followers + ' ' + (getCurrentLang() === 'fa' ? 'دنبال‌کننده' : 'Followers');
    const folw = document.getElementById('drawerFollowing');
    if (folw) folw.textContent = u.following + ' ' + (getCurrentLang() === 'fa' ? 'دنبال‌شونده' : 'Following');
}

function closeDrawer() {
    const o = document.getElementById('drawerOverlay');
    if (o) o.classList.remove('open');
    document.body.style.overflow = '';
}

// ===== 6. ناوبری پایین =====
function goTo(page) {
    const map = {
        dashboard: 'dashboard.html',
        signals_feed: 'signals_feed.html',
        markets: 'markets.html',
        explore: 'explore.html',
        signal: 'signal-request.html',
        wallet: 'wallet.html'
    };
    const url = map[page];
    if (url) window.location.href = url;
}

function initBottomNav() {
    const navs = document.querySelectorAll('.nav');
    const center = document.getElementById('centerBtn');
    const path = window.location.pathname.split('/').pop() || 'dashboard.html';
    const pageMap = {
        dashboard: 'dashboard',
        signals_feed: 'signals_feed',
        markets: 'markets',
        explore: 'explore'
    };
    const currentPage = pageMap[path.split('.')[0]] || 'dashboard';
    navs.forEach(n => {
        n.classList.toggle('active', n.dataset.page === currentPage);
        n.addEventListener('click', function(e) {
            e.preventDefault();
            const p = this.dataset.page;
            if (p) {
                navs.forEach(x => x.classList.remove('active'));
                this.classList.add('active');
                if (center) center.classList.remove('active');
                if (p === 'signal' && center) center.classList.add('active');
                goTo(p);
            }
        });
    });
    if (center) {
        center.addEventListener('click', function(e) {
            e.preventDefault();
            navs.forEach(x => x.classList.remove('active'));
            this.classList.add('active');
            goTo('signal');
        });
    }
}

// ===== 7. مقداردهی اولیه =====
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    const lang = getCurrentLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    // به‌روزرسانی برچسب زبان در دراور
    const label = document.getElementById('drawerLangLabel');
    if (label) label.textContent = lang === 'fa' ? 'فارسی' : 'English';
    // به‌روزرسانی دکمه بستن دراور
    const closeBtn = document.getElementById('drawerCloseBtn');
    if (closeBtn) {
        closeBtn.innerHTML = lang === 'en' ?
            `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none"><polyline points="9 18 15 12 9 6"/></svg>` :
            `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none"><polyline points="15 18 9 12 15 6"/></svg>`;
    }
    initBottomNav();
    console.log('✅ main.js loaded - theme, lang, drawer, bottom nav ready');
});
