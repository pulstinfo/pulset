// ================================================================
// support.js - اسکریپت صفحه پشتیبانی
// ================================================================

// ===== ترجمه =====
const PAGE_TR = {
    fa: {
        pageTitle: 'پشتیبانی',
        statusResolved: 'برطرف شد',
        statusPending: 'در حال بررسی',
        statusOpen: 'باز',
        emptyTickets: 'هیچ تیکتی وجود ندارد.',
        savedToast: '✅ تیکت ارسال شد',
        replyPlaceholder: 'پاسخ خود را بنویسید...',
        sendReply: 'ارسال',
        you: 'شما',
        support: 'پشتیبانی',
        close: 'بستن',
        cancel: 'انصراف',
        save: 'ذخیره'
    },
    en: {
        pageTitle: 'Support',
        statusResolved: 'Resolved',
        statusPending: 'Pending',
        statusOpen: 'Open',
        emptyTickets: 'No tickets yet.',
        savedToast: '✅ Ticket sent',
        replyPlaceholder: 'Write your reply...',
        sendReply: 'Send',
        you: 'You',
        support: 'Support',
        close: 'Close',
        cancel: 'Cancel',
        save: 'Save'
    }
};

// ===== متغیرها =====
let currentTicketId = null;

// ===== اعمال ترجمه =====
function applyPageTranslations() {
    const lang = getCurrentLang();
    const t = PAGE_TR[lang] || PAGE_TR.fa;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key]) el.textContent = t[key];
    });
}
window.applyPageTranslations = applyPageTranslations;

// ===== تابع t محلی =====
function t(key) {
    const lang = getCurrentLang();
    return PAGE_TR[lang]?.[key] || key;
}

// ===== داده‌های نمونه =====
function getSampleTickets() {
    return [{
        id: 1,
        subject: 'مشکل در نمایش نمودار',
        category: 'فنی',
        message: 'نمودار بیت‌کوین در صفحه asset.html به درستی نمایش داده نمی‌شود. خطای ۴۰۴ دریافت می‌کنم.',
        status: 'resolved',
        time: '۱۴۰۴/۰۴/۱۰ ۱۴:۳۰',
        replies: [
            { sender: 'user', text: 'نمودار بیت‌کوین در صفحه asset.html به درستی نمایش داده نمی‌شود. خطای ۴۰۴ دریافت می‌کنم.', time: '۱۴۰۴/۰۴/۱۰ ۱۴:۳۰' },
            { sender: 'support', text: 'سلام. مشکل را بررسی کردیم. به نظر می‌رسد کلید API TradingView منقضی شده باشد. لطفاً کلید را در تنظیمات به‌روز کنید.', time: '۱۴۰۴/۰۴/۱۰ ۱۵:۰۰' },
            { sender: 'user', text: 'ممنون از راهنماییتون. کلید رو عوض کردم و مشکل حل شد.', time: '۱۴۰۴/۰۴/۱۰ ۱۵:۲۰' },
            { sender: 'support', text: 'خوشحالیم که مشکل حل شد. در صورت نیاز مجدداً با ما در ارتباط باشید.', time: '۱۴۰۴/۰۴/۱۰ ۱۵:۴۰' }
        ]
    }, {
        id: 2,
        subject: 'درخواست افزایش اعتبار',
        category: 'مالی',
        message: 'می‌خواهم اعتبار کیف پول خود را افزایش دهم اما درگاه پرداخت خطا می‌دهد.',
        status: 'pending',
        time: '۱۴۰۴/۰۴/۰۸ ۱۰:۱۵',
        replies: [
            { sender: 'user', text: 'می‌خواهم اعتبار کیف پول خود را افزایش دهم اما درگاه پرداخت خطا می‌دهد.', time: '۱۴۰۴/۰۴/۰۸ ۱۰:۱۵' },
            { sender: 'support', text: 'در حال بررسی مشکل درگاه پرداخت هستیم. لطفاً شکیبا باشید.', time: '۱۴۰۴/۰۴/۰۸ ۱۱:۰۰' }
        ]
    }, {
        id: 3,
        subject: 'سیگنال خریداری نشد',
        category: 'پشتیبانی',
        message: 'سیگنال خریداری شده در صفحه signals_feed نمایش داده نمی‌شود.',
        status: 'open',
        time: '۱۴۰۴/۰۴/۰۵ ۰۹:۲۰',
        replies: [
            { sender: 'user', text: 'سیگنال خریداری شده در صفحه signals_feed نمایش داده نمی‌شود.', time: '۱۴۰۴/۰۴/۰۵ ۰۹:۲۰' }
        ]
    }];
}

function getTickets() {
    try {
        const stored = localStorage.getItem('pulset_tickets');
        if (stored) {
            const parsed = JSON.parse(stored);
            if (parsed && parsed.length) return parsed;
        }
    } catch (e) { /* ignore */ }
    const samples = getSampleTickets();
    localStorage.setItem('pulset_tickets', JSON.stringify(samples));
    return samples;
}

function saveTickets(list) {
    localStorage.setItem('pulset_tickets', JSON.stringify(list));
}

// ===== دریافت تیکت‌ها از API =====
async function fetchTicketsFromAPI() {
    try {
        const data = await API.Support.getTickets();
        if (data && data.length) {
            return data.map(t => ({
                id: t.id,
                subject: t.subject || 'بدون موضوع',
                category: t.category || 'عمومی',
                message: t.message || '',
                status: t.status || 'open',
                time: t.time || new Date().toLocaleString('fa-IR'),
                replies: t.replies || []
            }));
        }
        return null;
    } catch (e) {
        console.warn('Fetch tickets error:', e);
        return null;
    }
}

// ===== رندر لیست تیکت‌ها =====
async function renderTickets() {
    let tickets = getTickets();

    // به‌روزرسانی از API
    const apiData = await fetchTicketsFromAPI();
    if (apiData && apiData.length) {
        tickets = apiData;
        localStorage.setItem('pulset_tickets', JSON.stringify(tickets));
    }

    const container = document.getElementById('ticketList');
    if (!tickets.length) {
        container.innerHTML = `
            <div class="ticket-empty">
                <span class="icon"><i class="fas fa-ticket-alt"></i></span>
                ${t('emptyTickets')}
            </div>
        `;
        return;
    }

    const statusMap = { open: 'open', pending: 'pending', resolved: 'resolved' };
    const labelMap = { open: t('statusOpen'), pending: t('statusPending'), resolved: t('statusResolved') };
    const iconMap = { open: 'exclamation-circle', pending: 'clock', resolved: 'check-circle' };

    container.innerHTML = tickets.map(ticket => {
        const hasReply = ticket.replies && ticket.replies.length > 1;
        const statusLabel = labelMap[ticket.status] || ticket.status;
        const icon = iconMap[ticket.status] || 'circle';
        const color = ticket.status === 'open' ? 'var(--error)' : ticket.status === 'pending' ? 'var(--gold)' : 'var(--success)';

        return `
            <div class="ticket-item" onclick="openTicketDetail(${ticket.id})">
                <span class="status ${statusMap[ticket.status] || 'pending'}"></span>
                <div class="info">
                    <div class="subject">${ticket.subject} ${hasReply ? '<span style="font-size:11px;color:var(--success);font-weight:600;">· پاسخ داده شد</span>' : ''}</div>
                    <div class="meta">${ticket.category || ''} · ${ticket.time || ''} · ${statusLabel}</div>
                </div>
                <div class="right"><i class="fas fa-${icon}" style="color:${color};"></i></div>
            </div>
        `;
    }).join('');
}

// ===== شیت جزئیات تیکت =====
async function openTicketDetail(id) {
    currentTicketId = id;
    let tickets = getTickets();
    let ticket = tickets.find(t => t.id === id);

    // اگر از API بیاید و جدیدتر باشد
    try {
        const apiTicket = await API.Support.getTicket(id);
        if (apiTicket) {
            ticket = {
                id: apiTicket.id,
                subject: apiTicket.subject || ticket?.subject || 'بدون موضوع',
                category: apiTicket.category || ticket?.category || 'عمومی',
                message: apiTicket.message || ticket?.message || '',
                status: apiTicket.status || ticket?.status || 'open',
                time: apiTicket.time || ticket?.time || new Date().toLocaleString('fa-IR'),
                replies: apiTicket.replies || ticket?.replies || []
            };
            // به‌روزرسانی در localStorage
            const allTickets = getTickets();
            const idx = allTickets.findIndex(t => t.id === id);
            if (idx !== -1) allTickets[idx] = ticket;
            else allTickets.push(ticket);
            saveTickets(allTickets);
        }
    } catch (e) { /* ignore */ }

    if (!ticket) {
        showToast('تیکت یافت نشد');
        return;
    }

    const overlay = document.getElementById('detailSheetOverlay');
    const content = document.getElementById('detailContent');

    const statusMap = { open: 'باز', pending: 'در حال بررسی', resolved: 'برطرف شد' };
    const statusClass = ticket.status || 'pending';
    const statusLabel = statusMap[statusClass] || 'در حال بررسی';

    let messagesHtml = '';
    if (ticket.replies && ticket.replies.length) {
        messagesHtml = ticket.replies.map(msg => {
            const isUser = msg.sender === 'user';
            const senderLabel = isUser ? t('you') : t('support');
            const avatar = isUser ? 'ش' : 'پ';
            return `
                <div class="ticket-msg ${isUser ? 'user' : 'support'}">
                    <div class="avatar">${avatar}</div>
                    <div class="bubble">
                        ${msg.text}
                        <span class="time">${msg.time || ''}</span>
                    </div>
                </div>
            `;
        }).join('');
    } else {
        messagesHtml = '<div style="text-align:center;padding:20px;color:var(--text3);font-size:13px;">هیچ پیامی وجود ندارد</div>';
    }

    content.innerHTML = `
        <div>
            <span class="ticket-detail-status ${statusClass}">${statusLabel}</span>
            <div class="ticket-detail-meta">
                <span>📌 ${ticket.subject}</span>
                <span>📂 ${ticket.category || 'بدون دسته‌بندی'}</span>
                <span>🕒 ${ticket.time || ''}</span>
            </div>
            <div class="ticket-messages">
                ${messagesHtml}
            </div>
            <div class="ticket-reply-form">
                <textarea id="replyText" placeholder="${t('replyPlaceholder')}" rows="1" oninput="autoResizeReply()"></textarea>
                <button onclick="sendTicketReply(${ticket.id})"><i class="fas fa-paper-plane"></i></button>
            </div>
        </div>
    `;

    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';

    setTimeout(() => {
        const input = document.getElementById('replyText');
        if (input) input.focus();
    }, 300);
}

function closeDetailSheet() {
    document.getElementById('detailSheetOverlay').classList.remove('open');
    document.body.style.overflow = '';
    currentTicketId = null;
}

function autoResizeReply() {
    const el = document.getElementById('replyText');
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 100) + 'px';
}

async function sendTicketReply(id) {
    const input = document.getElementById('replyText');
    if (!input) return;
    const text = input.value.trim();
    if (!text) return;

    const tickets = getTickets();
    const ticket = tickets.find(t => t.id === id);
    if (!ticket) return;

    if (!ticket.replies) ticket.replies = [];
    ticket.replies.push({
        sender: 'user',
        text: text,
        time: new Date().toLocaleString('fa-IR')
    });
    if (ticket.status === 'resolved') ticket.status = 'pending';

    saveTickets(tickets);
    renderTickets();
    openTicketDetail(id);
    showToast('✅ پاسخ شما ارسال شد');

    try {
        await API.Support.reply(id, text);
    } catch (e) {
        console.warn('Reply API error:', e);
    }
}

// ===== تب‌ها =====
function switchTab(tabId, btn) {
    document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
    document.getElementById('tab-' + tabId).classList.add('active');
    if (btn) btn.classList.add('active');
}

// ===== سوالات متداول =====
function toggleFaq(el) {
    el.classList.toggle('open');
    const arrow = el.querySelector('.arrow');
    if (arrow) arrow.classList.toggle('open');
}

// ===== فرم تیکت جدید =====
function updateCharCount() {
    const el = document.getElementById('msgCharCount');
    if (el) el.textContent = document.getElementById('ticketMessage').value.length;
}

function validateTicketForm() {
    const subject = document.getElementById('ticketSubject').value.trim();
    const category = document.getElementById('ticketCategory').value.trim();
    const message = document.getElementById('ticketMessage').value.trim();
    const btn = document.getElementById('submitTicketBtn');

    let valid = true;

    if (!subject) {
        document.getElementById('subjectError').classList.add('show');
        valid = false;
    } else {
        document.getElementById('subjectError').classList.remove('show');
    }

    if (!category) {
        document.getElementById('categoryError').classList.add('show');
        valid = false;
    } else {
        document.getElementById('categoryError').classList.remove('show');
    }

    if (message.length < 10) {
        document.getElementById('messageError').classList.add('show');
        valid = false;
    } else {
        document.getElementById('messageError').classList.remove('show');
    }

    btn.disabled = !valid;
    return valid;
}

async function submitTicket() {
    if (!validateTicketForm()) return;

    const data = {
        id: Date.now(),
        subject: document.getElementById('ticketSubject').value.trim(),
        category: document.getElementById('ticketCategory').value.trim(),
        message: document.getElementById('ticketMessage').value.trim(),
        attachment: document.getElementById('ticketAttachment').files[0]?.name || '',
        time: new Date().toLocaleString('fa-IR'),
        status: 'open',
        replies: [{
            sender: 'user',
            text: document.getElementById('ticketMessage').value.trim(),
            time: new Date().toLocaleString('fa-IR')
        }]
    };

    const tickets = getTickets();
    tickets.unshift(data);
    saveTickets(tickets);

    try {
        await API.Support.createTicket(data);
    } catch (e) {
        console.warn('Create ticket API error:', e);
    }

    // پاک کردن فرم
    document.getElementById('ticketSubject').value = '';
    document.getElementById('ticketCategory').value = '';
    document.getElementById('ticketMessage').value = '';
    document.getElementById('ticketAttachment').value = '';
    document.getElementById('msgCharCount').textContent = '0';
    document.getElementById('submitTicketBtn').disabled = true;

    document.getElementById('successModal').classList.add('show');
    renderTickets();
}

function closeSuccessModal() {
    document.getElementById('successModal').classList.remove('show');
    switchTab('tickets', document.querySelector('[data-tab="tickets"]'));
}

// ===== مقداردهی اولیه =====
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    const lang = getCurrentLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    applyPageTranslations();

    renderTickets();

    // کلید Enter در فرم تیکت جدید
    document.getElementById('ticketMessage').addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && e.ctrlKey) {
            e.preventDefault();
            if (!document.getElementById('submitTicketBtn').disabled) submitTicket();
        }
    });

    console.log('✅ support.js loaded');
});

// ===== خروجی توابع =====
window.switchTab = switchTab;
window.toggleFaq = toggleFaq;
window.validateTicketForm = validateTicketForm;
window.submitTicket = submitTicket;
window.closeSuccessModal = closeSuccessModal;
window.renderTickets = renderTickets;
window.updateCharCount = updateCharCount;
window.openTicketDetail = openTicketDetail;
window.closeDetailSheet = closeDetailSheet;
window.sendTicketReply = sendTicketReply;
window.autoResizeReply = autoResizeReply;
window.showToast = showToast;
