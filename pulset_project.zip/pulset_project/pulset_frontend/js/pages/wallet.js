// ================================================================
// wallet.js - اسکریپت صفحه کیف پول
// ================================================================

// ===== متغیرها =====
let walletData = null;
let allTransactions = [];
let selectedStars = 500;
let selectedPrice = 40000;

// ===== ترجمه صفحه (اختیاری) =====
function applyPageTranslations() {
  const lang = getCurrentLang();
  // در صورت نیاز، ترجمه‌های اختصاصی این صفحه را اضافه کنید
  // (فعلاً از ترجمه‌های عمومی main.js استفاده می‌شود)
}
window.applyPageTranslations = applyPageTranslations;

// ===== توابع کمکی =====
function openModal(id) {
  document.getElementById(id).classList.add('show');
}
function closeModal(id) {
  document.getElementById(id).classList.remove('show');
}

// ===== دریافت داده از API =====
async function fetchWalletData() {
  try {
    const data = await API.Wallet.get();
    if (data) {
      walletData = data;
      localStorage.setItem('pulset_rial_balance', String(data.rial || 0));
      localStorage.setItem('pulset_star_balance', String(data.stars || 0));
      localStorage.setItem('pulset_total_income', String(data.totalIncome || 0));
      localStorage.setItem('pulset_total_expense', String(data.totalExpense || 0));
      localStorage.setItem('pulset_signals_sold', String(data.signalsSold || 0));
      return data;
    }
    return null;
  } catch (e) {
    console.warn('Fetch wallet error, using localStorage:', e);
    return getLocalWalletData();
  }
}

function getLocalWalletData() {
  return {
    rial: parseInt(localStorage.getItem('pulset_rial_balance')) || 2450000,
    stars: parseInt(localStorage.getItem('pulset_star_balance')) || 1240,
    totalIncome: parseInt(localStorage.getItem('pulset_total_income')) || 4200000,
    totalExpense: parseInt(localStorage.getItem('pulset_total_expense')) || 1750000,
    signalsSold: parseInt(localStorage.getItem('pulset_signals_sold')) || 12
  };
}

async function fetchTransactions(filter) {
  try {
    const data = await API.Wallet.getTransactions(filter);
    if (data && data.length) {
      allTransactions = data;
      return data;
    }
    return getSampleTransactions();
  } catch (e) {
    console.warn('Fetch transactions error, using fallback:', e);
    return getSampleTransactions();
  }
}

function getSampleTransactions() {
  return [
    { id: 1, type: 'income', title: 'فروش سیگنال BTC/USDT', desc: 'امروز · ۱۴:۳۰', amount: 450000, date: new Date().toISOString().split('T')[0] },
    { id: 2, type: 'expense', title: 'خرید اشتراک پریمیوم', desc: 'دیروز · ۱۰:۱۵', amount: 200000, date: new Date(Date.now() - 86400000).toISOString().split('T')[0] },
    { id: 3, type: 'star', title: 'خرید ستاره', desc: '۲ روز پیش · ۱۶:۴۵', amount: 500, date: new Date(Date.now() - 172800000).toISOString().split('T')[0] },
    { id: 4, type: 'income', title: 'هدیه دریافت شده', desc: '۳ روز پیش · ۰۹:۲۰', amount: 100000, date: new Date(Date.now() - 259200000).toISOString().split('T')[0] },
    { id: 5, type: 'expense', title: 'خرید سیگنال ETH/USDT', desc: '۵ روز پیش · ۱۱:۰۰', amount: 150000, date: new Date(Date.now() - 432000000).toISOString().split('T')[0] },
    { id: 6, type: 'income', title: 'فروش ستاره', desc: '۱ هفته پیش · ۱۸:۳۰', amount: 350000, date: new Date(Date.now() - 604800000).toISOString().split('T')[0] }
  ];
}

// ===== به‌روزرسانی UI =====
async function updateUI() {
  const data = await fetchWalletData();
  if (data) {
    walletData = data;
  } else {
    walletData = getLocalWalletData();
  }

  document.getElementById('rialBalance').innerHTML = walletData.rial.toLocaleString('fa-IR') +
    ' <span class="currency">تومان</span>';
  document.getElementById('starBalanceShort').textContent = walletData.stars.toLocaleString('fa-IR');
  document.getElementById('starBalanceFull').textContent = walletData.stars.toLocaleString('fa-IR');
  document.getElementById('maxSellableStars').textContent = walletData.stars.toLocaleString('fa-IR');

  document.getElementById('totalIncome').textContent = '+' + walletData.totalIncome.toLocaleString('fa-IR');
  document.getElementById('totalExpense').textContent = '-' + walletData.totalExpense.toLocaleString('fa-IR');
  document.getElementById('signalsSold').textContent = walletData.signalsSold;

  document.getElementById('statIncome').textContent = (walletData.totalIncome / 1000).toFixed(1) + 'M';
  document.getElementById('statExpense').textContent = (walletData.totalExpense / 1000).toFixed(1) + 'M';
  document.getElementById('statSignals').textContent = walletData.signalsSold;

  // تراکنش‌ها
  const txData = await fetchTransactions('all');
  allTransactions = txData;
  renderTransactions('all');
}

function renderTransactions(filter) {
  const container = document.getElementById('txWrapper');
  let filtered = allTransactions;
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  if (filter === 'day') {
    filtered = allTransactions.filter(t => {
      const d = new Date(t.date);
      return d.getFullYear() === today.getFullYear() &&
        d.getMonth() === today.getMonth() &&
        d.getDate() === today.getDate();
    });
  } else if (filter === 'week') {
    const weekAgo = new Date(today);
    weekAgo.setDate(weekAgo.getDate() - 7);
    filtered = allTransactions.filter(t => new Date(t.date) >= weekAgo);
  } else if (filter === 'month') {
    filtered = allTransactions.filter(t => {
      const d = new Date(t.date);
      return d.getMonth() === today.getMonth() &&
        d.getFullYear() === today.getFullYear();
    });
  }

  if (!filtered.length) {
    container.innerHTML = `
      <div style="text-align:center;padding:40px 0;color:var(--text3);font-size:13px;">
        <span style="font-size:40px;display:block;margin-bottom:10px;opacity:0.4;">📭</span>
        هیچ تراکنشی وجود ندارد
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(t => {
    const iconMap = {
      income: { icon: 'fa-arrow-up', cls: 'income', label: '+' },
      expense: { icon: 'fa-arrow-down', cls: 'expense', label: '-' },
      star: { icon: 'fa-star', cls: 'star', label: '+' }
    };
    const ic = iconMap[t.type] || iconMap.income;
    const amountStr = t.type === 'star' ? t.amount + ' ⭐' : ic.label + t.amount.toLocaleString('fa-IR');
    return `
      <div class="tx-item">
        <div class="icon ${ic.cls}"><i class="fas ${ic.icon}"></i></div>
        <div class="info">
          <div class="title">${t.title}</div>
          <div class="desc">${t.desc}</div>
        </div>
        <div class="amount ${ic.cls}">${amountStr}</div>
      </div>
    `;
  }).join('');
}

function saveBalance(rial, stars) {
  localStorage.setItem('pulset_rial_balance', String(rial));
  localStorage.setItem('pulset_star_balance', String(stars));
  updateUI();
}

// ===== نمایش/مخفی کردن جزئیات =====
function toggleBalance() {
  const details = document.getElementById('balanceDetails');
  const icon = document.getElementById('toggleIcon');
  details.classList.toggle('open');
  icon.classList.toggle('open');
}

// ===== افزایش موجودی =====
function openAddFunds() {
  openModal('addFundsModal');
}

async function confirmAddFunds() {
  const amount = parseInt(document.getElementById('addFundsAmount').value.replace(/,/g, ''));
  if (!amount || amount <= 0) {
    showToast('⚠️ لطفاً مبلغ معتبر وارد کنید.');
    return;
  }
  closeModal('addFundsModal');
  showToast('⏳ در حال اتصال به درگاه پرداخت...');

  try {
    const result = await API.Wallet.deposit(amount);
    if (result && result.success) {
      await updateUI();
      showToast('✅ مبلغ ' + amount.toLocaleString('fa-IR') + ' تومان به حساب شما اضافه شد.');
    } else {
      throw new Error('Payment failed');
    }
  } catch (e) {
    // Fallback محلی
    const b = getLocalWalletData();
    b.rial += amount;
    saveBalance(b.rial, b.stars);
    await updateUI();
    showToast('✅ مبلغ ' + amount.toLocaleString('fa-IR') + ' تومان به حساب شما اضافه شد.');
  }
}

// ===== برداشت وجه =====
function openWithdraw() {
  openModal('withdrawModal');
}

async function confirmWithdraw() {
  const sheba = document.getElementById('withdrawSheba').value.trim();
  const name = document.getElementById('withdrawName').value.trim();
  const amount = parseInt(document.getElementById('withdrawAmount').value.replace(/,/g, ''));
  if (!sheba || !sheba.startsWith('IR')) {
    showToast('⚠️ شماره شبا معتبر وارد کنید (با IR شروع شود).');
    return;
  }
  if (!name) {
    showToast('⚠️ نام صاحب حساب را وارد کنید.');
    return;
  }
  if (!amount || amount <= 0) {
    showToast('⚠️ مبلغ معتبر وارد کنید.');
    return;
  }

  const b = getLocalWalletData();
  if (amount > b.rial) {
    showToast('⚠️ موجودی کافی نیست.');
    return;
  }

  closeModal('withdrawModal');
  showToast('⏳ در حال ثبت درخواست برداشت...');

  try {
    const result = await API.Wallet.withdraw({ sheba, name, amount });
    if (result && result.success) {
      await updateUI();
      showToast('✅ درخواست برداشت شما ثبت شد و تا ۲۴ ساعت کاری پردازش می‌شود.');
    } else {
      throw new Error('Withdraw failed');
    }
  } catch (e) {
    b.rial -= amount;
    saveBalance(b.rial, b.stars);
    await updateUI();
    showToast('✅ درخواست برداشت شما ثبت شد و تا ۲۴ ساعت کاری پردازش می‌شود.');
  }
}

// ===== خرید ستاره =====
function selectStarPackage(el) {
  document.querySelectorAll('.star-package').forEach(p => p.classList.remove('selected'));
  el.classList.add('selected');
  selectedStars = parseInt(el.dataset.stars);
  selectedPrice = parseInt(el.dataset.price);
}

function openBuyStars() {
  openModal('buyStarsModal');
  const defaultPackage = document.querySelector('.star-package.selected');
  if (!defaultPackage) {
    const first = document.querySelector('.star-package');
    if (first) selectStarPackage(first);
  }
}

async function confirmBuyStars() {
  const b = getLocalWalletData();
  if (selectedPrice > b.rial) {
    showToast('⚠️ موجودی کافی نیست. لطفاً ابتدا افزایش موجودی دهید.');
    return;
  }
  closeModal('buyStarsModal');
  showToast('⏳ در حال خرید ستاره...');

  try {
    const result = await API.Wallet.buyStars(selectedStars);
    if (result && result.success) {
      await updateUI();
      showToast('✅ خرید ' + selectedStars + ' ستاره با موفقیت انجام شد.');
    } else {
      throw new Error('Buy stars failed');
    }
  } catch (e) {
    b.rial -= selectedPrice;
    b.stars += selectedStars;
    saveBalance(b.rial, b.stars);
    await updateUI();
    showToast('✅ خرید ' + selectedStars + ' ستاره با موفقیت انجام شد.');
  }
}

// ===== فروش ستاره =====
function openSellStars() {
  openModal('sellStarsModal');
}

async function confirmSellStars() {
  const input = document.getElementById('sellStarsInput');
  const stars = parseInt(input.value);
  if (!stars || stars <= 0) {
    showToast('⚠️ تعداد ستاره معتبر وارد کنید.');
    return;
  }
  const b = getLocalWalletData();
  if (stars > b.stars) {
    showToast('⚠️ تعداد ستاره بیشتر از موجودی شماست.');
    return;
  }
  const price = stars * 70;
  closeModal('sellStarsModal');
  showToast('⏳ در حال فروش ستاره...');

  try {
    const result = await API.Wallet.sellStars(stars);
    if (result && result.success) {
      await updateUI();
      showToast('✅ فروش ' + stars + ' ستاره با موفقیت انجام شد. مبلغ به کیف پول شما اضافه شد.');
    } else {
      throw new Error('Sell stars failed');
    }
  } catch (e) {
    b.stars -= stars;
    b.rial += price;
    saveBalance(b.rial, b.stars);
    await updateUI();
    showToast('✅ فروش ' + stars + ' ستاره با موفقیت انجام شد. مبلغ به کیف پول شما اضافه شد.');
  }
}

// ===== فروشگاه و صرافی =====
function openShop() {
  showToast('🛒 به فروشگاه هدایت می‌شوید...');
  setTimeout(() => { window.location.href = 'shop.html'; }, 800);
}

function goToExchange(name) {
  const map = {
    binance: 'https://www.binance.com',
    coinx: 'https://www.coinx.com',
    nobitex: 'https://nobitex.ir',
    bingx: 'https://bingx.com',
    okx: 'https://www.okx.com'
  };
  const url = map[name] || '#';
  showToast('🎁 ثبت‌نام در ' + name + ' - پاداش شما تعلق می‌گیرد.');
  setTimeout(() => { window.open(url, '_blank'); }, 800);
}

// ===== فیلتر تراکنش‌ها =====
function filterTx(filter, btn) {
  document.querySelectorAll('.filter-tabs .tab').forEach(t => t.classList.remove('active'));
  if (btn) btn.classList.add('active');
  renderTransactions(filter);
}

// ===== مقداردهی اولیه =====
document.addEventListener('DOMContentLoaded', function() {
  initTheme();
  applyPageTranslations();
  updateUI();
  console.log('✅ wallet.js loaded');
});

// ===== خروجی توابع =====
window.toggleBalance = toggleBalance;
window.openAddFunds = openAddFunds;
window.confirmAddFunds = confirmAddFunds;
window.openWithdraw = openWithdraw;
window.confirmWithdraw = confirmWithdraw;
window.openBuyStars = openBuyStars;
window.confirmBuyStars = confirmBuyStars;
window.selectStarPackage = selectStarPackage;
window.openSellStars = openSellStars;
window.confirmSellStars = confirmSellStars;
window.openModal = openModal;
window.closeModal = closeModal;
window.openShop = openShop;
window.goToExchange = goToExchange;
window.filterTx = filterTx;
window.toggleDrawer = toggleDrawer;
window.closeDrawer = closeDrawer;
window.showToast = showToast;
window.updateUI = updateUI;
