// ================================================================
// blocked.js - اسکریپت صفحه بلاک‌لیست
// ================================================================

// ===== ترجمه =====
const PAGE_TR = {
    fa: {
        pageTitle: 'بلاک‌لیست',
        emptyTitle: 'هیچ کاربری بلاک نشده',
        emptyDesc: 'با بلاک کردن کاربران، آن‌ها نمی‌توانند به شما پیام دهند یا پست‌هایتان را ببینند.',
        unblock: 'آنبلاک',
        unblocked: '✅ کاربر آنبلاک شد'
    },
    en: {
        pageTitle: 'Blocked List',
        emptyTitle: 'No users blocked',
        emptyDesc: 'Blocked users cannot message you or see your posts.',
        unblock: 'Unblock',
        unblocked: '✅ User unblocked'
    }
};

// ===== اعمال ترجمه =====
function applyPageTranslations() {
    const lang = getCurrentLang();
    const t = PAGE_TR[lang] || PAGE_TR.fa;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key]) el.textContent = t[key];
    });
}
window.applyPageTranslations = applyPageTranslations;

// ===== تابع t محلی =====
function t(key) {
    const lang = getCurrentLang();
    return PAGE_TR[lang]?.[key] || key;
}

// ===== داده‌های نمونه =====
const sampleBlocked = [
    { id: 'u1', name: 'کاربر مزاحم', handle: '@spammer1', avatar: 'م' },
    { id: 'u2', name: 'فروشنده پیامکی', handle: '@seller_bot', avatar: 'ف' },
];

// ===== دریافت لیست =====
function getBlocked() {
    try {
        const b = localStorage.getItem('pulset_blocked');
        if (b) return JSON.parse(b);
    } catch (e) { /* ignore */ }
    return sampleBlocked;
}

function saveBlocked(list) {
    localStorage.setItem('pulset_blocked', JSON.stringify(list));
}

// ===== آنبلاک =====
function unblockUser(id) {
    const list = getBlocked().filter(function(u) { return u.id !== id; });
    saveBlocked(list);
    renderBlocked();
    showToast(t('unblocked'));
}

// ===== رندر =====
function renderBlocked() {
    const list = getBlocked();
    const container = document.getElementById('blockedList');
    if (!list.length) {
        container.innerHTML = `
            <div class="empty-state">
                <span class="icon"><i class="fas fa-ban"></i></span>
                <div class="title">${t('emptyTitle')}</div>
                <div class="desc">${t('emptyDesc')}</div>
            </div>
        `;
        return;
    }
    container.innerHTML = list.map(function(u) {
        return `
            <div class="list-item">
                <div class="avatar">${u.avatar || '?'}</div>
                <div class="info">
                    <div class="name">${u.name}</div>
                    <div class="handle">${u.handle}</div>
                </div>
                <button class="unblock-btn" onclick="unblockUser('${u.id}')">${t('unblock')}</button>
            </div>
        `;
    }).join('');
}

// ===== مقداردهی اولیه =====
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    const lang = getCurrentLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    applyPageTranslations();

    renderBlocked();
    console.log('✅ blocked.js loaded');
});

// ===== خروجی توابع =====
window.unblockUser = unblockUser;
window.renderBlocked = renderBlocked;
window.showToast = showToast;
window.toggleDark = toggleDark;
window.toggleLang = toggleLang;