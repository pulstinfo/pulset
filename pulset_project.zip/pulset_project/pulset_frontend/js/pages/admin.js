// ================================================================
// admin.js - اسکریپت پنل مدیریت
// ================================================================

// ===== ترجمه =====
const PAGE_TR = {
    fa: {
        admin_login_sub: 'پنل مدیریت Pulset',
        admin_username: 'نام کاربری',
        admin_password: 'رمز عبور',
        admin_login_btn: 'ورود به پنل'
    },
    en: {
        admin_login_sub: 'Pulset Admin Panel',
        admin_username: 'Username',
        admin_password: 'Password',
        admin_login_btn: 'Login'
    }
};

// ===== متغیرها =====
const ADMIN_CONFIG = {
    loginAttempts: 0,
    maxLoginAttempts: 5,
    lockedUntil: null,
    sessionTimeout: 30 * 60 * 1000,
    masterUsername: 'admin',
    masterPassword: 'pulset2024'
};

let users = [];
let admins = [];
let products = [];
let orders = [];
let tickets = [];
let logs = [];
let currentSection = 'dashboard';
let currentUserFilter = 'all';
let isAdminLoggedIn = false;
let sessionTimer = null;
let currentAdmin = null;

// ===== اعمال ترجمه =====
function applyPageTranslations() {
    const lang = getCurrentLang();
    const t = PAGE_TR[lang] || PAGE_TR.fa;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key]) el.textContent = t[key];
    });
}
window.applyPageTranslations = applyPageTranslations;

// ===== تابع t محلی =====
function t(key) {
    const lang = getCurrentLang();
    return PAGE_TR[lang]?.[key] || key;
}

// ===== احراز هویت =====
function checkAdminAuth() {
    const auth = localStorage.getItem('pulset_admin_auth');
    if (auth) {
        try {
            const data = JSON.parse(auth);
            if (data.expires && data.expires > Date.now()) {
                isAdminLoggedIn = true;
                currentAdmin = data;
                return true;
            }
        } catch (e) { /* ignore */ }
    }
    return false;
}

function setAdminAuth(username, name, role) {
    const data = {
        username: username,
        name: name || 'ادمین',
        role: role || 'admin',
        expires: Date.now() + ADMIN_CONFIG.sessionTimeout,
        loginTime: Date.now()
    };
    localStorage.setItem('pulset_admin_auth', JSON.stringify(data));
    isAdminLoggedIn = true;
    currentAdmin = data;
    startSessionTimer();
    updateHeaderInfo();
}

function startSessionTimer() {
    if (sessionTimer) clearInterval(sessionTimer);
    sessionTimer = setInterval(function() {
        const auth = localStorage.getItem('pulset_admin_auth');
        if (auth) {
            try {
                const data = JSON.parse(auth);
                if (data.expires && data.expires < Date.now()) {
                    logout('⏰ زمان جلسه به پایان رسید');
                }
            } catch (e) { /* ignore */ }
        }
    }, 60000);
}

function updateHeaderInfo() {
    if (currentAdmin) {
        document.getElementById('adminName').textContent = currentAdmin.name || 'ادمین';
        document.getElementById('adminAvatar').textContent = (currentAdmin.name || 'ا').charAt(0);
        document.getElementById('adminRole').innerHTML = (currentAdmin.role === 'super' ? 'سوپر ادمین' : 'ادمین') +
            ' <span class="badge-admin">●</span>';
        document.getElementById('adminRoleBadge').textContent = currentAdmin.role === 'super' ? 'سوپر' : 'ادمین';
        document.querySelector('.status-dot').className = 'status-dot online';
    }
}

function showLogin() {
    document.getElementById('loginOverlay').classList.add('show');
    document.getElementById('loginUsername').value = '';
    document.getElementById('loginPassword').value = '';
    document.getElementById('loginError').classList.remove('show');
    document.getElementById('loginBtn').disabled = false;
    document.getElementById('loginUsername').focus();
}

function hideLogin() {
    document.getElementById('loginOverlay').classList.remove('show');
}

function adminLogin() {
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value.trim();
    const error = document.getElementById('loginError');
    const btn = document.getElementById('loginBtn');

    if (ADMIN_CONFIG.lockedUntil && ADMIN_CONFIG.lockedUntil > Date.now()) {
        const remaining = Math.ceil((ADMIN_CONFIG.lockedUntil - Date.now()) / 1000);
        error.textContent = '⚠️ بیش از حد تلاش ناموفق. ' + remaining + ' ثانیه صبر کنید.';
        error.classList.add('show');
        return;
    }

    if (!username || !password) {
        error.textContent = '❌ لطفاً نام کاربری و رمز عبور را وارد کنید';
        error.classList.add('show');
        return;
    }

    btn.disabled = true;
    error.classList.remove('show');

    // بررسی مدیر اصلی
    if (username === ADMIN_CONFIG.masterUsername && password === ADMIN_CONFIG.masterPassword) {
        ADMIN_CONFIG.loginAttempts = 0;
        setAdminAuth(username, 'علی معامله‌گر', 'super');
        hideLogin();
        loadData();
        showToast('✅ ورود موفق، خوش آمدید', 'success');
        addLog('ورود به پنل مدیریت (سوپر ادمین)');
        return;
    }

    // بررسی ادمین‌های دیگر
    const adminUser = admins.find(function(a) { return a.username === username && a.password === password; });
    if (adminUser) {
        ADMIN_CONFIG.loginAttempts = 0;
        setAdminAuth(username, adminUser.name, adminUser.role || 'admin');
        hideLogin();
        loadData();
        showToast('✅ ورود موفق، خوش آمدید ' + adminUser.name, 'success');
        addLog('ورود ادمین ' + adminUser.name);
        return;
    }

    ADMIN_CONFIG.loginAttempts++;
    if (ADMIN_CONFIG.loginAttempts >= ADMIN_CONFIG.maxLoginAttempts) {
        ADMIN_CONFIG.lockedUntil = Date.now() + 300000;
        error.textContent = '⚠️ بیش از حد تلاش ناموفق. ۵ دقیقه صبر کنید.';
        error.classList.add('show');
        btn.disabled = false;
        return;
    }

    error.textContent = '❌ نام کاربری یا رمز عبور اشتباه است';
    error.classList.add('show');
    btn.disabled = false;
}

function logout(msg) {
    localStorage.removeItem('pulset_admin_auth');
    isAdminLoggedIn = false;
    currentAdmin = null;
    if (sessionTimer) clearInterval(sessionTimer);
    showToast(msg || '✅ خروج از پنل', 'success');
    setTimeout(function() {
        showLogin();
        document.querySelector('.status-dot').className = 'status-dot offline';
    }, 500);
}

// ===== بارگذاری داده‌ها =====
function getDefaultUsers() {
    return [
        { id: 'u1', name: 'علی معامله‌گر', username: '@ali_trades', avatar: 'ع', level: 'pro', email: 'ali@example.com',
            registered: '۱۴۰۴/۰۱/۰۱', blocked: false },
        { id: 'u2', name: 'مریم تریدر', username: '@mary_crypto', avatar: 'م', level: 'premium',
            email: 'mary@example.com', registered: '۱۴۰۴/۰۱/۱۵', blocked: false },
        { id: 'u3', name: 'حسین تحلیلگر', username: '@hossein_fx', avatar: 'ح', level: 'free',
            email: 'hossein@example.com', registered: '۱۴۰۴/۰۲/۰۱', blocked: false },
        { id: 'u4', name: 'سارا اسکالپر', username: '@sara_scalp', avatar: 'س', level: 'premium',
            email: 'sara@example.com', registered: '۱۴۰۴/۰۲/۱۰', blocked: true }
    ];
}

function getDefaultAdmins() {
    return [
        { id: 'a1', name: 'مدیر فروش', username: 'shop_admin', password: 'shop123456', role: 'admin',
            permissions: ['users', 'shop', 'tickets'] },
        { id: 'a2', name: 'مدیر محتوا', username: 'content_admin', password: 'content123', role: 'admin',
            permissions: ['content', 'tickets'] }
    ];
}

function getDefaultProducts() {
    return [
        { id: 'edu_basic', name: 'بسته آموزشی مقدماتی', icon: '📚', category: 'education', price: 250000,
            starsPrice: 150, desc: 'آموزش کامل تحلیل تکنیکال', discount: 0 },
        { id: 'ai_premium', name: 'هوش مصنوعی پلاس', icon: '🧠', category: 'ai', price: 500000, starsPrice: 300,
            desc: 'تحلیل پیشرفته', discount: 0 },
        { id: 'sub_monthly', name: 'اشتراک ماهانه', icon: '📅', category: 'subscription', price: 300000,
            starsPrice: 180, desc: 'دسترسی کامل به مدت یک ماه', discount: 0 }
    ];
}

function getDefaultOrders() {
    return [
        { id: 'o1', user: 'علی معامله‌گر', product: 'اشتراک ماهانه', amount: 300000, status: 'completed',
            date: '۱۴۰۴/۰۲/۱۵' },
        { id: 'o2', user: 'مریم تریدر', product: 'هوش مصنوعی پلاس', amount: 500000, status: 'pending',
            date: '۱۴۰۴/۰۲/۱۴' }
    ];
}

function getDefaultTickets() {
    return [
        { id: 1, user: 'علی معامله‌گر', subject: 'مشکل در نمایش نمودار', status: 'resolved',
            time: '۱۴۰۴/۰۲/۱۰ ۱۴:۳۰',
            messages: [{ sender: 'user', text: 'نمودار نمایش داده نمی‌شود', time: '۱۴۰۴/۰۲/۱۰ ۱۴:۳0' },
            { sender: 'support', text: 'مشکل برطرف شد', time: '۱۴۰۴/۰۲/۱۰ ۱۵:۰۰' }] },
        { id: 2, user: 'مریم تریدر', subject: 'درخواست افزایش اعتبار', status: 'pending', time: '۱۴۰۴/۰۲/۰۸ ۱۰:۱۵',
            messages: [{ sender: 'user', text: 'می‌خواهم اعتبار افزایش دهم', time: '۱۴۰۴/۰۲/۰۸ ۱۰:۱۵' }] }
    ];
}

function getDefaultLogs() {
    return [
        { action: 'ورود به پنل', admin: 'علی معامله‌گر', time: getTime(), type: 'admin' },
        { action: 'تغییر قیمت محصول "اشتراک ماهانه"', admin: 'علی معامله‌گر', time: getTime(), type: 'shop' },
        { action: 'بلاک کاربر "سارا اسکالپر"', admin: 'علی معامله‌گر', time: getTime(), type: 'user' }
    ];
}

function loadData() {
    try {
        const u = localStorage.getItem('pulset_admin_users');
        users = u ? JSON.parse(u) : getDefaultUsers();
        const a = localStorage.getItem('pulset_admin_admins');
        admins = a ? JSON.parse(a) : getDefaultAdmins();
        const p = localStorage.getItem('pulset_admin_products');
        products = p ? JSON.parse(p) : getDefaultProducts();
        const o = localStorage.getItem('pulset_admin_orders');
        orders = o ? JSON.parse(o) : getDefaultOrders();
        const t = localStorage.getItem('pulset_admin_tickets');
        tickets = t ? JSON.parse(t) : getDefaultTickets();
        const l = localStorage.getItem('pulset_admin_logs');
        logs = l ? JSON.parse(l) : getDefaultLogs();
    } catch (e) {
        users = getDefaultUsers();
        admins = getDefaultAdmins();
        products = getDefaultProducts();
        orders = getDefaultOrders();
        tickets = getDefaultTickets();
        logs = getDefaultLogs();
    }
    renderAll();
}

function saveUsers() { localStorage.setItem('pulset_admin_users', JSON.stringify(users)); }
function saveAdmins() { localStorage.setItem('pulset_admin_admins', JSON.stringify(admins)); }
function saveProducts() { localStorage.setItem('pulset_admin_products', JSON.stringify(products)); }
function saveOrders() { localStorage.setItem('pulset_admin_orders', JSON.stringify(orders)); }
function saveTickets() { localStorage.setItem('pulset_admin_tickets', JSON.stringify(tickets)); }
function saveLogs() { localStorage.setItem('pulset_admin_logs', JSON.stringify(logs)); }

function addLog(action, type) {
    const username = currentAdmin?.name || 'سیستم';
    logs.unshift({ action: action, admin: username, time: getTime(), type: type || 'system' });
    if (logs.length > 500) logs.pop();
    saveLogs();
    renderLogs();
}

function getTime() { return new Date().toLocaleString('fa-IR'); }

// ===== رندرها =====
function renderAll() {
    renderStats();
    renderUsers();
    renderAdmins();
    renderProductsList();
    renderOrdersList();
    renderTickets();
    renderLogs();
    updateBadges();
    loadPermissionSettings();
    loadAISettings();
    loadFinancialSettings();
    loadSiteSettings();
    document.getElementById('dashboardTime').textContent = getTime();
}

function renderStats() {
    document.getElementById('statUsers').textContent = users.length;
    document.getElementById('statSignals').textContent = Math.floor(Math.random() * 20 + 5);
    document.getElementById('statPosts').textContent = Math.floor(Math.random() * 50 + 10);
    const revenue = orders.filter(function(o) { return o.status === 'completed'; }).reduce(function(sum, o) { return sum +
            o.amount; }, 0);
    document.getElementById('statRevenue').textContent = revenue.toLocaleString('fa-IR');
    document.getElementById('statOnline').textContent = Math.floor(Math.random() * 30 + 5);
    document.getElementById('statPremium').textContent = users.filter(function(u) { return u.level === 'premium' ||
            u.level === 'pro'; }).length;
    document.getElementById('lastUpdate').textContent = getTime();
}

function renderUsers() {
    const container = document.getElementById('usersList');
    const search = document.getElementById('userSearch').value.trim().toLowerCase();
    const filter = document.getElementById('userFilter').value;
    const filtered = users.filter(function(u) {
        const matchSearch = u.name.includes(search) || u.username.includes(search) || (u.email || '').includes(
        search);
        if (filter === 'blocked') return u.blocked;
        const matchFilter = filter === 'all' || u.level === filter;
        return matchSearch && matchFilter && !u.blocked;
    });
    document.getElementById('usersCount').textContent = filtered.length + ' کاربر';

    if (!filtered.length) {
        container.innerHTML = '<div class="empty-state"><span class="icon"><i class="fas fa-users"></i></span>هیچ کاربری یافت نشد</div>';
        return;
    }

    const levelMap = { free: 'رایگان', premium: 'پریمیوم', pro: 'پرو' };
    container.innerHTML = filtered.map(function(u) {
        const levelTag = '<span class="tag ' + u.level + '">' + levelMap[u.level] + '</span>';
        return `
            <div class="list-item-admin">
                <div class="avatar">${u.avatar || 'ع'}</div>
                <div class="info">
                    <div class="name">${u.name}</div>
                    <div class="sub">${u.username} · ${u.email || ''} · ${levelTag}</div>
                    <div class="sub" style="font-size:10px;color:var(--text3);">عضو از ${u.registered || '--'}</div>
                </div>
                <div class="actions">
                    <button class="gold" onclick="changeUserLevel('${u.id}')">سطح</button>
                    <button class="${u.blocked ? 'success' : 'danger'}" onclick="toggleBlockUser('${u.id}')">${u.blocked ? 'آنبلاک' : 'بلاک'}</button>
                </div>
            </div>
        `;
    }).join('');
}

function renderAdmins() {
    const container = document.getElementById('adminsList');
    document.getElementById('adminsCount').textContent = admins.length + ' ادمین';
    if (!admins.length) {
        container.innerHTML = '<div class="empty-state"><span class="icon"><i class="fas fa-user-shield"></i></span>هیچ ادمینی ثبت نشده</div>';
        return;
    }
    const permMap = {
        users: 'کاربران',
        admins: 'ادمین‌ها',
        shop: 'فروشگاه',
        permissions: 'دسترسی‌ها',
        ai: 'هوش مصنوعی',
        content: 'محتوا',
        tickets: 'تیکت‌ها',
        financial: 'مالی',
        settings: 'تنظیمات',
        logs: 'لاگ'
    };
    container.innerHTML = admins.map(function(a) {
        const perms = (a.permissions || []).map(function(p) { return permMap[p] || p; }).join('، ');
        const roleTag = a.role === 'super' ? '<span class="tag super">سوپر</span>' :
            '<span class="tag admin">ادمین</span>';
        return `
            <div class="list-item-admin">
                <div class="avatar">${a.avatar || 'ا'}</div>
                <div class="info">
                    <div class="name">${a.name} ${roleTag}</div>
                    <div class="sub">@${a.username} · دسترسی: ${perms || 'همه'}</div>
                </div>
                <div class="actions">
                    ${currentAdmin?.role === 'super' ? `<button class="gold" onclick="editAdmin('${a.id}')">ویرایش</button><button class="danger" onclick="deleteAdmin('${a.id}')">حذف</button>` : ''}
                </div>
            </div>
        `;
    }).join('');
}

function renderProductsList() {
    const container = document.getElementById('productsList');
    document.getElementById('shopCount').textContent = products.length + ' محصول';
    if (!products.length) {
        container.innerHTML = '<div class="empty-state"><span class="icon"><i class="fas fa-box"></i></span>هیچ محصولی وجود ندارد</div>';
        return;
    }
    container.innerHTML = products.map(function(p) {
        return `
            <div class="list-item-admin">
                <div style="font-size:24px;">${p.icon || '📦'}</div>
                <div class="info">
                    <div class="name">${p.name}</div>
                    <div class="sub">${p.desc || ''} · ${p.price.toLocaleString('fa-IR')} تومان · ${p.starsPrice} ستاره</div>
                    <div class="sub" style="font-size:10px;color:var(--text3);">دسته: ${p.category} ${p.discount > 0 ? '· تخفیف ' + p.discount + '%' : ''}</div>
                </div>
                <div class="actions">
                    <button class="gold" onclick="editProduct('${p.id}')">ویرایش</button>
                    <button class="danger" onclick="deleteProduct('${p.id}')">حذف</button>
                </div>
            </div>
        `;
    }).join('');
}

function renderOrdersList() {
    const container = document.getElementById('ordersList');
    if (!orders.length) {
        container.innerHTML =
            '<div class="empty-state" style="padding:12px 0;"><span class="icon" style="font-size:24px;"><i class="fas fa-shopping-bag"></i></span>هیچ سفارشی وجود ندارد</div>';
        return;
    }
    const statusMap = { pending: 'در انتظار', completed: 'تکمیل‌شده', cancelled: 'لغو‌شده' };
    container.innerHTML = orders.slice(0, 5).map(function(o) {
        return `
            <div class="list-item-admin" style="padding:6px 10px;">
                <div class="info" style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;">
                    <span style="font-weight:500;">${o.product}</span>
                    <span style="color:var(--text3);font-size:11px;">${o.user}</span>
                    <span style="font-size:11px;font-weight:600;color:var(--gold);">${o.amount.toLocaleString('fa-IR')} تومان</span>
                    <span style="font-size:10px;padding:0 8px;border-radius:10px;background:${o.status === 'completed' ? 'var(--success-bg)' : 'var(--gold-bg)'};color:${o.status === 'completed' ? 'var(--success)' : 'var(--gold-dark)'};">${statusMap[o.status] || o.status}</span>
                </div>
                <div class="actions">
                    <button class="${o.status === 'completed' ? 'success' : 'gold'}" onclick="updateOrderStatus('${o.id}')">${o.status === 'completed' ? '✓' : 'تکمیل'}</button>
                </div>
            </div>
        `;
    }).join('');
}

function renderTickets() {
    const container = document.getElementById('ticketsList');
    document.getElementById('ticketsCount').textContent = tickets.length + ' تیکت';
    if (!tickets.length) {
        container.innerHTML = '<div class="empty-state"><span class="icon"><i class="fas fa-ticket-alt"></i></span>هیچ تیکتی وجود ندارد</div>';
        return;
    }
    const statusMap = { open: 'باز', pending: 'در حال بررسی', resolved: 'برطرف شد' };
    container.innerHTML = tickets.map(function(t) {
        const hasReply = t.messages && t.messages.length > 1;
        return `
            <div class="list-item-admin" onclick="openTicketDetail(${t.id})" style="cursor:pointer;">
                <div style="width:8px;height:8px;border-radius:50%;background:${t.status === 'resolved' ? 'var(--success)' : t.status === 'pending' ? 'var(--gold)' : 'var(--error)'};flex-shrink:0;"></div>
                <div class="info">
                    <div class="name">${t.subject} ${hasReply ? '<span style="font-size:11px;color:var(--success);">· پاسخ داده شد</span>' : ''}</div>
                    <div class="sub">${t.user} · ${t.time} · ${statusMap[t.status] || t.status}</div>
                </div>
                <div class="actions">
                    <button class="${t.status === 'resolved' ? 'success' : 'gold'}" onclick="event.stopPropagation();updateTicketStatus(${t.id})">${t.status === 'resolved' ? '✓' : 'برطرف کن'}</button>
                </div>
            </div>
        `;
    }).join('');
}

function renderLogs() {
    const container = document.getElementById('logsList');
    const search = document.getElementById('logSearch').value.trim().toLowerCase();
    const filter = document.getElementById('logFilter').value;

    const filtered = logs.filter(function(l) {
        const matchSearch = l.action.includes(search) || l.admin.includes(search);
        const matchFilter = filter === 'all' || l.type === filter;
        return matchSearch && matchFilter;
    });

    if (!filtered.length) {
        container.innerHTML = '<div class="empty-state"><span class="icon"><i class="fas fa-history"></i></span>هیچ لاگی وجود ندارد</div>';
        return;
    }
    const typeMap = { admin: 'ادمین', system: 'سیستم', user: 'کاربران', shop: 'فروشگاه' };
    container.innerHTML = filtered.slice(0, 50).map(function(l) {
        const typeLabel = typeMap[l.type] || l.type;
        return `
            <div class="list-item-admin" style="padding:6px 10px;">
                <div style="font-size:12px;color:var(--text3);"><i class="fas fa-circle" style="font-size:6px;color:var(--gold);"></i></div>
                <div class="info">
                    <div style="font-size:12px;">${l.action}</div>
                    <div class="sub">${l.admin} · ${l.time} · <span style="font-size:10px;color:var(--text3);">${typeLabel}</span></div>
                </div>
            </div>
        `;
    }).join('');
}

function updateBadges() {
    document.getElementById('userBadge').textContent = users.filter(function(u) { return !u.blocked; }).length;
    document.getElementById('adminBadge').textContent = admins.length;
    document.getElementById('shopBadge').textContent = products.length;
    document.getElementById('ticketBadge').textContent = tickets.filter(function(t) { return t.status !== 'resolved'; })
        .length;
}

// ===== سایدبار =====
function toggleSidebar() {
    if (!isAdminLoggedIn) return;
    document.getElementById('sidebarOverlay').classList.toggle('open');
}

function closeSidebar() {
    document.getElementById('sidebarOverlay').classList.remove('open');
}

function switchSection(section, btn) {
    currentSection = section;
    document.querySelectorAll('.section').forEach(function(s) { s.classList.remove('active'); });
    document.getElementById('section-' + section).classList.add('active');
    document.querySelectorAll('.nav-item').forEach(function(b) { b.classList.remove('active'); });
    if (btn) btn.classList.add('active');
    closeSidebar();
    if (section === 'users') renderUsers();
    if (section === 'admins') renderAdmins();
    if (section === 'shop') { renderProductsList();
        renderOrdersList(); }
    if (section === 'tickets') renderTickets();
    if (section === 'logs') renderLogs();
}

// ===== اقدامات کاربران =====
function toggleBlockUser(id) {
    const user = users.find(function(u) { return u.id === id; });
    if (!user) return;
    user.blocked = !user.blocked;
    saveUsers();
    renderUsers();
    addLog((user.blocked ? 'بلاک' : 'آنبلاک') + ' کاربر ' + user.name, 'user');
    showToast(user.blocked ? '✅ کاربر بلاک شد' : '✅ بلاک کاربر برداشته شد', 'success');
}

function changeUserLevel(id) {
    const user = users.find(function(u) { return u.id === id; });
    if (!user) return;
    const levels = ['free', 'premium', 'pro'];
    const currentIdx = levels.indexOf(user.level);
    const nextIdx = (currentIdx + 1) % levels.length;
    user.level = levels[nextIdx];
    saveUsers();
    renderUsers();
    addLog('تغییر سطح کاربر ' + user.name + ' به ' + user.level, 'user');
    showToast('✅ سطح کاربر به ' + user.level + ' تغییر کرد', 'success');
}

// ===== اقدامات ادمین‌ها =====
function openAddAdminModal() {
    if (currentAdmin?.role !== 'super') {
        showToast('⚠️ فقط سوپر ادمین می‌تواند ادمین اضافه کند', 'error');
        return;
    }
    document.getElementById('addAdminModal').classList.add('show');
    document.getElementById('newAdminName').value = '';
    document.getElementById('newAdminUsername').value = '';
    document.getElementById('newAdminPassword').value = '';
    document.getElementById('newAdminPermissions').value = [];
    document.getElementById('newAdminRole').value = 'admin';
    document.getElementById('newAdminName').focus();
}

function closeAddAdminModal() {
    document.getElementById('addAdminModal').classList.remove('show');
}

function addAdmin() {
    const name = document.getElementById('newAdminName').value.trim();
    const username = document.getElementById('newAdminUsername').value.trim().toLowerCase();
    const password = document.getElementById('newAdminPassword').value.trim();
    const role = document.getElementById('newAdminRole').value;
    const permsSelect = document.getElementById('newAdminPermissions');
    const permissions = Array.from(permsSelect.selectedOptions).map(function(o) { return o.value; });

    if (!name || !username || !password) {
        showToast('⚠️ لطفاً تمام فیلدها را پر کنید', 'error');
        return;
    }
    if (password.length < 8) {
        showToast('⚠️ رمز عبور باید حداقل ۸ کاراکتر باشد', 'error');
        return;
    }
    if (admins.find(function(a) { return a.username === username; })) {
        showToast('⚠️ این نام کاربری قبلاً ثبت شده است', 'error');
        return;
    }
    if (username === ADMIN_CONFIG.masterUsername) {
        showToast('⚠️ این نام کاربری متعلق به مدیر اصلی است', 'error');
        return;
    }

    const newAdmin = {
        id: 'a' + Date.now(),
        name: name,
        username: username,
        password: password,
        role: role,
        avatar: name.charAt(0),
        permissions: permissions
    };
    admins.push(newAdmin);
    saveAdmins();
    closeAddAdminModal();
    renderAdmins();
    updateBadges();
    addLog('افزودن ادمین ' + name + ' (' + role + ')', 'admin');
    showToast('✅ ادمین با موفقیت اضافه شد', 'success');
}

function editAdmin(id) {
    if (currentAdmin?.role !== 'super') {
        showToast('⚠️ فقط سوپر ادمین می‌تواند ادمین را ویرایش کند', 'error');
        return;
    }
    const admin = admins.find(function(a) { return a.id === id; });
    if (!admin) return;
    const newName = prompt('نام جدید:', admin.name);
    if (newName === null) return;
    const newPassword = prompt('رمز عبور جدید (خالی بگذارید برای عدم تغییر):', '');
    if (newPassword === null) return;
    admin.name = newName.trim() || admin.name;
    if (newPassword.trim()) admin.password = newPassword.trim();
    saveAdmins();
    renderAdmins();
    addLog('ویرایش ادمین ' + admin.name, 'admin');
    showToast('✅ ادمین ویرایش شد', 'success');
}

function deleteAdmin(id) {
    if (currentAdmin?.role !== 'super') {
        showToast('⚠️ فقط سوپر ادمین می‌تواند ادمین را حذف کند', 'error');
        return;
    }
    const admin = admins.find(function(a) { return a.id === id; });
    if (!admin) return;
    if (!confirm('آیا از حذف ادمین "' + admin.name + '" مطمئنید؟')) return;
    admins = admins.filter(function(a) { return a.id !== id; });
    saveAdmins();
    renderAdmins();
    updateBadges();
    addLog('حذف ادمین ' + admin.name, 'admin');
    showToast('🗑️ ادمین حذف شد', 'success');
}

// ===== اقدامات محصولات =====
function openAddProductModal() {
    document.getElementById('addProductModal').classList.add('show');
    document.getElementById('newProductName').value = '';
    document.getElementById('newProductDesc').value = '';
    document.getElementById('newProductPrice').value = '';
    document.getElementById('newProductStars').value = '';
    document.getElementById('newProductDiscount').value = '0';
    document.getElementById('newProductIcon').value = '📦';
    document.getElementById('newProductName').focus();
}

function closeAddProductModal() {
    document.getElementById('addProductModal').classList.remove('show');
}

function addProduct() {
    const name = document.getElementById('newProductName').value.trim();
    const desc = document.getElementById('newProductDesc').value.trim();
    const price = parseInt(document.getElementById('newProductPrice').value);
    const starsPrice = parseInt(document.getElementById('newProductStars').value);
    const discount = parseInt(document.getElementById('newProductDiscount').value) || 0;
    const category = document.getElementById('newProductCategory').value;
    const icon = document.getElementById('newProductIcon').value.trim() || '📦';

    if (!name || !price || !starsPrice) {
        showToast('⚠️ لطفاً نام، قیمت و قیمت ستاره را وارد کنید', 'error');
        return;
    }

    const newProduct = {
        id: 'prod_' + Date.now(),
        name: name,
        desc: desc,
        price: price,
        starsPrice: starsPrice,
        discount: discount,
        category: category,
        icon: icon
    };
    products.push(newProduct);
    saveProducts();
    closeAddProductModal();
    renderProductsList();
    updateBadges();
    addLog('افزودن محصول ' + name, 'shop');
    showToast('✅ محصول با موفقیت اضافه شد', 'success');
}

function editProduct(id) {
    const p = products.find(function(pr) { return pr.id === id; });
    if (!p) return;
    const newName = prompt('نام جدید:', p.name);
    if (newName === null) return;
    const newPrice = parseInt(prompt('قیمت جدید (تومان):', p.price));
    if (isNaN(newPrice)) return;
    const newStars = parseInt(prompt('قیمت جدید با ستاره:', p.starsPrice));
    if (isNaN(newStars)) return;
    p.name = newName.trim() || p.name;
    p.price = newPrice;
    p.starsPrice = newStars;
    saveProducts();
    renderProductsList();
    addLog('ویرایش محصول ' + p.name, 'shop');
    showToast('✅ محصول ویرایش شد', 'success');
}

function deleteProduct(id) {
    if (!confirm('آیا از حذف این محصول مطمئنید؟')) return;
    const p = products.find(function(pr) { return pr.id === id; });
    products = products.filter(function(pr) { return pr.id !== id; });
    saveProducts();
    renderProductsList();
    updateBadges();
    addLog('حذف محصول ' + (p ? p.name : ''), 'shop');
    showToast('🗑️ محصول حذف شد', 'success');
}

function updateOrderStatus(id) {
    const order = orders.find(function(o) { return o.id === id; });
    if (!order) return;
    order.status = order.status === 'completed' ? 'pending' : 'completed';
    saveOrders();
    renderOrdersList();
    addLog('تغییر وضعیت سفارش ' + order.id + ' به ' + order.status, 'shop');
    showToast('✅ وضعیت سفارش تغییر کرد', 'success');
}

// ===== تنظیمات دسترسی =====
function loadPermissionSettings() {
    const level = document.getElementById('permLevel').value;
    document.getElementById('customPermDiv').style.display = level === 'custom' ? 'block' : 'none';
    const p = Permissions.get();
    const settings = p.permissions?.[level] || { dailyLimit: level === 'free' ? 5 : level === 'premium' ? 30 : 100,
        models: level === 'free' ? ['openai'] : level === 'premium' ? ['openai', 'deepseek'] : ['openai',
            'deepseek', 'xai'
        ], signalAccess: level !== 'free', proAccess: level === 'pro' };
    if (level === 'custom') {
        settings = p.permissions?.custom || { dailyLimit: 20, models: ['openai', 'deepseek'],
            signalAccess: true, proAccess: false };
    }
    document.getElementById('permDailyLimit').value = settings.dailyLimit || 5;
    document.getElementById('permModels').value = (settings.models || ['openai']).join(', ');
    document.getElementById('permSignalAccess').value = settings.signalAccess ? 'true' : 'false';
    document.getElementById('permProAccess').value = settings.proAccess ? 'true' : 'false';
    if (level === 'custom') {
        document.getElementById('permCustomName').value = p.permissions?.customName || 'VIP';
    }
}

function savePermissionsSettings() {
    const level = document.getElementById('permLevel').value;
    const dailyLimit = parseInt(document.getElementById('permDailyLimit').value) || 5;
    const models = document.getElementById('permModels').value.split(',').map(function(s) { return s.trim(); }).filter(
        function(s) { return s; });
    const signalAccess = document.getElementById('permSignalAccess').value === 'true';
    const proAccess = document.getElementById('permProAccess').value === 'true';
    const customName = document.getElementById('permCustomName').value.trim() || 'سفارشی';
    const p = Permissions.get();
    if (!p.permissions) p.permissions = {};
    p.permissions[level] = { dailyLimit: dailyLimit, models: models, signalAccess: signalAccess,
        proAccess: proAccess };
    if (level === 'custom') {
        p.permissions.customName = customName;
    }
    Permissions.save(p);
    addLog('تغییر تنظیمات دسترسی برای سطح ' + level, 'permissions');
    showToast('✅ تنظیمات دسترسی ذخیره شد', 'success');
}

// ===== تنظیمات AI =====
function loadAISettings() {
    try {
        const settings = JSON.parse(localStorage.getItem('pulset_ai_settings') || '{}');
        document.getElementById('aiDefaultModel').value = settings.defaultModel || 'openai';
        document.getElementById('aiTemperature').value = settings.temperature || '0.7';
        document.getElementById('aiMaxTokens').value = settings.maxTokens || '2048';
        document.getElementById('aiOpenAIKey').value = settings.openaiKey || '';
        document.getElementById('aiDeepSeekKey').value = settings.deepseekKey || '';
        document.getElementById('aiXAIKey').value = settings.xaiKey || '';
    } catch (e) { /* ignore */ }
}

function saveAISettings() {
    const settings = {
        defaultModel: document.getElementById('aiDefaultModel').value,
        temperature: parseFloat(document.getElementById('aiTemperature').value) || 0.7,
        maxTokens: parseInt(document.getElementById('aiMaxTokens').value) || 2048,
        openaiKey: document.getElementById('aiOpenAIKey').value.trim(),
        deepseekKey: document.getElementById('aiDeepSeekKey').value.trim(),
        xaiKey: document.getElementById('aiXAIKey').value.trim()
    };
    localStorage.setItem('pulset_ai_settings', JSON.stringify(settings));
    addLog('تغییر تنظیمات هوش مصنوعی', 'ai');
    showToast('✅ تنظیمات AI ذخیره شد', 'success');
}

// ===== تنظیمات مالی =====
function loadFinancialSettings() {
    try {
        const settings = JSON.parse(localStorage.getItem('pulset_financial_settings') || '{}');
        document.getElementById('starRate').value = settings.starRate || '70';
        document.getElementById('minWithdraw').value = settings.minWithdraw || '100000';
        document.getElementById('paymentGateway').value = settings.paymentGateway || 'zarinpal';
        document.getElementById('merchantCode').value = settings.merchantCode || '';
    } catch (e) { /* ignore */ }
}

function saveFinancialSettings() {
    const settings = {
        starRate: parseInt(document.getElementById('starRate').value) || 70,
        minWithdraw: parseInt(document.getElementById('minWithdraw').value) || 100000,
        paymentGateway: document.getElementById('paymentGateway').value,
        merchantCode: document.getElementById('merchantCode').value.trim()
    };
    localStorage.setItem('pulset_financial_settings', JSON.stringify(settings));
    addLog('تغییر تنظیمات مالی', 'financial');
    showToast('✅ تنظیمات مالی ذخیره شد', 'success');
}

// ===== تنظیمات سایت =====
function loadSiteSettings() {
    try {
        const settings = JSON.parse(localStorage.getItem('pulset_site_settings') || '{}');
        document.getElementById('siteTitle').value = settings.title || 'Pulset';
        document.getElementById('siteDesc').value = settings.description || 'سیگنال‌های هوشمند، معاملات آگاهانه';
        document.getElementById('siteTheme').value = settings.theme || 'light';
        document.getElementById('siteLang').value = settings.lang || 'fa';
    } catch (e) { /* ignore */ }
}

function saveSiteSettings() {
    const settings = {
        title: document.getElementById('siteTitle').value.trim() || 'Pulset',
        description: document.getElementById('siteDesc').value.trim() || 'سیگنال‌های هوشمند، معاملات آگاهانه',
        theme: document.getElementById('siteTheme').value,
        lang: document.getElementById('siteLang').value
    };
    localStorage.setItem('pulset_site_settings', JSON.stringify(settings));
    addLog('تغییر تنظیمات سایت', 'settings');
    showToast('✅ تنظیمات سایت ذخیره شد', 'success');
    if (settings.theme === 'dark') document.body.classList.add('dark');
    else if (settings.theme === 'light') document.body.classList.remove('dark');
    if (settings.lang !== localStorage.getItem('pulset_lang')) {
        localStorage.setItem('pulset_lang', settings.lang);
    }
}

// ===== اطلاعیه =====
function sendAnnouncement() {
    const title = document.getElementById('announceTitle').value.trim();
    const message = document.getElementById('announceMessage').value.trim();
    const target = document.getElementById('announceTarget').value;
    const specific = document.getElementById('announceSpecific').value.trim();

    if (!title || !message) {
        showToast('⚠️ لطفاً عنوان و متن اطلاعیه را وارد کنید', 'error');
        return;
    }

    const data = { title: title, message: message, target: target };
    if (target === 'specific' && specific) {
        data.users = specific.split(',').map(function(s) { return s.trim(); }).filter(function(s) { return s; });
    }

    addLog('ارسال اطلاعیه: ' + title, 'content');
    showToast('✅ اطلاعیه با موفقیت ارسال شد', 'success');
    document.getElementById('announceTitle').value = '';
    document.getElementById('announceMessage').value = '';
    document.getElementById('announceSpecific').value = '';
}

document.getElementById('announceTarget').addEventListener('change', function() {
    document.getElementById('specificUsersDiv').style.display = this.value === 'specific' ? 'block' : 'none';
});

// ===== صفحات استاتیک =====
function loadStaticPage() {
    const page = document.getElementById('staticPageSelect').value;
    try {
        const content = localStorage.getItem('pulset_static_' + page);
        document.getElementById('staticPageContent').value = content || '';
    } catch (e) { /* ignore */ }
}

function saveStaticPage() {
    const page = document.getElementById('staticPageSelect').value;
    const content = document.getElementById('staticPageContent').value;
    localStorage.setItem('pulset_static_' + page, content);
    addLog('ویرایش صفحه ' + page, 'content');
    showToast('✅ صفحه ذخیره شد', 'success');
}

// ===== جزئیات تیکت =====
let currentTicketId = null;

function openTicketDetail(id) {
    currentTicketId = id;
    const ticket = tickets.find(function(t) { return t.id === id; });
    if (!ticket) return;
    alert('جزئیات تیکت: ' + ticket.subject + '\n' + ticket.messages.map(function(m) { return m.sender + ': ' + m
            .text; }).join('\n'));
}

function updateTicketStatus(id) {
    const ticket = tickets.find(function(t) { return t.id === id; });
    if (!ticket) return;
    ticket.status = ticket.status === 'resolved' ? 'open' : 'resolved';
    saveTickets();
    renderTickets();
    addLog('تغییر وضعیت تیکت ' + ticket.subject + ' به ' + ticket.status, 'tickets');
    showToast('✅ وضعیت تیکت تغییر کرد', 'success');
}

// ===== مقداردهی اولیه =====
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    const lang = getCurrentLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    applyPageTranslations();

    if (checkAdminAuth()) {
        isAdminLoggedIn = true;
        hideLogin();
        loadData();
        startSessionTimer();
        updateHeaderInfo();
        document.querySelector('.status-dot').className = 'status-dot online';
        console.log('✅ Admin panel ready - logged in');
    } else {
        showLogin();
        document.querySelector('.status-dot').className = 'status-dot offline';
        console.log('🔒 Admin panel - login required');
    }

    // میانبر Ctrl+Shift+A
    document.addEventListener('keydown', function(e) {
        if (e.ctrlKey && e.shiftKey && (e.key === 'a' || e.key === 'A')) {
            e.preventDefault();
            if (!isAdminLoggedIn) {
                showLogin();
            } else {
                showToast('🔐 شما وارد شده‌اید', 'success');
            }
        }
    });

    document.querySelectorAll('.modal-overlay').forEach(function(modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === this) this.classList.remove('show');
        });
    });

    console.log('✅ Admin panel loaded');
});

// ===== خروجی توابع =====
window.toggleSidebar = toggleSidebar;
window.closeSidebar = closeSidebar;
window.switchSection = switchSection;
window.toggleBlockUser = toggleBlockUser;
window.changeUserLevel = changeUserLevel;
window.openAddAdminModal = openAddAdminModal;
window.closeAddAdminModal = closeAddAdminModal;
window.addAdmin = addAdmin;
window.editAdmin = editAdmin;
window.deleteAdmin = deleteAdmin;
window.openAddProductModal = openAddProductModal;
window.closeAddProductModal = closeAddProductModal;
window.addProduct = addProduct;
window.editProduct = editProduct;
window.deleteProduct = deleteProduct;
window.updateOrderStatus = updateOrderStatus;
window.openTicketDetail = openTicketDetail;
window.updateTicketStatus = updateTicketStatus;
window.loadPermissionSettings = loadPermissionSettings;
window.savePermissionsSettings = savePermissionsSettings;
window.loadAISettings = loadAISettings;
window.saveAISettings = saveAISettings;
window.loadFinancialSettings = loadFinancialSettings;
window.saveFinancialSettings = saveFinancialSettings;
window.loadSiteSettings = loadSiteSettings;
window.saveSiteSettings = saveSiteSettings;
window.sendAnnouncement = sendAnnouncement;
window.loadStaticPage = loadStaticPage;
window.saveStaticPage = saveStaticPage;
window.logout = logout;
window.adminLogin = adminLogin;
window.loadData = loadData;
window.renderUsers = renderUsers;
window.renderAdmins = renderAdmins;
window.renderProductsList = renderProductsList;
window.renderOrdersList = renderOrdersList;
window.renderTickets = renderTickets;
window.renderLogs = renderLogs;
window.showToast = showToast;
window.addLog = addLog;
window.hideLogin = hideLogin;
window.showLogin = showLogin;
window.checkAdminAuth = checkAdminAuth;
