// ================================================================
// settings.js - اسکریپت صفحه تنظیمات
// ================================================================

// ===== ترجمه =====
const PAGE_TR = {
    fa: {
        pageTitle: 'تنظیمات',
        account: 'حساب کاربری',
        wallet: 'کیف پول و درآمد',
        walletDesc: 'مدیریت موجودی و تراکنش‌ها',
        changePassword: 'تغییر رمز عبور',
        changePasswordDesc: 'به‌روزرسانی رمز عبور',
        privacy: 'حریم خصوصی و امنیت',
        privacyDesc: 'مدیریت حریم خصوصی حساب',
        appSettings: 'تنظیمات اپلیکیشن',
        startPage: 'صفحه شروع',
        language: 'زبان',
        theme: 'تم',
        notifications: 'اعلان‌ها',
        notificationsDesc: 'دریافت اعلان‌های سیگنال و پیام',
        about: 'درباره',
        aboutPulset: 'درباره Pulset',
        aboutPulsetDesc: 'معرفی پلتفرم و تیم',
        support: 'پشتیبانی',
        supportDesc: 'تماس با تیم پشتیبانی',
        terms: 'شرایط استفاده',
        termsDesc: 'مطالعه قوانین و مقررات',
        disclaimer: 'سلب مسئولیت',
        disclaimerDesc: 'اطلاعات حقوقی و هشدارها',
        logout: 'خروج از حساب',
        logoutTitle: 'خروج از حساب',
        logoutDesc: 'آیا مطمئنید که می‌خواهید خارج شوید؟',
        cancelBtn: 'انصراف',
        logoutBtn: 'خروج',
        closeBtn: 'بستن',
        saveBtn: 'ذخیره',
        dashboard: 'داشبورد',
        signals: 'سیگنال‌ها',
        markets: 'بازارها',
        persian: 'فارسی',
        english: 'English',
        light: 'روشن',
        dark: 'تاریک',
        adminTitle: 'ورود به پنل مدیریت',
        adminDesc: 'رمز عبور مدیریت را وارد کنید.',
        adminPassword: 'رمز عبور',
        adminWrong: '❌ رمز عبور اشتباه است.',
        adminSuccess: '✅ ورود موفق',
        saveSuccess: '✅ تنظیمات ذخیره شد',
        logoutSuccess: '✅ خروج موفق',
        changePasswordTitle: 'تغییر رمز عبور',
        currentPassword: 'رمز عبور فعلی',
        newPassword: 'رمز عبور جدید',
        confirmPassword: 'تکرار رمز عبور جدید',
        passwordHint: 'حداقل ۸ کاراکتر',
        passwordMismatch: 'رمز عبور جدید و تکرار آن مطابقت ندارند',
        passwordShort: 'رمز عبور جدید باید حداقل ۸ کاراکتر باشد',
        passwordRequired: 'لطفاً تمام فیلدها را پر کنید',
        passwordSuccess: '✅ رمز عبور با موفقیت تغییر کرد',
        privacyTitle: 'حریم خصوصی و امنیت',
        privacySubtitle: 'تنظیمات حریم خصوصی حساب شما',
        privateAccount: 'حساب خصوصی',
        privateAccountDesc: 'فقط فالوئرها پست‌ها را ببینند',
        activityStatus: 'وضعیت فعالیت',
        activityStatusDesc: 'نمایش آخرین بازدید به دیگران',
        whoCanMessage: 'چه کسی می‌تواند پیام دهد؟',
        whoCanSeeSignals: 'چه کسی سیگنال‌ها را می‌بیند؟',
        everyone: 'همه',
        followersOnly: 'فالوئرها',
        none: 'هیچکس',
        blockedList: 'بلاک‌لیست',
        blockedListDesc: 'مدیریت کاربران بلاک‌شده',
        restrictedList: 'کاربران محدودشده',
        restrictedListDesc: 'مدیریت کاربران محدود'
    },
    en: {
        pageTitle: 'Settings',
        account: 'Account',
        wallet: 'Wallet & Earnings',
        walletDesc: 'Manage balance and transactions',
        changePassword: 'Change Password',
        changePasswordDesc: 'Update your password',
        privacy: 'Privacy & Security',
        privacyDesc: 'Manage account privacy',
        appSettings: 'App Settings',
        startPage: 'Start Page',
        language: 'Language',
        theme: 'Theme',
        notifications: 'Notifications',
        notificationsDesc: 'Receive signal and message notifications',
        about: 'About',
        aboutPulset: 'About Pulset',
        aboutPulsetDesc: 'Platform and team introduction',
        support: 'Support',
        supportDesc: 'Contact support team',
        terms: 'Terms of Service',
        termsDesc: 'Read rules and regulations',
        disclaimer: 'Disclaimer',
        disclaimerDesc: 'Legal information and warnings',
        logout: 'Logout',
        logoutTitle: 'Logout',
        logoutDesc: 'Are you sure you want to logout?',
        cancelBtn: 'Cancel',
        logoutBtn: 'Logout',
        closeBtn: 'Close',
        saveBtn: 'Save',
        dashboard: 'Dashboard',
        signals: 'Signals',
        markets: 'Markets',
        persian: 'Persian',
        english: 'English',
        light: 'Light',
        dark: 'Dark',
        adminTitle: 'Admin Panel Login',
        adminDesc: 'Enter the admin password.',
        adminPassword: 'Password',
        adminWrong: '❌ Wrong password.',
        adminSuccess: '✅ Login successful',
        saveSuccess: '✅ Settings saved',
        logoutSuccess: '✅ Logout successful',
        changePasswordTitle: 'Change Password',
        currentPassword: 'Current Password',
        newPassword: 'New Password',
        confirmPassword: 'Confirm New Password',
        passwordHint: 'Minimum 8 characters',
        passwordMismatch: 'Passwords do not match',
        passwordShort: 'Password must be at least 8 characters',
        passwordRequired: 'Please fill all fields',
        passwordSuccess: '✅ Password changed successfully',
        privacyTitle: 'Privacy & Security',
        privacySubtitle: 'Manage your account privacy settings',
        privateAccount: 'Private Account',
        privateAccountDesc: 'Only followers can see your posts',
        activityStatus: 'Activity Status',
        activityStatusDesc: 'Show your last seen to others',
        whoCanMessage: 'Who can message you?',
        whoCanSeeSignals: 'Who can see your signals?',
        everyone: 'Everyone',
        followersOnly: 'Followers',
        none: 'No one',
        blockedList: 'Blocked List',
        blockedListDesc: 'Manage blocked users',
        restrictedList: 'Restricted Users',
        restrictedListDesc: 'Manage restricted users'
    }
};

// ===== متغیرها =====
let lang = getCurrentLang();
let sheetType = '';

// ===== اعمال ترجمه =====
function applyPageTranslations() {
    const t = PAGE_TR[lang] || PAGE_TR.fa;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key]) el.textContent = t[key];
    });
    updateDynamicTexts();
    updatePrivacyTexts();
}
window.applyPageTranslations = applyPageTranslations;

// ===== به‌روزرسانی متن‌های پویا =====
function updateDynamicTexts() {
    const t = PAGE_TR[lang] || PAGE_TR.fa;

    // صفحه شروع
    const start = localStorage.getItem('pulset_start_page') || 'dashboard';
    const startMap = { dashboard: t.dashboard, signals: t.signals, markets: t.markets };
    const el = document.getElementById('startPageDesc');
    if (el) el.textContent = startMap[start] || t.dashboard;

    // زبان
    const langMap = { fa: t.persian, en: t.english };
    const el2 = document.getElementById('langDesc');
    if (el2) el2.textContent = langMap[lang] || t.persian;

    // تم
    const theme = localStorage.getItem('pulset_dark') === 'true' ? 'dark' : 'light';
    const themeMap = { light: t.light, dark: t.dark };
    const el3 = document.getElementById('themeDesc');
    if (el3) el3.textContent = themeMap[theme] || t.light;

    // کیف پول
    fetchWalletBalance();
}

// ===== به‌روزرسانی متن‌های حریم خصوصی =====
function updatePrivacyTexts() {
    const t = PAGE_TR[lang] || PAGE_TR.fa;
    const msgVal = localStorage.getItem('pulset_msgPrivacySelect') || 'everyone';
    const sigVal = localStorage.getItem('pulset_sigPrivacySelect') || 'followers';
    const map = { everyone: t.everyone, followers: t.followersOnly, none: t.none };

    const msgEl = document.getElementById('msgPrivacyDesc');
    if (msgEl) msgEl.textContent = map[msgVal] || t.everyone;
    const msgSel = document.getElementById('msgPrivacySelected');
    if (msgSel) msgSel.textContent = map[msgVal] || t.everyone;

    const sigEl = document.getElementById('sigPrivacyDesc');
    if (sigEl) sigEl.textContent = map[sigVal] || t.followersOnly;
    const sigSel = document.getElementById('sigPrivacySelected');
    if (sigSel) sigSel.textContent = map[sigVal] || t.followersOnly;
}

// ===== دریافت موجودی کیف پول =====
async function fetchWalletBalance() {
    try {
        const data = await API.Wallet.get();
        if (data && data.rial) {
            const badge = document.getElementById('walletBadge');
            if (badge) badge.textContent = (data.rial / 1000).toFixed(1) + 'M';
        }
    } catch (e) {
        const rial = parseInt(localStorage.getItem('pulset_rial_balance')) || 0;
        const badge = document.getElementById('walletBadge');
        if (badge) badge.textContent = (rial / 1000).toFixed(1) + 'M';
    }
}

// ===== بارگذاری پروفایل =====
async function loadProfile() {
    try {
        const data = await API.Profile.get();
        let p = data;
        if (!p) {
            p = JSON.parse(localStorage.getItem('pulset_profile') ||
                '{"displayName":"کاربر","username":"@user","avatar":"","verified":false}');
        }
        // ذخیره نقش برای نمایش دکمه مدیریت
        if (p.role) {
            localStorage.setItem('pulset_user_role', p.role);
        }

        const avatarDiv = document.getElementById('profileAvatar');
        const img = document.getElementById('profileAvatarImg');
        if (p.avatar && p.avatar.startsWith('data:image')) {
            img.src = p.avatar;
            img.style.display = 'block';
            avatarDiv.classList.add('has-image');
        } else {
            img.style.display = 'none';
            avatarDiv.classList.remove('has-image');
        }
        document.getElementById('profileName').innerHTML = (p.displayName || 'کاربر') +
            (p.verified ? ' <span class="verified">✓</span>' : '');
        document.getElementById('profileHandle').textContent = p.username || '@user';

        // نمایش دکمه مدیریت
        showAdminEntry();

    } catch (e) {
        console.warn('Load profile error:', e);
    }
}

// ===== نمایش دکمه مدیریت =====
function showAdminEntry() {
    const role = getUserRole();
    const adminEntry = document.getElementById('adminEntryPoint');
    if (!adminEntry) return;

    if (role === 'admin' || role === 'super') {
        adminEntry.style.display = 'block';
        if (role === 'super') {
            const label = adminEntry.querySelector('.label');
            if (label) label.textContent = '🛡️ پنل مدیریت (سوپر)';
        }
    } else {
        adminEntry.style.display = 'none';
    }
}

function getUserRole() {
    let role = localStorage.getItem('pulset_user_role');
    if (role === 'admin' || role === 'super') return role;
    try {
        const profile = JSON.parse(localStorage.getItem('pulset_profile') || '{}');
        if (profile.role === 'admin' || profile.role === 'super') {
            localStorage.setItem('pulset_user_role', profile.role);
            return profile.role;
        }
    } catch (e) { /* ignore */ }
    return 'user';
}

// ===== ذخیره تنظیمات =====
function saveSetting(key, value) {
    localStorage.setItem('pulset_' + key, JSON.stringify(value));
    updateSettingsToAPI(key, value);
    showToast(t('saveSuccess'));
    updateDynamicTexts();
}

function loadSetting(key, def) {
    try {
        const val = localStorage.getItem('pulset_' + key);
        if (val === null) return def;
        return JSON.parse(val);
    } catch (e) { return def; }
}

async function updateSettingsToAPI(key, value) {
    try {
        await API.Settings.update({ [key]: value });
    } catch (e) {
        console.warn('Update settings error:', e);
    }
}

// ===== توست =====
function t(key) {
    return PAGE_TR[lang]?.[key] || key;
}

// ===== مودال‌ها =====
function openModal(id) {
    document.getElementById(id).classList.add('show');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('show');
}

// ===== شیت انتخاب =====
function openSheet(type) {
    sheetType = type;
    const modal = document.getElementById('sheetModal');
    const options = document.getElementById('sheetOptions');
    const icon = document.getElementById('sheetIcon');
    const title = document.getElementById('sheetTitle');
    const desc = document.getElementById('sheetDesc');

    const optData = [];
    let selected = '';
    const iconMap = { start: 'fa-home', lang: 'fa-globe', theme: 'fa-moon' };
    const titleMap = { start: t('startPage'), lang: t('language'), theme: t('theme') };
    const descMap = {
        start: 'صفحه‌ای که پس از ورود نمایش داده می‌شود',
        lang: 'زبان رابط کاربری را انتخاب کنید',
        theme: 'تم روشن یا تاریک را انتخاب کنید'
    };

    icon.className = 'icon fas ' + (iconMap[type] || 'fa-cog');
    title.textContent = titleMap[type] || 'انتخاب کنید';
    desc.textContent = descMap[type] || '';

    if (type === 'start') {
        optData = [
            { value: 'dashboard', label: t('dashboard') },
            { value: 'signals', label: t('signals') },
            { value: 'markets', label: t('markets') }
        ];
        selected = localStorage.getItem('pulset_start_page') || 'dashboard';
    } else if (type === 'lang') {
        optData = [
            { value: 'fa', label: t('persian') },
            { value: 'en', label: t('english') }
        ];
        selected = lang;
    } else if (type === 'theme') {
        optData = [
            { value: 'light', label: t('light') },
            { value: 'dark', label: t('dark') }
        ];
        selected = localStorage.getItem('pulset_dark') === 'true' ? 'dark' : 'light';
    }

    options.innerHTML = optData.map(opt => `
        <div class="sheet-option ${opt.value === selected ? 'active' : ''}" onclick="selectSheetOption('${opt.value}')">
            <span class="label">${opt.label}</span>
            <span class="check"><i class="fas fa-check-circle"></i></span>
        </div>
    `).join('');

    modal.classList.add('show');
}

function selectSheetOption(value) {
    if (sheetType === 'start') {
        localStorage.setItem('pulset_start_page', value);
        updateSettingsToAPI('start_page', value);
        showToast(t('saveSuccess'));
        updateDynamicTexts();
        closeModal('sheetModal');
    } else if (sheetType === 'lang') {
        if (value !== lang) {
            lang = value;
            localStorage.setItem('pulset_lang', lang);
            document.documentElement.lang = lang;
            document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
            applyPageTranslations();
            updateDynamicTexts();
            showToast(t('saveSuccess'));
        }
        closeModal('sheetModal');
    } else if (sheetType === 'theme') {
        const isDark = value === 'dark';
        if (document.body.classList.contains('dark') !== isDark) {
            document.body.classList.toggle('dark', isDark);
            localStorage.setItem('pulset_dark', String(isDark));
            updateSettingsToAPI('theme', isDark ? 'dark' : 'light');
            updateDynamicTexts();
            showToast(t('saveSuccess'));
        }
        closeModal('sheetModal');
    }
}

// ===== اعلان‌ها =====
function toggleNotification() {
    const cb = document.getElementById('notifToggle');
    saveSetting('notifications', cb.checked);
}

// ===== تغییر رمز عبور =====
function openChangePassword() {
    document.getElementById('currentPassword').value = '';
    document.getElementById('newPassword').value = '';
    document.getElementById('confirmPassword').value = '';
    document.getElementById('passwordError').style.display = 'none';
    openModal('changePasswordModal');
}

async function submitChangePassword() {
    const current = document.getElementById('currentPassword').value.trim();
    const newPass = document.getElementById('newPassword').value.trim();
    const confirm = document.getElementById('confirmPassword').value.trim();
    const error = document.getElementById('passwordError');

    if (!current || !newPass || !confirm) {
        error.textContent = t('passwordRequired');
        error.style.display = 'block';
        return;
    }
    if (newPass.length < 8) {
        error.textContent = t('passwordShort');
        error.style.display = 'block';
        return;
    }
    if (newPass !== confirm) {
        error.textContent = t('passwordMismatch');
        error.style.display = 'block';
        return;
    }

    try {
        await API.Profile.changePassword(current, newPass);
        error.style.display = 'none';
        closeModal('changePasswordModal');
        showToast(t('passwordSuccess'));
    } catch (e) {
        error.textContent = 'خطا در تغییر رمز عبور. لطفاً مجدداً تلاش کنید.';
        error.style.display = 'block';
    }
}

// ===== حریم خصوصی =====
function openPrivacy() {
    const privateAcc = loadSetting('privateAccount', false);
    document.getElementById('privateAccount').checked = privateAcc;
    const activity = loadSetting('activityStatus', true);
    document.getElementById('activityStatus').checked = activity;

    const msgVal = localStorage.getItem('pulset_msgPrivacySelect') || 'everyone';
    const sigVal = localStorage.getItem('pulset_sigPrivacySelect') || 'followers';
    const map = { everyone: t('everyone'), followers: t('followersOnly'), none: t('none') };
    document.getElementById('msgPrivacySelected').textContent = map[msgVal] || t('everyone');
    document.getElementById('msgPrivacyDesc').textContent = map[msgVal] || t('everyone');
    document.getElementById('sigPrivacySelected').textContent = map[sigVal] || t('followersOnly');
    document.getElementById('sigPrivacyDesc').textContent = map[sigVal] || t('followersOnly');

    document.querySelectorAll('#msgPrivacyOptions .opt').forEach(el => {
        el.classList.toggle('selected', el.dataset.value === msgVal);
    });
    document.querySelectorAll('#sigPrivacyOptions .opt').forEach(el => {
        el.classList.toggle('selected', el.dataset.value === sigVal);
    });

    openModal('privacyModal');
}

function togglePrivacyDropdown(id) {
    const container = document.getElementById(id);
    const options = container.querySelector('.options');
    const isOpen = options.classList.contains('show');
    document.querySelectorAll('.custom-select .options').forEach(o => o.classList.remove('show'));
    if (!isOpen) options.classList.add('show');
}

function selectPrivacyOption(selectId, value, label, descId, selectedId) {
    const container = document.getElementById(selectId);
    container.querySelector('.options').classList.remove('show');
    document.getElementById(selectedId).textContent = label;
    document.getElementById(descId).textContent = label;
    container.querySelectorAll('.opt').forEach(el => el.classList.remove('selected'));
    const opt = container.querySelector('.opt[data-value="' + value + '"]');
    if (opt) opt.classList.add('selected');
    localStorage.setItem('pulset_' + selectId, value);
    updateSettingsToAPI(selectId, value);
}

function savePrivacySetting(key, value) {
    saveSetting(key, value);
}

// ===== خروج =====
function logout() {
    openModal('logoutModal');
}

async function confirmLogout() {
    closeModal('logoutModal');
    try {
        await API.Auth.logout();
    } catch (e) {
        console.warn('Logout API error:', e);
    }
    localStorage.removeItem('pulset_token');
    localStorage.removeItem('pulset_refresh_token');
    localStorage.removeItem('pulset_profile');
    showToast(t('logoutSuccess'));
    setTimeout(function() {
        window.location.href = 'pulset.html';
    }, 1000);
}

// ===== مقداردهی اولیه =====
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    lang = getCurrentLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');

    applyPageTranslations();
    loadProfile();
    updateDynamicTexts();

    // نمایش دکمه مدیریت
    showAdminEntry();

    // کلیک خارج از سلکت
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.custom-select')) {
            document.querySelectorAll('.custom-select .options').forEach(o => o.classList.remove('show'));
        }
    });

    console.log('✅ settings.js loaded');
});

// ===== خروجی توابع =====
window.openSheet = openSheet;
window.selectSheetOption = selectSheetOption;
window.toggleNotification = toggleNotification;
window.saveSetting = saveSetting;
window.logout = logout;
window.confirmLogout = confirmLogout;
window.openModal = openModal;
window.closeModal = closeModal;
window.showToast = showToast;
window.openChangePassword = openChangePassword;
window.submitChangePassword = submitChangePassword;
window.openPrivacy = openPrivacy;
window.togglePrivacyDropdown = togglePrivacyDropdown;
window.selectPrivacyOption = selectPrivacyOption;
window.savePrivacySetting = savePrivacySetting;
window.toggleDark = function() {
    document.body.classList.toggle('dark');
    localStorage.setItem('pulset_dark', document.body.classList.contains('dark'));
    updateSettingsToAPI('theme', document.body.classList.contains('dark') ? 'dark' : 'light');
    updateDynamicTexts();
    applyPageTranslations();
};
window.toggleLang = function() {
    lang = lang === 'fa' ? 'en' : 'fa';
    localStorage.setItem('pulset_lang', lang);
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    applyPageTranslations();
    updateDynamicTexts();
};
window.showAdminEntry = showAdminEntry;
window.getUserRole = getUserRole;
window.loadProfile = loadProfile;
