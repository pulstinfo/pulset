// ================================================================
// profile.js - اسکریپت صفحه پروفایل
// ================================================================

let currentUser = null,
    profileData = null,
    isOwnProfile = true,
    isFollowing = false,
    userPosts = [],
    userSignals = [],
    userReposts = [],
    followersList = [],
    followingList = [],
    currentTab = 'about';

function applyPageTranslations() {
    const lang = getCurrentLang();
    const tr = {
        fa: {
            posts_label: 'پست‌ها',
            followers_label: 'دنبال‌کنندگان',
            following_label: 'دنبال‌شوندگان',
            edit_profile: 'ویرایش پروفایل',
            about: 'درباره',
            posts: 'پست‌ها',
            signals: 'سیگنال‌ها',
            reposts: 'بازنشرها',
            experience: 'سابقه کاری',
            education: 'تحصیلات',
            location: 'موقعیت مکانی',
            links: 'لینک‌ها',
            stats: 'آمار معاملات',
            follow: 'دنبال کردن',
            unfollow: 'لغو دنبال',
            followers: 'دنبال‌کنندگان',
            following: 'دنبال‌شوندگان',
            no_posts: 'هیچ پستی وجود ندارد',
            no_signals: 'هیچ سیگنالی وجود ندارد',
            no_reposts: 'هیچ بازنشری وجود ندارد',
            login_required: 'برای این اقدام باید وارد شوید.',
            msg: 'پیام‌ها',
            block: 'بلاک',
            report: 'گزارش',
            privacy_hidden: 'این کاربر لیست دنبال‌کنندگان خود را مخفی کرده است.',
            profile_title: 'پروفایل',
            share: 'اشتراک‌گذاری',
            share_title: 'اشتراک‌گذاری پروفایل',
            copy_link: 'کپی لینک',
            followed_toast: 'دنبال می‌کنید',
            unfollowed_toast: 'لغو دنبال',
            last_30d: 'در ۳۰ روز گذشته',
            published_on_pulset: 'منتشر شده در Pulset'
        },
        en: {
            posts_label: 'Posts',
            followers_label: 'Followers',
            following_label: 'Following',
            edit_profile: 'Edit Profile',
            about: 'About',
            posts: 'Posts',
            signals: 'Signals',
            reposts: 'Reposts',
            experience: 'Experience',
            education: 'Education',
            location: 'Location',
            links: 'Links',
            stats: 'Stats',
            follow: 'Follow',
            unfollow: 'Unfollow',
            followers: 'Followers',
            following: 'Following',
            no_posts: 'No posts yet',
            no_signals: 'No signals yet',
            no_reposts: 'No reposts yet',
            login_required: 'Please login to perform this action.',
            msg: 'Messages',
            block: 'Block',
            report: 'Report',
            privacy_hidden: 'This user has hidden their followers list.',
            profile_title: 'Profile',
            share: 'Share',
            share_title: 'Share Profile',
            copy_link: 'Copy Link',
            followed_toast: 'Following',
            unfollowed_toast: 'Unfollowed',
            last_30d: 'Last 30 days',
            published_on_pulset: 'Published on Pulset'
        }
    };
    const t = tr[lang] || tr.fa;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key]) el.textContent = t[key];
    });
    document.getElementById('pageTitle').textContent = t.profile_title;
    document.getElementById('sheetTitle').textContent = lang === 'fa' ? 'دنبال‌کنندگان' : 'Followers';
}
window.applyPageTranslations = applyPageTranslations;

function getSampleOtherProfile(username) {
    const samples = {
        'maryam': {
            name: 'مریم تریدر',
            username: '@mary_crypto',
            avatar: 'م',
            verified: true,
            bio: 'تریدر و تحلیلگر رمزارزها 💎\nمتخصص تحلیل تکنیکال',
            followers: '876',
            following: '234',
            badges: ['معامله‌گر حرفه‌ای'],
            location: 'تهران، ایران',
            links: { website: 'maryam.io', twitter: 'twitter.com/maryam', telegram: 't.me/maryam' },
            successRate: '۸۲٪',
            signalCount: '۹۴',
            experience: ['تحلیلگر ارشد - Pulset · ۲۰۲۳-اکنون'],
            education: ['کارشناسی ارشد مهندسی مالی - دانشگاه تهران'],
            privacy: { followers_visible: true }
        },
        'hossein': {
            name: 'حسین تحلیلگر',
            username: '@hossein_fx',
            avatar: 'ح',
            verified: false,
            bio: 'تحلیلگر فارکس | مدرس بازارهای مالی 📊\n۱۰ سال تجربه',
            followers: '۱.۴K',
            following: '۴۱۰',
            badges: ['تحلیلگر ارشد'],
            location: 'اصفهان، ایران',
            links: { website: 'hossein.ir', twitter: 'twitter.com/hossein' },
            successRate: '۷۶٪',
            signalCount: '۱۵۶',
            experience: ['مدرس بازارهای مالی - دانشگاه تهران · ۲۰۱۸-اکنون'],
            education: ['کارشناسی اقتصاد - دانشگاه اصفهان'],
            privacy: { followers_visible: false }
        }
    };
    return samples[username] || {
        name: 'کاربر',
        username: '@' + username,
        avatar: 'ع',
        verified: false,
        bio: '',
        followers: '۰',
        following: '۰',
        badges: [],
        location: '',
        links: {},
        successRate: '--',
        signalCount: '--',
        experience: [],
        education: [],
        privacy: { followers_visible: true }
    };
}

async function fetchProfile(username) {
    try {
        let data;
        if (username && username !== 'me') {
            data = await API.Profile.getByUsername ? await API.Profile.getByUsername(username) : null;
            if (!data) data = getSampleOtherProfile(username);
            isOwnProfile = false;
        } else {
            data = await API.Profile.get();
            if (!data) data = getUser();
            isOwnProfile = true;
        }
        return data;
    } catch (e) {
        console.warn('Fetch profile error, using fallback:', e);
        return username ? getSampleOtherProfile(username) : getUser();
    }
}

async function fetchUserPosts(userId) {
    try {
        const data = await API.Posts.getUserPosts ? await API.Posts.getUserPosts(userId) : [];
        return data.map(p => ({ ...p, liked: false, saved: false }));
    } catch (e) {
        console.warn('Fetch user posts error:', e);
        return [];
    }
}

async function fetchUserSignals(userId) {
    try {
        const data = await API.Signals.getUserSignals ? await API.Signals.getUserSignals(userId) : [];
        return data.map(s => ({ ...s, liked: false, saved: false }));
    } catch (e) {
        console.warn('Fetch user signals error:', e);
        return [];
    }
}

function getSampleFollowers() {
    return [
        { name: 'مریم تریدر', handle: '@mary_crypto', avatar: 'م', following: false },
        { name: 'حسین تحلیلگر', handle: '@hossein_fx', avatar: 'ح', following: true },
        { name: 'سارا اسکالپر', handle: '@sara_scalp', avatar: 'س', following: false },
        { name: 'رضا بورسی', handle: '@reza_bourse', avatar: 'ر', following: true }
    ];
}

function getSampleFollowing() {
    return [
        { name: 'رضا بورسی', handle: '@reza_bourse', avatar: 'ر', following: true },
        { name: 'نیما تریدر', handle: '@nima_fx', avatar: 'ن', following: true },
        { name: 'مریم تریدر', handle: '@mary_crypto', avatar: 'م', following: true }
    ];
}

function renderProfile() {
    if (!profileData) return;
    const p = profileData;

    // آواتار
    const avatarEl = document.getElementById('profileAvatar');
    if (p.avatar && p.avatar.startsWith('data:image')) {
        avatarEl.innerHTML = `<img src="${p.avatar}" alt="${p.name}">`;
    } else {
        avatarEl.textContent = p.avatar || getInitials(p.name);
    }

    // نام
    document.getElementById('profileName').innerHTML = p.name + (p.verified ? ' <span class="verified">✓</span>' : '');

    // هندل
    document.getElementById('profileHandle').textContent = p.username || '@user';

    // بیو
    document.getElementById('profileBio').innerHTML = p.bio ? p.bio.replace(/\n/g, '<br>') : '';

    // آمار
    document.getElementById('statPosts').textContent = p.posts || userPosts.length || '۰';
    document.getElementById('statFollowers').textContent = p.followers || '۰';
    document.getElementById('statFollowing').textContent = p.following || '۰';

    // تگ‌ها
    const badgesContainer = document.getElementById('badgesContainer');
    badgesContainer.innerHTML = p.badges && p.badges.length ?
        p.badges.map(b => `<span class="badge"><i class="fas fa-crown"></i> ${b}</span>`).join('') :
        '';

    // دکمه‌های اکشن
    const actions = document.getElementById('profileActions');
    if (isOwnProfile) {
        actions.innerHTML = `
            <button class="btn btn-primary-profile" onclick="window.location.href='edit-profile.html'">
                <i class="fas fa-pen"></i> ${t('edit_profile')}
            </button>
            <button class="btn btn-outline-profile" onclick="shareProfile()">
                <i class="fas fa-share-alt"></i> ${t('share')}
            </button>
        `;
    } else {
        const followText = isFollowing ? t('unfollow') : t('follow');
        const followClass = isFollowing ? 'btn-follow following' : 'btn-follow';
        actions.innerHTML = `
            <button class="btn ${followClass}" onclick="toggleFollow(this)">
                <i class="fas ${isFollowing ? 'fa-user-check' : 'fa-user-plus'}"></i><span>${followText}</span>
            </button>
            <button class="btn btn-primary-profile" onclick="window.location.href='chat.html?user='+encodeURIComponent('${p.username || ''}')">
                <i class="fas fa-comment"></i> ${t('msg')}
            </button>
            <button class="btn btn-outline-profile" onclick="shareProfile()">
                <i class="fas fa-share-alt"></i> ${t('share')}
            </button>
            <button class="btn-more" onclick="toggleMoreMenu(event)">
                <i class="fas fa-ellipsis-h"></i>
            </button>
            <div class="dropdown-menu" id="moreMenu">
                <button class="dropdown-item" onclick="reportUser()">
                    <i class="fas fa-flag"></i> ${t('report')}
                </button>
                <button class="dropdown-item" onclick="blockUser()">
                    <i class="fas fa-ban"></i> ${t('block')}
                </button>
            </div>
        `;
    }

    // اطلاعات درباره
    renderAbout(p);

    // پست‌ها، سیگنال‌ها و بازنشرها
    renderGrid('postsGrid', userPosts);
    renderGrid('signalsGrid', userSignals);
    renderReposts();

    // آمار تب‌ها
    document.getElementById('tabCountPosts').textContent = userPosts.length;
    document.getElementById('tabCountSignals').textContent = userSignals.length;
    document.getElementById('tabCountReposts').textContent = userReposts.length;
}

function renderAbout(p) {
    // تجربه
    const expList = document.getElementById('experienceList');
    expList.innerHTML = p.experience && p.experience.length ?
        p.experience.map(exp => `
            <div class="about-item">
                <div class="about-item-content">
                    <div class="about-item-title">${exp}</div>
                </div>
            </div>
        `).join('') :
        '<div style="color:var(--text3);font-size:13px;padding:4px 0;">هیچ سابقه کاری ثبت نشده</div>';

    // تحصیلات
    const eduList = document.getElementById('educationList');
    eduList.innerHTML = p.education && p.education.length ?
        p.education.map(edu => `
            <div class="about-item">
                <div class="about-item-content">
                    <div class="about-item-title">${edu}</div>
                </div>
            </div>
        `).join('') :
        '<div style="color:var(--text3);font-size:13px;padding:4px 0;">هیچ تحصیلی ثبت نشده</div>';

    // موقعیت
    document.getElementById('aboutLocation').textContent = p.location || 'موقعیت مکانی مشخص نشده';
    const now = new Date();
    document.getElementById('aboutLocationTime').textContent = 'ساعت محلی: ' +
        now.toLocaleTimeString(getCurrentLang() === 'fa' ? 'fa-IR' : 'en-US', { hour: '2-digit', minute: '2-digit' });

    // لینک‌ها
    const links = p.links || {};
    let linksHtml = '';
    if (links.website) linksHtml += `<a href="${links.website}" target="_blank"><i class="fas fa-globe"></i> ${links.website.replace('https://', '')}</a>`;
    if (links.twitter) linksHtml += `<a href="${links.twitter}" target="_blank"><i class="fab fa-twitter"></i> توییتر</a>`;
    if (links.telegram) linksHtml += `<a href="${links.telegram}" target="_blank"><i class="fab fa-telegram"></i> تلگرام</a>`;
    if (links.instagram) linksHtml += `<a href="${links.instagram}" target="_blank"><i class="fab fa-instagram"></i> اینستاگرام</a>`;
    if (links.linkedin) linksHtml += `<a href="${links.linkedin}" target="_blank"><i class="fab fa-linkedin"></i> لینکدین</a>`;
    if (!linksHtml) linksHtml = '<span style="color:var(--text3);font-size:13px;">هیچ لینکی ثبت نشده</span>';
    document.getElementById('aboutLinks').innerHTML = linksHtml;

    // آمار معاملات
    document.getElementById('tradingSuccess').textContent = p.successRate || '--';
    document.getElementById('tradingSignals').textContent = p.signalCount || '--';
}

function renderGrid(containerId, items) {
    const container = document.getElementById(containerId);
    if (!container) return;
    if (!items || !items.length) {
        container.innerHTML = `
            <div class="empty-state" style="text-align:center;padding:60px 20px;color:var(--text3);">
                <span class="icon" style="font-size:40px;display:block;margin-bottom:10px;opacity:0.5;">📭</span>
                <span>${t('no_posts')}</span>
            </div>
        `;
        return;
    }
    container.innerHTML = items.map(item => `
        <div class="grid-item" onclick="alert('جزئیات ${item.id}')">
            <img src="${item.image || 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=300&h=300&fit=crop'}" alt="${item.id}" loading="lazy">
            <div class="overlay">
                <span>❤️ ${item.likes || 0}</span>
                <span>💬 ${item.comments || 0}</span>
            </div>
        </div>
    `).join('');
}

function renderReposts() {
    const container = document.getElementById('repostsList');
    if (!container) return;
    if (!userReposts || !userReposts.length) {
        container.innerHTML = `
            <div class="empty-state" style="text-align:center;padding:60px 20px;color:var(--text3);">
                <span class="icon" style="font-size:40px;display:block;margin-bottom:10px;opacity:0.5;">🔄</span>
                <span>${t('no_reposts')}</span>
            </div>
        `;
        return;
    }
    container.innerHTML = userReposts.map(r => `
        <div class="repost-item" onclick="alert('بازنشر ${r.id}')">
            <div class="repost-avatar">${r.avatar || 'ع'}</div>
            <div class="repost-content">
                <div class="repost-name">${r.name || 'کاربر'}</div>
                <div class="repost-quote">"${r.quote || ''}"</div>
            </div>
        </div>
    `).join('');
}

async function toggleFollow(btn) {
    const isFollow = btn.classList.contains('following');
    if (isFollow) {
        await API.Profile.unfollow ? await API.Profile.unfollow(profileData.id) : null;
        isFollowing = false;
        btn.classList.remove('following');
        btn.innerHTML = `<i class="fas fa-user-plus"></i><span>${t('follow')}</span>`;
        showToast(t('unfollowed_toast'));
    } else {
        await API.Profile.follow ? await API.Profile.follow(profileData.id) : null;
        isFollowing = true;
        btn.classList.add('following');
        btn.innerHTML = `<i class="fas fa-user-check"></i><span>${t('unfollow')}</span>`;
        showToast(t('followed_toast'));
    }
}

function toggleMoreMenu(e) {
    e.stopPropagation();
    document.getElementById('moreMenu').classList.toggle('show');
}
document.addEventListener('click', () => {
    document.getElementById('moreMenu')?.classList.remove('show');
});

function reportUser() {
    showToast('گزارش ارسال شد');
    document.getElementById('moreMenu')?.classList.remove('show');
}

function blockUser() {
    showToast('کاربر بلاک شد');
    document.getElementById('moreMenu')?.classList.remove('show');
}

function switchTab(tab, btn) {
    currentTab = tab;
    document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
    if (btn) btn.classList.add('active');
    document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
    document.getElementById('tab-' + tab).classList.add('active');
}

function openSheet(type) {
    if (!isOwnProfile && !profileData?.privacy?.followers_visible) {
        showToast(t('privacy_hidden'));
        return;
    }
    const overlay = document.getElementById('sheetOverlay');
    let list = [],
        title = '';
    if (type === 'followers') {
        list = followersList.length ? followersList : getSampleFollowers();
        title = t('followers');
    } else if (type === 'following') {
        list = followingList.length ? followingList : getSampleFollowing();
        title = t('following');
    } else if (type === 'posts') {
        showToast('تعداد پست‌ها: ' + userPosts.length);
        return;
    }
    document.getElementById('sheetTitle').textContent = title;
    document.getElementById('sheetBody').innerHTML = list.map(item => `
        <div class="sheet-item">
            <div class="sheet-item-avatar">${item.avatar || 'ع'}</div>
            <div class="sheet-item-info">
                <div class="sheet-item-name">${item.name}</div>
                <div class="sheet-item-handle">${item.handle}</div>
            </div>
            <button class="sheet-item-btn ${item.following ? 'following' : ''}" onclick="event.stopPropagation();toggleSheetFollow(this)">
                ${item.following ? t('unfollow') : t('follow')}
            </button>
        </div>
    `).join('');
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
}

function closeSheet() {
    document.getElementById('sheetOverlay').classList.remove('open');
    document.body.style.overflow = '';
}

function toggleSheetFollow(btn) {
    const isFollow = btn.classList.contains('following');
    if (isFollow) {
        btn.classList.remove('following');
        btn.textContent = t('follow');
        showToast(t('unfollowed_toast'));
    } else {
        btn.classList.add('following');
        btn.textContent = t('unfollow');
        showToast(t('followed_toast'));
    }
}

function shareProfile() {
    const url = window.location.href;
    if (navigator.share) {
        navigator.share({
            title: t('share_title'),
            text: profileData?.name + ' در Pulset',
            url: url
        }).catch(() => {});
    } else {
        navigator.clipboard.writeText(url).then(() => {
            showToast(t('copy_link') + ' ✅');
        }).catch(() => {
            const ta = document.createElement('textarea');
            ta.value = url;
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
            showToast(t('copy_link') + ' ✅');
        });
    }
}

function toggleDrawer() { /* در main.js تعریف شده */ }
function closeDrawer() { /* در main.js تعریف شده */ }

document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    applyPageTranslations();

    const params = new URLSearchParams(window.location.search);
    const username = params.get('user');

    fetchProfile(username).then(data => {
        profileData = data;
        Promise.all([
            fetchUserPosts(data.id),
            fetchUserSignals(data.id)
        ]).then(([posts, signals]) => {
            userPosts = posts;
            userSignals = signals;
            userReposts = [];
            renderProfile();
        });
        followersList = getSampleFollowers();
        followingList = getSampleFollowing();
    });

    const path = window.location.pathname.split('/').pop() || 'profile.html';
    const pm = { dashboard: 'dashboard', signals_feed: 'signals_feed', markets: 'markets', explore: 'explore' };
    const cp = pm[path.split('.')[0]] || 'profile';
    document.querySelectorAll('.nav').forEach(n => n.classList.toggle('active', n.dataset.page === cp));
    if (cp === 'signal') document.getElementById('centerBtn')?.classList.add('active');

    console.log('✅ profile.js loaded');
});

window.switchTab = switchTab;
window.openSheet = openSheet;
window.closeSheet = closeSheet;
window.toggleFollow = toggleFollow;
window.toggleSheetFollow = toggleSheetFollow;
window.shareProfile = shareProfile;
window.toggleMoreMenu = toggleMoreMenu;
window.reportUser = reportUser;
window.blockUser = blockUser;
window.showToast = showToast;
window.toggleDrawer = toggleDrawer;
window.closeDrawer = closeDrawer;
