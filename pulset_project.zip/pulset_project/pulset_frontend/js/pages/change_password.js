// ================================================================
// change_password.js - اسکریپت صفحه تغییر رمز عبور
// ================================================================

// ===== ترجمه =====
const PAGE_TR = {
    fa: {
        pageTitle: 'تغییر رمز عبور',
        cancel: 'انصراف',
        save: 'ذخیره',
        current_password: 'رمز عبور فعلی',
        new_password: 'رمز عبور جدید',
        confirm_password: 'تکرار رمز عبور جدید',
        current_error: 'رمز عبور فعلی الزامی است.',
        new_error: 'رمز عبور جدید باید حداقل ۸ کاراکتر باشد.',
        confirm_error: 'رمز عبور و تکرار آن مطابقت ندارند.',
        success: '✅ رمز عبور با موفقیت تغییر کرد.',
        redirecting: 'در حال انتقال به تنظیمات...'
    },
    en: {
        pageTitle: 'Change Password',
        cancel: 'Cancel',
        save: 'Save',
        current_password: 'Current Password',
        new_password: 'New Password',
        confirm_password: 'Confirm New Password',
        current_error: 'Current password is required.',
        new_error: 'New password must be at least 8 characters.',
        confirm_error: 'Passwords do not match.',
        success: '✅ Password changed successfully.',
        redirecting: 'Redirecting to settings...'
    }
};

// ===== اعمال ترجمه =====
function applyPageTranslations() {
    const lang = getCurrentLang();
    const t = PAGE_TR[lang] || PAGE_TR.fa;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key]) el.textContent = t[key];
    });
}
window.applyPageTranslations = applyPageTranslations;

// ===== تابع t محلی =====
function t(key) {
    const lang = getCurrentLang();
    return PAGE_TR[lang]?.[key] || key;
}

// ===== اعتبارسنجی و ذخیره =====
function validateAndSave() {
    const current = document.getElementById('currentPassword').value.trim();
    const newPass = document.getElementById('newPassword').value.trim();
    const confirm = document.getElementById('confirmPassword').value.trim();

    // ریست خطاها
    document.querySelectorAll('.error-message').forEach(el => el.classList.remove('show'));

    let isValid = true;

    if (!current) {
        document.getElementById('currentError').classList.add('show');
        isValid = false;
    }

    if (newPass.length < 8) {
        document.getElementById('newError').classList.add('show');
        isValid = false;
    }

    if (newPass !== confirm) {
        document.getElementById('confirmError').classList.add('show');
        isValid = false;
    }

    if (!isValid) return;

    // ارسال به API
    const btn = document.querySelector('.save-btn');
    btn.disabled = true;
    btn.textContent = '⏳ در حال تغییر...';

    API.Profile.changePassword(current, newPass)
        .then(() => {
            showToast(t('success'));
            btn.textContent = t('save');
            btn.disabled = false;
            setTimeout(() => {
                window.location.href = 'settings.html';
            }, 1200);
        })
        .catch((err) => {
            console.error('Change password error:', err);
            showToast('❌ ' + (err.message || 'خطا در تغییر رمز عبور'), 3000);
            btn.textContent = t('save');
            btn.disabled = false;
        });
}

function showToast(msg, duration = 2500) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(window.toastTimer);
    window.toastTimer = setTimeout(() => t.classList.remove('show'), duration);
}

// ===== مقداردهی اولیه =====
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    const lang = getCurrentLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    applyPageTranslations();
    console.log('✅ change_password.js loaded');
});

// ===== خروجی توابع =====
window.validateAndSave = validateAndSave;
window.showToast = showToast;
window.toggleDark = toggleDark;
window.toggleLang = toggleLang;
