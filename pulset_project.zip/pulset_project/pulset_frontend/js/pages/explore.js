// ================================================================
// explore.js - اسکریپت صفحه اکسپلور
// ================================================================

let exploreItems = [],
    currentTab = 'all',
    page = 0,
    loading = false,
    hasMore = true,
    observer = null,
    searchQuery = '',
    viewMode = 'grid',
    adCounter = 0;

function applyPageTranslations() {
    const lang = getCurrentLang();
    const tr = {
        fa: {
            all: 'همه',
            posts: 'پست‌ها',
            signals: 'سیگنال‌ها',
            people: 'افراد',
            emp: 'هیچ محتوایی یافت نشد',
            end: 'همه محتواها را دیدید',
            vi: 'بازدید',
            share_title: 'اشتراک‌گذاری',
            copy_link: 'کپی لینک',
            share_native: 'اشتراک‌گذاری',
            close: 'بستن',
            post: 'پست'
        },
        en: {
            all: 'All',
            posts: 'Posts',
            signals: 'Signals',
            people: 'People',
            emp: 'No content found',
            end: 'You\'ve seen all',
            vi: 'Views',
            share_title: 'Share',
            copy_link: 'Copy link',
            share_native: 'Share',
            close: 'Close',
            post: 'Post'
        }
    };
    const t = tr[lang] || tr.fa;
    document.querySelectorAll('.tab-btn [data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key]) el.textContent = t[key];
    });
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key]) el.textContent = t[key];
    });
    document.getElementById('searchInput').placeholder = lang === 'fa' ? 'جستجوی پست، افراد، موضوعات...' : 'Search posts, people, topics...';
}
window.applyPageTranslations = applyPageTranslations;

function getSampleItems(tab, query) {
    const now = Date.now();
    const items = [
        { id: 1, type: 'post', user: 'علی معامله‌گر', username: '@ali_trades', avatar: 'ع', verified: true, time: now - 180000, text: 'بیت‌کوین به مقاومت ۶۸ هزار دلار رسیده. تحلیل تکنیکال نشان می‌دهد که در صورت شکست این سطح، هدف بعدی ۷۲ هزار دلار خواهد بود. #BTC #تحلیل', image: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=300&h=300&fit=crop', likes: 28, comments: 12, views: 245, liked: false, saved: false, online: true },
        { id: 2, type: 'post', user: 'مریم تریدر', username: '@mary_crypto', avatar: 'م', verified: false, time: now - 720000, text: 'سولانا الگوی مثلث صعودی داره! #SOL #تحلیل_تکنیکال', image: 'https://images.unsplash.com/photo-1535320903710-d993d3d77d29?w=300&h=300&fit=crop', likes: 15, comments: 8, views: 180, liked: false, saved: false, online: false },
        { id: 3, type: 'signal', user: 'نیما تحلیل‌گر', username: '@nima_charts', avatar: 'ن', verified: true, time: now - 600000, coin: 'بیت‌کوین/USDT', type_signal: 'buy', entry: '$67,850', tp: '$69,200', sl: '$67,100', confidence: 85, views: 512, likes: 34, comments: 8, liked: false, saved: false, online: true },
        { id: 5, type: 'person', user: 'رضا بورسی', username: '@reza_bourse', avatar: 'ر', verified: true, bio: 'تحلیلگر بورس تهران | ۱۰ سال تجربه | #بورس #تحلیل', followers: 1245, following: 320, followed: false, online: true }
    ];
    let filtered = items;
    if (tab === 'posts') filtered = items.filter(i => i.type === 'post');
    else if (tab === 'signals') filtered = items.filter(i => i.type === 'signal');
    else if (tab === 'people') filtered = items.filter(i => i.type === 'person');
    if (query) filtered = filtered.filter(i => {
        const s = (i.user + (i.username || '') + (i.text || '') + (i.coin || '') + (i.bio || '')).toLowerCase();
        return s.includes(query.toLowerCase());
    });
    filtered.sort((a, b) => b.time - a.time);
    return filtered;
}

async function fetchExplore(tab, query, pageNum) {
    try {
        let data = [];
        if (tab === 'all' || tab === 'posts') {
            const posts = await API.Posts.get(tab === 'all' ? 'for-you' : 'for-you', pageNum, 15);
            data = data.concat(posts.posts || posts || []);
        }
        if (tab === 'all' || tab === 'signals') {
            const signals = await API.Signals.get('public', pageNum, 10);
            data = data.concat(signals.signals || signals || []);
        }
        if (tab === 'all' || tab === 'people') {
            const people = getSampleItems('people', query);
            data = data.concat(people);
        }
        return data.map(item => ({
            id: item.id || Date.now() + Math.random(),
            type: item.type || (item.entry ? 'signal' : 'post'),
            user: item.user || 'کاربر',
            username: item.username || '',
            avatar: item.avatar || 'ع',
            verified: item.verified || false,
            time: item.time || Date.now(),
            text: item.text || '',
            image: item.image || (item.media && item.media.length > 0 && item.media[0].type === 'image' ? item.media[0].url : null),
            likes: item.likes || 0,
            comments: item.comments || 0,
            views: item.views || 0,
            liked: item.liked || false,
            saved: item.saved || false,
            online: item.online || false,
            coin: item.coin || '',
            type_signal: item.type_signal || item.type || '',
            entry: item.entry || '',
            tp: item.tp || '',
            sl: item.sl || '',
            confidence: item.confidence || 0,
            bio: item.bio || '',
            followers: item.followers || 0,
            following: item.following || 0,
            followed: item.followed || false
        }));
    } catch (e) {
        console.warn('Explore fetch error, using fallback:', e);
        return getSampleItems(tab, query);
    }
}

function createGridItem(item, isList) {
    const typeEmoji = { post: '📝', signal: '⚡', person: '👤' };
    let imgSrc = '',
        overlayText = '',
        title = '',
        sub = '';
    if (item.type === 'post' || item.type === 'signal') {
        imgSrc = item.image || 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=300&h=300&fit=crop';
        overlayText = `❤️ ${item.likes || 0}`;
        title = item.user;
        sub = item.text ? item.text.substring(0, 60) + (item.text.length > 60 ? '...' : '') : (item.coin || '');
    } else {
        imgSrc = 'https://i.pravatar.cc/300?img=' + (item.id % 70 + 10);
        overlayText = `👥 ${item.followers || 0}`;
        title = item.user;
        sub = item.bio || '';
    }
    if (isList) {
        return `<div class="grid-item" onclick="openDetail(${item.id})" data-id="${item.id}">
            <img src="${imgSrc}" alt="${item.user}" loading="lazy" />
            <div class="item-info"><div class="title">${title}</div><div class="sub">${sub}</div></div>
            <div class="type-badge">${typeEmoji[item.type] || '📌'}</div>
        </div>`;
    }
    return `<div class="grid-item" onclick="openDetail(${item.id})" data-id="${item.id}">
        <img src="${imgSrc}" alt="${item.user}" loading="lazy" />
        <div class="type-badge">${typeEmoji[item.type] || '📌'}</div>
        <div class="overlay">${overlayText}</div>
    </div>`;
}

function renderGrid(showSkeleton) {
    const container = document.getElementById('exploreGrid');
    if (!container) return;
    if (showSkeleton) {
        container.innerHTML = '<div class="skeleton-grid">' + Array(12).fill('<div class="skeleton-item"></div>').join('') + '</div>';
        return;
    }
    const isList = viewMode === 'list';
    const feed = document.getElementById('feedContainer');
    if (isList) feed.classList.add('list-view');
    else feed.classList.remove('list-view');
    const items = exploreItems.slice(0, page * 15 + 15);
    container.innerHTML = '';
    if (!items.length) {
        container.innerHTML = `<div class="empty-state"><span class="icon">🔍</span>${t('emp')}</div>`;
        hasMore = false;
        return;
    }
    items.forEach((item, i) => {
        container.insertAdjacentHTML('beforeend', createGridItem(item, isList));
        if (!isList && (i + 1) % 6 === 0) {
            const posId = (adCounter % 2 === 0) ? 'pos-article-display-card-120295' : 'pos-article-display-card-120298';
            adCounter++;
            container.insertAdjacentHTML('beforeend', `<div class="sponsor-grid-item"><div class="sponsor-container"><div id="${posId}"></div></div></div>`);
        }
    });
    hasMore = items.length < exploreItems.length;
    const endMsg = document.getElementById('endMessage');
    if (endMsg) { if (!hasMore) endMsg.classList.add('show');
    else endMsg.classList.remove('show'); }
    setupObserver();
}

async function initExplore() {
    page = 0;
    const data = await fetchExplore(currentTab, searchQuery, 0);
    exploreItems = data;
    renderGrid(false);
    updateCounts();
}

async function loadMore() {
    if (loading || !hasMore) return;
    loading = true;
    const l = document.getElementById('loaderContainer');
    if (l) l.classList.add('show');
    page++;
    const data = await fetchExplore(currentTab, searchQuery, page);
    if (data.length) {
        exploreItems = [...exploreItems, ...data];
        renderGrid(false);
    } else {
        hasMore = false;
    }
    if (l) l.classList.remove('show');
    loading = false;
}

function setupObserver() {
    if (observer) observer.disconnect();
    const l = document.getElementById('loaderContainer');
    observer = new IntersectionObserver(e => {
        if (e[0].isIntersecting && !loading && hasMore) loadMore();
    }, { threshold: 0.1 });
    if (l) observer.observe(l);
}

function updateCounts() {
    const counts = { all: exploreItems.length };
    ['posts', 'signals', 'people'].forEach(t => {
        counts[t] = exploreItems.filter(i => i.type === t).length;
    });
    document.querySelectorAll('.tab-btn').forEach(b => {
        const t = b.dataset.tab;
        const s = b.querySelector('.count');
        if (s) s.textContent = counts[t] || 0;
    });
}

function switchTab(tab, btn) {
    currentTab = tab;
    page = 0;
    hasMore = true;
    adCounter = 0;
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    initExplore();
}

function handleSearch() {
    searchQuery = document.getElementById('searchInput').value.trim();
    page = 0;
    hasMore = true;
    initExplore();
}

let detailItems = [],
    detailIndex = 0,
    detailShareUrl = '';

function openDetail(id) {
    const overlay = document.getElementById('detailOverlay');
    const feed = document.getElementById('detailFeed');
    detailItems = exploreItems;
    detailIndex = detailItems.findIndex(i => i.id === id);
    if (detailIndex === -1) detailIndex = 0;
    detailShareUrl = window.location.href + '?detail=' + id;
    renderDetailItems();
    overlay.classList.add('show');
    document.body.style.overflow = 'hidden';
}

function closeDetail() {
    document.getElementById('detailOverlay').classList.remove('show');
    document.body.style.overflow = '';
}

function renderDetailItems() {
    const feed = document.getElementById('detailFeed');
    const items = detailItems.slice(detailIndex);
    feed.innerHTML = items.map(item => {
        const verified = item.verified ? '<span class="v">✓</span>' : '';
        const liked = item.liked ? 'liked' : '';
        const saved = item.saved ? 'saved' : '';
        let content = '';
        if (item.type === 'signal') {
            const typeLabel = item.type_signal === 'buy' ? 'خرید' : 'فروش';
            const typeClass = item.type_signal === 'buy' ? 'buy' : 'sell';
            content = `<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px"><span class="signal-badge ${typeClass}">${typeLabel}</span>${item.coin ? `<span style="font-size:15px;font-weight:700;color:var(--text)">${item.coin}</span>` : ''}</div>
            <div class="signal-details"><div class="signal-detail-item"><div class="signal-detail-label">ورود</div><div class="signal-detail-value">${item.entry}</div></div><div class="signal-detail-item"><div class="signal-detail-label">حد سود</div><div class="signal-detail-value" style="color:#2e7d32;">${item.tp}</div></div><div class="signal-detail-item"><div class="signal-detail-label">حد ضرر</div><div class="signal-detail-value" style="color:#c62828;">${item.sl}</div></div></div>
            <div class="signal-confidence"><span>اطمینان</span><div class="bar"><div class="fill" style="width:${item.confidence}%;"></div></div><span class="percent">${item.confidence}%</span></div>`;
        } else if (item.type === 'post') {
            const textWithLinks = (item.text || '').replace(/#(\w+)/g, '<span class="hashtag" onclick="event.stopPropagation();searchHashtag(\'$1\')">#$1</span>').replace(/@(\w+)/g, '<span class="mention" onclick="event.stopPropagation();goToProfile(\'$1\')">@$1</span>');
            content = `<div class="post-txt">${textWithLinks}</div>${item.image ? `<img class="post-img" src="${item.image}" alt="${item.user}" loading="lazy" />` : ''}`;
        } else if (item.type === 'person') {
            return `<div class="detail-item"><div class="person-row"><div class="person-avatar" onclick="goToProfile('${item.username ? item.username.replace('@','') : ''}')">${item.avatar || 'ع'}</div><div class="person-info" onclick="goToProfile('${item.username ? item.username.replace('@','') : ''}')"><div class="person-name">${item.user} ${verified}</div><div class="person-handle">${item.username || ''}</div><div class="person-bio">${item.bio ? item.bio.replace(/#(\w+)/g, '<span class="hashtag" onclick="event.stopPropagation();searchHashtag(\'$1\')">#$1</span>') : ''}</div></div><button class="person-follow ${item.followed ? 'following' : ''}" onclick="event.stopPropagation();toggleDetailFollow(${item.id},this)">${item.followed ? 'لغو دنبال' : 'دنبال کردن'}</button></div></div>`;
        }
        return `<div class="detail-item"><div class="post-h"><div class="post-a" onclick="goToProfile('${item.username ? item.username.replace('@','') : ''}')">${item.avatar || 'ع'}</div><div class="post-ui" onclick="goToProfile('${item.username ? item.username.replace('@','') : ''}')"><div class="post-un">${item.user} ${verified}</div><div class="post-usr">${item.username || ''}</div></div><span style="font-size:11px;color:var(--text3);margin-right:auto;">${fmtTime(item.time)}</span></div>${content}<div class="post-a2"><button class="btn like ${liked}" onclick="event.stopPropagation();toggleDetailLike(${item.id})"><svg class="i" viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg><span>${item.likes}</span></button><button class="btn" onclick="event.stopPropagation();alert('${t('cm')}')"><svg class="i" viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg><span>${item.comments}</span></button><button class="btn bookmark ${saved}" onclick="event.stopPropagation();toggleDetailSave(${item.id})"><svg class="i" viewBox="0 0 24 24"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg></button><span class="views">${t('vi')} ${item.views}</span></div></div>`;
    }).join('');
}

async function toggleDetailLike(id) {
    const item = detailItems.find(i => i.id === id);
    if (!item) return;
    try {
        const data = await API.Posts.like(id);
        item.liked = data.liked;
        item.likes = data.likes;
    } catch (e) {
        item.liked = !item.liked;
        item.likes += item.liked ? 1 : -1;
    }
    renderDetailItems();
}
async function toggleDetailSave(id) {
    const item = detailItems.find(i => i.id === id);
    if (!item) return;
    try {
        const data = await API.Posts.bookmark(id);
        item.saved = data.saved;
    } catch (e) {
        item.saved = !item.saved;
    }
    renderDetailItems();
}
async function toggleDetailFollow(id, btn) {
    const item = detailItems.find(i => i.id === id);
    if (!item) return;
    try {
        await API.Profile.follow ? await API.Profile.follow(id) : null;
        item.followed = !item.followed;
    } catch (e) {
        item.followed = !item.followed;
    }
    btn.textContent = item.followed ? 'لغو دنبال' : 'دنبال کردن';
    btn.classList.toggle('following', item.followed);
}

function shareDetail() {
    document.getElementById('shareModal').classList.add('show');
}
function closeShareModal() {
    document.getElementById('shareModal').classList.remove('show');
}
function copyLink() {
    const url = detailShareUrl || window.location.href;
    navigator.clipboard.writeText(url).then(() => {
        showToast('✅ لینک کپی شد!');
        closeShareModal();
    }).catch(() => {
        const ta = document.createElement('textarea');
        ta.value = url;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        showToast('✅ لینک کپی شد!');
        closeShareModal();
    });
}
function shareNative() {
    if (navigator.share) {
        navigator.share({ title: 'Pulset', text: 'محتوا در Pulset', url: detailShareUrl || window.location.href }).catch(() => {}).finally(closeShareModal);
    } else {
        copyLink();
    }
}

function searchHashtag(tag) {
    document.getElementById('searchInput').value = '#' + tag;
    handleSearch();
}
function goToProfile(username) {
    window.location.href = 'profile.html?user=' + username;
}

function toggleDrawer() { /* در main.js تعریف شده */ }
function closeDrawer() { /* در main.js تعریف شده */ }

document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    applyPageTranslations();
    const savedTab = localStorage.getItem('pulset_explore_tab') || 'all';
    const savedView = localStorage.getItem('pulset_explore_view') || 'grid';
    currentTab = savedTab;
    viewMode = savedView;
    document.querySelectorAll('.tab-btn').forEach(b => {
        b.classList.toggle('active', b.dataset.tab === savedTab);
    });
    initExplore();
    const path = window.location.pathname.split('/').pop() || 'explore.html';
    const pm = { dashboard: 'dashboard', signals_feed: 'signals_feed', markets: 'markets', explore: 'explore' };
    const cp = pm[path.split('.')[0]] || 'explore';
    document.querySelectorAll('.nav').forEach(n => n.classList.toggle('active', n.dataset.page === cp));
    if (cp === 'signal') document.getElementById('centerBtn')?.classList.add('active');
    console.log('✅ explore.js loaded');
});

window.switchTab = switchTab;
window.handleSearch = handleSearch;
window.openDetail = openDetail;
window.closeDetail = closeDetail;
window.toggleDetailLike = toggleDetailLike;
window.toggleDetailSave = toggleDetailSave;
window.toggleDetailFollow = toggleDetailFollow;
window.shareDetail = shareDetail;
window.closeShareModal = closeShareModal;
window.copyLink = copyLink;
window.shareNative = shareNative;
window.searchHashtag = searchHashtag;
window.goToProfile = goToProfile;
window.toggleDrawer = toggleDrawer;
window.closeDrawer = closeDrawer;
window.showToast = showToast;
