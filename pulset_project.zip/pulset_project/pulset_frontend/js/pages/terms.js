// ================================================================
// terms.js - اسکریپت صفحه شرایط استفاده
// ================================================================

// ===== ترجمه =====
const PAGE_TR = {
    fa: {
        pageTitle: 'شرایط استفاده',
        section1_title: 'پذیرش شرایط',
        section1_text: 'با ثبت‌نام، دسترسی و استفاده از پلتفرم Pulset، شما تأیید می‌کنید که این شرایط را به‌طور کامل مطالعه کرده و بدون قید و شرط پذیرفته‌اید.',
        section2_title: 'تعریف خدمات',
        section2_text: 'Pulset خدماتی شامل ارائه سیگنال‌ها و تحلیل‌های مبتنی بر هوش مصنوعی، بستری برای شبکه‌سازی اجتماعی معامله‌گران و داده‌های لحظه‌ای بازار ارائه می‌دهد.',
        section3_title: 'حساب کاربری',
        section3_text: 'کاربر موظف به ارائه اطلاعات صحیح هنگام ثبت‌نام است. مسئولیت حفظ امنیت و محرمانگی اطلاعات ورود بر عهده کاربر می‌باشد.',
        section4_title: 'قوانین استفاده',
        rule1: 'نقض قوانین جمهوری اسلامی ایران و قوانین بین‌المللی',
        rule2: 'انتشار محتوای توهین‌آمیز، نژادپرستانه یا خشونت‌آمیز',
        rule3: 'تلاش برای نفوذ، هک یا ایجاد اختلال در عملکرد',
        section5_title: 'مالکیت فکری',
        section5_text: 'کلیه حقوق مالکیت معنوی، از جمله برند Pulset، لوگو، کدهای نرم‌افزاری، الگوریتم‌های هوش مصنوعی، طراحی رابط کاربری و محتوای اختصاصی، متعلق به شرکت RA است.',
        section6_title: 'سلب مسئولیت مالی',
        section6_text: 'Pulset صرفاً یک ارائه‌دهنده ابزارهای تحلیلی است و به هیچ وجه مشاور مالی محسوب نمی‌شود. تمامی سیگنال‌ها جنبه آموزشی دارند و کاربر شخصاً مسئول تصمیمات معاملاتی خود می‌باشد.',
        last_update: 'آخرین به‌روزرسانی: تابستان ۱۴۰۵'
    },
    en: {
        pageTitle: 'Terms of Service',
        section1_title: 'Acceptance of Terms',
        section1_text: 'By registering, accessing and using the Pulset platform, you confirm that you have read and agree to these terms without any reservation.',
        section2_title: 'Definition of Services',
        section2_text: 'Pulset provides services including AI-based signals and analysis, a social networking platform for traders, and real-time market data.',
        section3_title: 'User Account',
        section3_text: 'The user is required to provide correct information during registration. The user is responsible for maintaining the security and confidentiality of login information.',
        section4_title: 'Rules of Use',
        rule1: 'Violation of the laws of the Islamic Republic of Iran and international laws',
        rule2: 'Publishing offensive, racist or violent content',
        rule3: 'Attempting to infiltrate, hack or disrupt the operation',
        section5_title: 'Intellectual Property',
        section5_text: 'All intellectual property rights, including the Pulset brand, logo, software code, AI algorithms, UI design and proprietary content, belong to RA Company.',
        section6_title: 'Financial Disclaimer',
        section6_text: 'Pulset is solely a provider of analytical tools and is by no means a financial advisor. All signals are for educational purposes and the user is personally responsible for their trading decisions.',
        last_update: 'Last updated: Summer 2025'
    }
};

// ===== اعمال ترجمه =====
function applyPageTranslations() {
    const lang = getCurrentLang();
    const t = PAGE_TR[lang] || PAGE_TR.fa;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key]) el.textContent = t[key];
    });
}
window.applyPageTranslations = applyPageTranslations;

// ===== مقداردهی اولیه =====
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    const lang = getCurrentLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    applyPageTranslations();
    console.log('✅ terms.js loaded');
});

// ===== خروجی توابع =====
window.showToast = showToast;
window.toggleDark = toggleDark;
window.toggleLang = toggleLang;
