// ================================================================
// edit_profile.js - اسکریپت صفحه ویرایش پروفایل
// ================================================================

// ===== ترجمه =====
const PAGE_TR = {
    fa: {
        pageTitle: 'ویرایش پروفایل',
        save: 'ذخیره',
        remove_photo: 'حذف عکس',
        basic_info: 'اطلاعات پایه',
        display_name: 'نام نمایشی',
        display_name_error: 'نام نمایشی نمی‌تواند خالی باشد',
        username: 'نام کاربری',
        username_error: 'فقط حروف انگلیسی، اعداد و زیرخط مجاز است',
        bio: 'بیوگرافی',
        location: 'موقعیت مکانی',
        links: 'لینک‌ها',
        website: 'وب‌سایت',
        twitter: 'توییتر',
        telegram: 'تلگرام',
        instagram: 'اینستاگرام',
        linkedin: 'لینکدین',
        link_error: 'لینک معتبر وارد کنید',
        badges: 'تگ‌های حرفه‌ای',
        badges_label: 'تگ‌ها',
        add: 'افزودن',
        education_title: 'تحصیلات',
        education_label: 'سوابق تحصیلی',
        experience_title: 'سابقه کاری',
        experience_label: 'سوابق کاری',
        trading_stats: 'آمار معاملات',
        success_rate: 'درصد موفقیت',
        range_error: 'عدد بین ۰ تا ۱۰۰ وارد کنید',
        signal_count: 'تعداد سیگنال‌ها',
        positive_error: 'عدد مثبت وارد کنید',
        export_json: '📤 دریافت JSON',
        confirm_title: 'آیا مطمئنید؟',
        confirm_desc: 'تغییرات ذخیره نشده‌اند. در صورت بازگشت، از دست می‌روند.',
        cancel: 'انصراف',
        confirm: 'بازگشت',
        success_title: '✅ ذخیره شد!',
        success_desc: 'پروفایل با موفقیت به‌روزرسانی شد.',
        go_profile: 'بازگشت به پروفایل',
        crop_title: 'برش عکس'
    },
    en: {
        pageTitle: 'Edit Profile',
        save: 'Save',
        remove_photo: 'Remove Photo',
        basic_info: 'Basic Info',
        display_name: 'Display Name',
        display_name_error: 'Display name is required',
        username: 'Username',
        username_error: 'Only letters, numbers, underscore allowed',
        bio: 'Bio',
        location: 'Location',
        links: 'Links',
        website: 'Website',
        twitter: 'Twitter',
        telegram: 'Telegram',
        instagram: 'Instagram',
        linkedin: 'LinkedIn',
        link_error: 'Enter a valid link',
        badges: 'Badges',
        badges_label: 'Badges',
        add: 'Add',
        education_title: 'Education',
        education_label: 'Education',
        experience_title: 'Experience',
        experience_label: 'Experience',
        trading_stats: 'Trading Stats',
        success_rate: 'Success Rate',
        range_error: 'Enter a number between 0-100',
        signal_count: 'Signal Count',
        positive_error: 'Enter a positive number',
        export_json: '📤 Export JSON',
        confirm_title: 'Are you sure?',
        confirm_desc: 'Unsaved changes will be lost.',
        cancel: 'Cancel',
        confirm: 'Go back',
        success_title: '✅ Saved!',
        success_desc: 'Profile updated successfully.',
        go_profile: 'Go to Profile',
        crop_title: 'Crop Image'
    }
};

// ===== متغیرها =====
let avatarDataUrl = '';
let hasAvatar = false;
let cropper = null;
let badges = [];
let educationList = [];
let experienceList = [];
let originalProfile = {};

// ===== اعمال ترجمه =====
function applyPageTranslations() {
    const lang = getCurrentLang();
    const t = PAGE_TR[lang] || PAGE_TR.fa;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key]) el.textContent = t[key];
    });
}
window.applyPageTranslations = applyPageTranslations;

// ===== تابع t محلی =====
function t(key) {
    const lang = getCurrentLang();
    return PAGE_TR[lang]?.[key] || key;
}

// ===== توابع کمکی =====
function $(id) { return document.getElementById(id); }

function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(window.toastTimer);
    window.toastTimer = setTimeout(() => t.classList.remove('show'), 3000);
}

function updateFallback() {
    const name = $('displayName').value.trim() || 'کاربر';
    $('avatarFallback').textContent = name.charAt(0).toUpperCase();
}

function updateCharCount() {
    $('bioCharCount').textContent = $('bio').value.length;
}

function openModal(id) { document.getElementById(id).classList.add('show'); }
function closeModal(id) { document.getElementById(id).classList.remove('show'); }

// ===== آواتار =====
function setAvatar(url) {
    avatarDataUrl = url;
    const img = $('avatarImg');
    const fb = $('avatarFallback');
    const preview = $('avatarPreview');
    const btn = $('removeAvatarBtn');
    if (url) {
        img.src = url;
        img.style.display = 'block';
        fb.style.display = 'none';
        preview.classList.add('has-image');
        hasAvatar = true;
        btn.classList.remove('disabled');
    } else {
        img.src = '';
        img.style.display = 'none';
        fb.style.display = 'block';
        preview.classList.remove('has-image');
        hasAvatar = false;
        btn.classList.add('disabled');
    }
    updatePreview();
}

function setAvatarFromUrl(url) {
    if (!confirm('آیا این عکس را به عنوان آواتار انتخاب می‌کنید؟')) return;
    setAvatar(url);
    showToast('✅ عکس انتخاب شد');
}

function removeAvatar() {
    if (!hasAvatar) return;
    if (!confirm('آیا از حذف عکس مطمئنید؟')) return;
    setAvatar('');
    updateFallback();
    showToast('🗑️ عکس حذف شد.');
}

// ===== کراپر =====
function handleAvatarUpload(e) {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
        showToast('⚠️ حجم تصویر نباید بیشتر از ۵ مگابایت باشد.');
        e.target.value = '';
        return;
    }
    const reader = new FileReader();
    reader.onload = function(ev) {
        const img = $('cropImage');
        img.src = ev.target.result;
        img.onload = function() { openCropModal(); };
        setTimeout(function() { if (!cropper) openCropModal(); }, 300);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
}

function openCropModal() {
    $('cropModal').classList.add('show');
    setTimeout(function() {
        if (cropper) cropper.destroy();
        try {
            cropper = new Cropper($('cropImage'), {
                aspectRatio: 1,
                viewMode: 1,
                autoCropArea: 0.8,
                background: false,
                responsive: true,
            });
        } catch (err) {
            console.error('Cropper error:', err);
            showToast('⚠️ خطا در بارگذاری برش‌دهنده');
        }
    }, 200);
}

function closeCrop() {
    $('cropModal').classList.remove('show');
    if (cropper) { cropper.destroy();
        cropper = null; }
}

function applyCrop() {
    if (!cropper) { showToast('⚠️ خطا در برش'); return; }
    try {
        const canvas = cropper.getCroppedCanvas({ width: 400, height: 400 });
        const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
        setAvatar(dataUrl);
        closeCrop();
        showToast('✅ عکس برش خورد!');
    } catch (err) {
        console.error(err);
        showToast('⚠️ خطا در برش');
    }
}

// ===== لیست‌ها =====
function renderList(containerId, items) {
    const container = $(containerId);
    if (!container) return;
    container.innerHTML = items.map(function(item, idx) {
        return '<span class="list-item">' +
            item +
            '<button class="remove" onclick="removeItem(\'' + containerId + '\',' + idx + ')">' +
            '<i class="fas fa-times"></i></button></span>';
    }).join('');
}

function renderAll() {
    renderList('badgesContainer', badges);
    renderList('educationContainer', educationList);
    renderList('experienceContainer', experienceList);
}

function addItem(list, inputId, containerId) {
    const input = $(inputId);
    const val = input.value.trim();
    if (!val) { showToast('⚠️ لطفاً مقداری وارد کنید'); return; }
    if (list.indexOf(val) !== -1) { showToast('⚠️ این مورد قبلاً اضافه شده'); return; }
    if (list.length >= 20) { showToast('⚠️ حداکثر ۲۰ مورد'); return; }
    list.push(val);
    input.value = '';
    renderList(containerId, list);
    showToast('➕ اضافه شد: ' + val);
}

function removeItem(containerId, index) {
    let list;
    if (containerId === 'badgesContainer') list = badges;
    else if (containerId === 'educationContainer') list = educationList;
    else if (containerId === 'experienceContainer') list = experienceList;
    else return;
    list.splice(index, 1);
    renderList(containerId, list);
}

function addBadge() { addItem(badges, 'badgeInput', 'badgesContainer'); }
function addEducation() { addItem(educationList, 'educationInput', 'educationContainer'); }
function addExperience() { addItem(experienceList, 'experienceInput', 'experienceContainer'); }

// ===== اعتبارسنجی =====
function validateField(fieldId) {
    const input = $(fieldId);
    const error = $(fieldId + 'Error');
    if (!input || !error) return;
    const val = input.value.trim();
    let valid = true;
    switch (fieldId) {
        case 'displayName':
            valid = val.length > 0;
            break;
        case 'username':
            valid = val === '' || /^[a-zA-Z0-9_]+$/.test(val);
            break;
        case 'website':
        case 'twitter':
        case 'telegram':
        case 'instagram':
        case 'linkedin':
            valid = val === '' || /^https?:\/\/[^\s]+$/.test(val);
            break;
        case 'successRate':
            valid = val === '' || (!isNaN(val) && Number(val) >= 0 && Number(val) <= 100);
            break;
        case 'signalCount':
            valid = val === '' || (!isNaN(val) && Number(val) >= 0);
            break;
        default:
            valid = true;
    }
    if (!valid) error.classList.add('show');
    else error.classList.remove('show');
    return valid;
}

function validateAll() {
    const fields = ['displayName', 'username', 'website', 'twitter', 'telegram', 'instagram', 'linkedin',
        'successRate', 'signalCount'
    ];
    let allValid = true;
    fields.forEach(function(id) {
        if (!validateField(id)) allValid = false;
    });
    return allValid;
}

// ===== پیش‌نمایش =====
function updatePreview() {
    // فقط آواتار و نام را به‌روز می‌کند (در بخش آواتار انجام می‌شود)
}

// ===== بارگذاری پروفایل =====
async function loadProfile() {
    try {
        const data = await API.Profile.get();
        if (data) {
            originalProfile = data;
            $('displayName').value = data.displayName || '';
            $('username').value = data.username || '';
            $('bio').value = data.bio || '';
            $('location').value = data.location || '';
            $('website').value = data.website || '';
            $('twitter').value = data.twitter || '';
            $('telegram').value = data.telegram || '';
            $('instagram').value = data.instagram || '';
            $('linkedin').value = data.linkedin || '';
            $('successRate').value = data.successRate || '';
            $('signalCount').value = data.signalCount || '';
            badges = data.badges || [];
            educationList = data.education || [];
            experienceList = data.experience || [];
            if (data.avatar) setAvatar(data.avatar);
            else setAvatar('');
            renderAll();
            updateFallback();
            updateCharCount();
            updatePreview();
        }
    } catch (e) {
        console.warn('Load profile error:', e);
        // Fallback به localStorage
        const saved = localStorage.getItem('pulset_profile');
        if (saved) {
            const data = JSON.parse(saved);
            $('displayName').value = data.displayName || '';
            $('username').value = data.username || '';
            $('bio').value = data.bio || '';
            $('location').value = data.location || '';
            $('website').value = data.website || '';
            $('twitter').value = data.twitter || '';
            $('telegram').value = data.telegram || '';
            $('instagram').value = data.instagram || '';
            $('linkedin').value = data.linkedin || '';
            $('successRate').value = data.successRate || '';
            $('signalCount').value = data.signalCount || '';
            badges = data.badges || [];
            educationList = data.education || [];
            experienceList = data.experience || [];
            if (data.avatar) setAvatar(data.avatar);
            else setAvatar('');
            renderAll();
            updateFallback();
            updateCharCount();
            updatePreview();
        }
    }
}

// ===== ذخیره =====
async function saveProfile() {
    if (!validateAll()) {
        showToast('⚠️ لطفاً خطاهای فرم را اصلاح کنید');
        return;
    }

    const data = {
        displayName: $('displayName').value.trim() || 'کاربر',
        username: $('username').value.trim() || '@user',
        bio: $('bio').value.trim(),
        location: $('location').value.trim(),
        website: $('website').value.trim(),
        twitter: $('twitter').value.trim(),
        telegram: $('telegram').value.trim(),
        instagram: $('instagram').value.trim(),
        linkedin: $('linkedin').value.trim(),
        badges: badges,
        education: educationList,
        experience: experienceList,
        successRate: $('successRate').value.trim(),
        signalCount: $('signalCount').value.trim(),
        avatar: avatarDataUrl,
    };

    try {
        await API.Profile.update(data);
        localStorage.setItem('pulset_profile', JSON.stringify(data));
        $('successModal').classList.add('show');
        showToast('✅ پروفایل ذخیره شد!');
    } catch (e) {
        console.warn('Update profile error:', e);
        localStorage.setItem('pulset_profile', JSON.stringify(data));
        $('successModal').classList.add('show');
        showToast('✅ پروفایل ذخیره شد!');
    }
}

// ===== خروجی JSON =====
function exportJSON() {
    const data = {
        displayName: $('displayName').value.trim() || 'کاربر',
        username: $('username').value.trim() || '@user',
        bio: $('bio').value.trim(),
        location: $('location').value.trim(),
        website: $('website').value.trim(),
        twitter: $('twitter').value.trim(),
        telegram: $('telegram').value.trim(),
        instagram: $('instagram').value.trim(),
        linkedin: $('linkedin').value.trim(),
        badges: badges,
        education: educationList,
        experience: experienceList,
        successRate: $('successRate').value.trim(),
        signalCount: $('signalCount').value.trim(),
        avatar: avatarDataUrl ? '(base64 image)' : null,
    };
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'profile_data.json';
    a.click();
    URL.revokeObjectURL(url);
    showToast('📤 JSON دانلود شد');
}

// ===== برگشت =====
function confirmBack() {
    $('confirmModal').classList.add('show');
}

function closeConfirm() {
    $('confirmModal').classList.remove('show');
}

function doBack() {
    $('confirmModal').classList.remove('show');
    window.history.back();
}

function goProfile() {
    $('successModal').classList.remove('show');
    window.location.href = 'profile.html';
}

// ===== مقداردهی اولیه =====
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    const lang = getCurrentLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    applyPageTranslations();

    loadProfile();
    console.log('✅ edit_profile.js loaded');
});

// ===== خروجی توابع =====
window.addBadge = addBadge;
window.addEducation = addEducation;
window.addExperience = addExperience;
window.removeItem = removeItem;
window.saveProfile = saveProfile;
window.confirmBack = confirmBack;
window.closeConfirm = closeConfirm;
window.doBack = doBack;
window.goProfile = goProfile;
window.removeAvatar = removeAvatar;
window.handleAvatarUpload = handleAvatarUpload;
window.openCropModal = openCropModal;
window.closeCrop = closeCrop;
window.applyCrop = applyCrop;
window.updateFallback = updateFallback;
window.updateCharCount = updateCharCount;
window.showToast = showToast;
window.setAvatarFromUrl = setAvatarFromUrl;
window.validateField = validateField;
window.exportJSON = exportJSON;
window.updatePreview = updatePreview;
window.toggleDark = toggleDark;
window.toggleLang = toggleLang;
