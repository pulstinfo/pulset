// ================================================================
// asset.js - اسکریپت صفحه جزئیات ارز
// ================================================================

// ===== متغیرها =====
const urlParams = new URLSearchParams(window.location.search);
const symbol = urlParams.get('symbol') || 'BTC/USDT';
let assetData = null;
let priceData = null;
let tomanRate = null;
let tvLoaded = false;
let tvAttempts = 0;
let tvWidget = null;
let pollVotes = JSON.parse(localStorage.getItem('pulset_poll_' + symbol) || '{"bull":0,"bear":0}');
let userVoted = localStorage.getItem('pulset_poll_voted_' + symbol) === 'true';
let shareUrl = window.location.href;
let wsUnsubscribe = null;
let chatMessages = JSON.parse(localStorage.getItem('pulset_asset_chat_' + symbol) || '[]');
let currentPrice = 0;
let currentChange = 0;
let fabMenuOpen = false;

// ===== اطلاعات دارایی‌ها =====
const assetInfoDB = {
    'BTC/USDT': { name: 'بیت‌کوین', short: 'BTC', desc: 'بیت‌کوین اولین و بزرگترین ارز دیجیتال جهان است که در سال ۲۰۰۹ توسط ساتوشی ناکاموتو ایجاد شد. این ارز به عنوان طلای دیجیتال شناخته می‌شود و عرضه محدودی دارد.', links: { website: 'https://bitcoin.org', whitepaper: 'https://bitcoin.org/bitcoin.pdf', twitter: 'https://twitter.com/bitcoin' } },
    'ETH/USDT': { name: 'اتریوم', short: 'ETH', desc: 'اتریوم یک پلتفرم غیرمتمرکز برای قراردادهای هوشمند است که توسط ویتالیک بوترین ایجاد شده. اتریوم بستری برای توسعه برنامه‌های غیرمتمرکز (DApps) فراهم می‌کند.', links: { website: 'https://ethereum.org', whitepaper: 'https://ethereum.org/whitepaper', twitter: 'https://twitter.com/ethereum' } },
    'SOL/USDT': { name: 'سولانا', short: 'SOL', desc: 'سولانا یک بلاک‌چین با کارایی بالا است که به دلیل سرعت بالا و هزینه‌های پایین تراکنش، توجه زیادی را جلب کرده است. این شبکه از الگوریتم اثبات سهام (PoS) استفاده می‌کند.', links: { website: 'https://solana.com', whitepaper: 'https://solana.com/solana-whitepaper.pdf', twitter: 'https://twitter.com/solana' } },
    'XAU/USD': { name: 'طلا', short: 'XAU', desc: 'طلا یکی از قدیمی‌ترین و معتبرترین دارایی‌های سرمایه‌گذاری است که به عنوان پناهگاه امن در برابر تورم و بحران‌های اقتصادی شناخته می‌شود.', links: { website: 'https://www.gold.org', whitepaper: '', twitter: '' } }
};

function getDefaultInfo() {
    return { name: symbol.split('/')[0] || 'ارز', short: symbol.split('/')[0] || '', desc: 'توضیحاتی درباره این دارایی در حال تکمیل است.', links: {} };
}

// ===== کاربر =====
function getUser() {
    try {
        const s = JSON.parse(localStorage.getItem('pulset_profile') || '{}');
        return { name: s.displayName || 'علی معامله‌گر', avatar: s.avatar || 'ع', followers: s.followers || '۱.۲K', following: s.following || '۳۲۰' };
    } catch (e) { return { name: 'کاربر', avatar: 'ع', followers: '۰', following: '۰' }; }
}

// ===== توابع کمکی =====
function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(window.toastTimer);
    window.toastTimer = setTimeout(() => t.classList.remove('show'), 2500);
}

function applyTr() {
    // ترجمه‌ها در main.js مدیریت می‌شوند
}

function toggleDark() { /* در main.js تعریف شده */ }
function toggleLang() { /* در main.js تعریف شده */ }

// ===== دریافت داده‌ها =====
async function fetchAssetData() {
    try {
        const data = await API.Markets.getBySymbol(symbol);
        if (data) {
            assetData = data;
            return data;
        }
        throw new Error('No data');
    } catch (e) {
        console.warn('Fetch asset error, using fallback:', e);
        const fallback = {
            price: Math.round((Math.random() * 50000 + 100) * 100) / 100,
            change: Math.round((Math.random() * 10 - 5) * 10) / 10,
            high: 0,
            low: 0,
            volume: '--',
            supply: '--'
        };
        if (symbol === 'BTC/USDT') {
            Object.assign(fallback, { price: 67245.80, change: 2.34, high: 68245, low: 66980, volume: '24.8B', supply: '19.6M' });
        } else if (symbol === 'ETH/USDT') {
            Object.assign(fallback, { price: 3515.20, change: -1.12, high: 3560, low: 3480, volume: '12.1B', supply: '120.2M' });
        } else if (symbol === 'SOL/USDT') {
            Object.assign(fallback, { price: 178.30, change: 5.72, high: 182.5, low: 168.2, volume: '4.3B', supply: '470.5M' });
        }
        assetData = fallback;
        return fallback;
    }
}

async function fetchTomanRate() {
    try {
        const res = await fetch('https://api.exchangerate.host/latest?base=USD&symbols=IRR');
        if (!res.ok) throw new Error('Network error');
        const data = await res.json();
        return data.rates.IRR || 420000;
    } catch (e) {
        console.warn('Toman rate error:', e);
        return null;
    }
}

// ===== به‌روزرسانی UI =====
function updateUI() {
    const info = assetInfoDB[symbol] || getDefaultInfo();
    document.getElementById('assetTitle').textContent = info.name;
    document.getElementById('assetSymbol').textContent = symbol;

    const price = assetData?.price || 0;
    const change = assetData?.change || 0;
    currentPrice = price;
    currentChange = change;

    document.getElementById('priceUsd').textContent = '$' + price.toFixed(2);
    const ch = document.getElementById('priceChange');
    ch.textContent = (change >= 0 ? '+' : '') + change.toFixed(2) + '%';
    ch.className = 'price-change ' + (change >= 0 ? 'change-pos' : 'change-neg');

    document.getElementById('highDay').textContent = assetData?.high ? '$' + assetData.high.toLocaleString() : '--';
    document.getElementById('lowDay').textContent = assetData?.low ? '$' + assetData.low.toLocaleString() : '--';
    document.getElementById('volume24h').textContent = assetData?.volume || '--';
    document.getElementById('circulatingSupply').textContent = (assetData?.supply || '--') + ' ' + (info.short || '');

    document.getElementById('assetDesc').textContent = info.desc || 'توضیحاتی درباره این دارایی در حال تکمیل است.';
    const links = info.links || {};
    const linkEls = document.querySelectorAll('#assetLinks a');
    if (links.website) linkEls[0].href = links.website;
    if (links.whitepaper) linkEls[1].href = links.whitepaper;
    if (links.twitter) linkEls[2].href = links.twitter;

    const favs = JSON.parse(localStorage.getItem('pulset_asset_favs') || '[]');
    const btn = document.getElementById('favBtn');
    if (favs.includes(symbol)) {
        btn.textContent = '★';
        btn.classList.add('active');
    } else {
        btn.textContent = '☆';
        btn.classList.remove('active');
    }

    updateToman(price);
    renderOrders();
    renderTrades();
    updatePollUI();
    renderChatMessages();
}

async function updateToman(price) {
    if (!tomanRate) {
        tomanRate = await fetchTomanRate();
    }
    const el = document.getElementById('priceTmn');
    const err = document.getElementById('priceError');
    if (tomanRate && price) {
        const val = price * tomanRate;
        el.textContent = new Intl.NumberFormat('fa-IR', { style: 'currency', currency: 'IRR', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(val);
        err.classList.remove('show');
    } else {
        el.textContent = '--- تومان';
        err.classList.add('show');
    }
}

// ===== TradingView =====
function initTradingView() {
    if (tvLoaded) return;
    tvAttempts++;
    try {
        if (typeof TradingView === 'undefined') {
            if (tvAttempts < 5) { setTimeout(initTradingView, 800); return; }
            throw new Error('TV not loaded');
        }
        const tvSymbol = symbol.replace('/', '');
        tvWidget = new TradingView.widget({
            container_id: 'tvChart',
            autosize: true,
            symbol: 'BINANCE:' + tvSymbol,
            interval: '60',
            timezone: 'Asia/Tehran',
            theme: document.body.classList.contains('dark') ? 'dark' : 'light',
            style: '1',
            locale: getCurrentLang() === 'fa' ? 'fa_IR' : 'en',
            toolbar_bg: '#f1f3f6',
            enable_publishing: false,
            hide_side_toolbar: false,
            allow_symbol_change: false,
            studies: ['RSI@tv-basicstudies', 'MASimple@tv-basicstudies', 'MACD@tv-basicstudies'],
            loading_screen: { backgroundColor: 'transparent' }
        });
        tvLoaded = true;
        document.getElementById('chartLoader').classList.add('hidden');
    } catch (e) {
        console.warn('TV error:', e);
        document.getElementById('chartError').classList.add('show');
        document.getElementById('chartLoader').classList.add('hidden');
    }
}

// ===== تمام‌صفحه =====
function toggleFullscreen() {
    const wrapper = document.getElementById('chartWrapper');
    const fsBtn = document.getElementById('exitFsBtn');
    if (!document.fullscreenEnabled && !document.webkitFullscreenEnabled) {
        if (confirm('امکان نمایش تمام‌صفحه در این محیط وجود ندارد. آیا می‌خواهید نمودار را در یک صفحه جدید باز کنید؟')) {
            window.open(window.location.href + '&fullscreen=1', '_blank');
        }
        return;
    }
    if (!document.fullscreenElement && !document.webkitFullscreenElement) {
        const el = wrapper;
        if (el.requestFullscreen) {
            el.requestFullscreen().catch(() => {
                document.documentElement.requestFullscreen().catch(e => {
                    alert('خطا در فعال‌سازی تمام‌صفحه: ' + e.message);
                });
            });
        } else if (el.webkitRequestFullscreen) {
            el.webkitRequestFullscreen();
        } else if (el.msRequestFullscreen) {
            el.msRequestFullscreen();
        }
        if (screen.orientation && screen.orientation.lock) {
            screen.orientation.lock('landscape').catch(() => {});
        }
        fsBtn.classList.add('show');
    } else {
        if (document.exitFullscreen) {
            document.exitFullscreen().catch(() => {});
        } else if (document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
        } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
        }
        if (screen.orientation && screen.orientation.unlock) {
            screen.orientation.unlock();
        }
        fsBtn.classList.remove('show');
    }
}

function exitFullscreen() {
    if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
    } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
    } else if (document.msExitFullscreen) {
        document.msExitFullscreen();
    }
    if (screen.orientation && screen.orientation.unlock) {
        screen.orientation.unlock();
    }
    document.getElementById('exitFsBtn').classList.remove('show');
}

document.addEventListener('fullscreenchange', function() {
    if (!document.fullscreenElement) {
        document.getElementById('exitFsBtn').classList.remove('show');
        if (screen.orientation && screen.orientation.unlock) {
            screen.orientation.unlock();
        }
    } else {
        document.getElementById('exitFsBtn').classList.add('show');
    }
});

// ===== تغییر تب =====
function switchTab(tab, btn) {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    document.getElementById('tab-' + tab).classList.add('active');
    if (tab === 'chart') {
        setTimeout(initTradingView, 300);
    }
    if (tab === 'analysis') {
        loadAnalysis();
    }
}

// ===== سفارشات و معاملات =====
function renderOrders() {
    const tbody = document.getElementById('orderBody');
    const base = assetData?.price || 50000;
    const rows = [];
    for (let i = 0; i < 6; i++) {
        const offset = (i + 1) * 10;
        rows.push({ type: 'ask', price: base + offset, amount: (Math.random() * 2).toFixed(3), total: ((base + offset) * (Math.random() * 2)).toFixed(2) });
    }
    rows.push({ type: 'mid', price: base, amount: '', total: '' });
    for (let i = 0; i < 6; i++) {
        const offset = (i + 1) * 10;
        rows.push({ type: 'bid', price: base - offset, amount: (Math.random() * 2).toFixed(3), total: ((base - offset) * (Math.random() * 2)).toFixed(2) });
    }
    tbody.innerHTML = rows.map(r => {
        if (r.type === 'mid') return `<tr style="background:var(--bg2);"><td colspan="3" style="text-align:center;font-weight:700;color:var(--gold);">${r.price.toFixed(2)}</td></tr>`;
        const cls = r.type === 'ask' ? 'ask' : 'bid';
        return `<tr class="${cls}"><td>${r.price.toFixed(2)}</td><td>${r.amount}</td><td>${r.total}</td></tr>`;
    }).join('');
}

function renderTrades() {
    const tbody = document.getElementById('tradeBody');
    const base = assetData?.price || 50000;
    const rows = [];
    for (let i = 0; i < 8; i++) {
        const side = Math.random() > 0.5 ? 'ask' : 'bid';
        const price = side === 'ask' ? base + (Math.random() * 20 + 1) : base - (Math.random() * 20 + 1);
        rows.push({
            side,
            price: price.toFixed(2),
            amount: (Math.random() * 1.5).toFixed(4),
            time: new Date(Date.now() - i * 60000).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
        });
    }
    tbody.innerHTML = rows.map(r => `<tr class="${r.side}"><td>${r.price}</td><td>${r.amount}</td><td>${r.time}</td></tr>`).join('');
}

// ===== چت =====
const chatInput = document.getElementById('chatInput');
function autoResize() {
    chatInput.style.height = 'auto';
    chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + 'px';
}
chatInput.addEventListener('input', autoResize);
chatInput.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendChat();
    }
});

function renderChatMessages() {
    const container = document.getElementById('chatMessages');
    if (!container) return;
    if (!chatMessages.length) {
        container.innerHTML = `<div style="text-align:center;padding:30px 0;color:var(--text3);font-size:13px;">هنوز پیامی ارسال نشده است. اولین نفر باشید!</div>`;
        return;
    }
    container.innerHTML = chatMessages.map(msg => {
        const isSelf = msg.sender === 'me';
        const avatar = isSelf ? 'ش' : (msg.avatar || 'ع');
        const userLink = isSelf ? 'profile.html' : 'profile.html?user=' + (msg.user || '');
        return `<div class="chat-msg ${isSelf ? 'self' : ''}">
            <a class="chat-avatar" href="${userLink}">${avatar}</a>
            <div class="chat-bubble">${msg.text}<span class="chat-time">${msg.time}</span></div>
        </div>`;
    }).join('');
    container.scrollTop = container.scrollHeight;
}

function sendChat() {
    const txt = chatInput.value.trim();
    if (!txt) return;
    const now = new Date();
    const time = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
    const user = getUser();
    const msg = {
        sender: 'me',
        text: txt,
        time: time,
        user: user.name,
        avatar: user.avatar
    };
    chatMessages.push(msg);
    localStorage.setItem('pulset_asset_chat_' + symbol, JSON.stringify(chatMessages));
    renderChatMessages();
    chatInput.value = '';
    autoResize();
    if (wsUnsubscribe) {
        API.WS.send('asset_chat', { symbol: symbol, message: txt, user: user.name });
    }
}

// ===== نظرسنجی =====
function updatePollUI() {
    const total = pollVotes.bull + pollVotes.bear || 1;
    const bp = Math.round(pollVotes.bull / total * 100);
    const br = Math.round(pollVotes.bear / total * 100);
    document.getElementById('bullPct').textContent = bp + '%';
    document.getElementById('bearPct').textContent = br + '%';
    document.getElementById('pollBarBull').style.width = bp + '%';
    document.getElementById('pollBarBear').style.width = br + '%';
    document.getElementById('pollTotal').textContent = (pollVotes.bull + pollVotes.bear) + ' رای';
    document.getElementById('pollStatus').textContent = userVoted ? 'رای شما ثبت شد' : 'نظر خود را ثبت کنید';
    if (userVoted) {
        document.getElementById('pollBull').classList.add('disabled');
        document.getElementById('pollBear').classList.add('disabled');
    }
}

function votePoll(type) {
    if (userVoted) { showToast('شما قبلاً رای داده‌اید.'); return; }
    userVoted = true;
    localStorage.setItem('pulset_poll_voted_' + symbol, 'true');
    if (type === 'bull') { pollVotes.bull++;
        document.getElementById('pollBull').classList.add('selected-bull'); }
    else { pollVotes.bear++;
        document.getElementById('pollBear').classList.add('selected-bear'); }
    localStorage.setItem('pulset_poll_' + symbol, JSON.stringify(pollVotes));
    updatePollUI();
}

// ===== علاقه‌مندی =====
function toggleFav() {
    const btn = document.getElementById('favBtn');
    const favs = JSON.parse(localStorage.getItem('pulset_asset_favs') || '[]');
    const idx = favs.indexOf(symbol);
    if (idx > -1) {
        favs.splice(idx, 1);
        btn.textContent = '☆';
        btn.classList.remove('active');
    } else {
        favs.push(symbol);
        btn.textContent = '★';
        btn.classList.add('active');
    }
    localStorage.setItem('pulset_asset_favs', JSON.stringify(favs));
}

// ===== اشتراک‌گذاری =====
function openShareModal() {
    shareUrl = window.location.href;
    document.getElementById('shareModal').classList.add('show');
}

function closeShareModal() {
    document.getElementById('shareModal').classList.remove('show');
}

function copyLink() {
    navigator.clipboard.writeText(shareUrl).then(() => {
        showToast('✅ لینک کپی شد!');
        closeShareModal();
    }).catch(() => {
        const ta = document.createElement('textarea');
        ta.value = shareUrl;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        showToast('✅ لینک کپی شد!');
        closeShareModal();
    });
}

function shareNative() {
    if (navigator.share) {
        navigator.share({ title: 'Pulset - ' + (assetInfoDB[symbol]?.name || symbol), text: 'قیمت لحظه‌ای ' + (assetInfoDB[symbol]?.name || symbol) + ' در Pulset', url: shareUrl }).catch(() => {}).finally(closeShareModal);
    } else { copyLink(); }
}

// ===== تحلیل AI =====
let analysisLoaded = false;

function loadAnalysis() {
    if (analysisLoaded) return;
    const loading = document.getElementById('analysisLoading');
    const result = document.getElementById('analysisResult');
    const error = document.getElementById('analysisError');
    loading.style.display = 'block';
    result.style.display = 'none';
    error.style.display = 'none';

    const info = assetInfoDB[symbol] || getDefaultInfo();
    const price = assetData?.price || 0;

    API.AI.quickSignal(symbol, info.name, price)
        .then(data => {
            if (data && data.signal) {
                const signal = data.signal;
                document.getElementById('analysisSummary').textContent = signal.analysis || 'تحلیل مختصر از وضعیت فعلی بازار.';
                document.getElementById('analysisTechnical').textContent = signal.technical || 'تحلیل تکنیکال نشان‌دهنده روند صعودی در بازه کوتاه‌مدت است.';
                document.getElementById('analysisFundamental').textContent = signal.fundamental || 'عوامل بنیادی حاکی از رشد پایدار در میان‌مدت است.';
                document.getElementById('analysisPrediction').textContent = signal.prediction || 'پیش‌بینی می‌شود قیمت با ادامه روند فعلی به سطوح بالاتر حرکت کند.';
                document.getElementById('analysisConfidence').textContent = (signal.confidence || 70) + '%';
                analysisLoaded = true;
                loading.style.display = 'none';
                result.style.display = 'block';
            } else {
                throw new Error('No data');
            }
        })
        .catch(() => {
            // Fallback
            const analyses = {
                'BTC/USDT': { summary: 'بیت‌کوین در محدوده مقاومتی ۶۸ هزار دلار قرار دارد.', technical: 'RSI در سطح ۶۲ قرار دارد و نشان‌دهنده قدرت نسبی خریداران است. میانگین متحرک ۵۰ روزه حمایت خوبی ایجاد کرده.', fundamental: 'ورود سرمایه نهادی به ETF‌های بیت‌کوین ادامه دارد و این عامل می‌تواند قیمت را بالا ببرد.', prediction: 'با شکست مقاومت ۶۸ هزار دلار، هدف بعدی ۷۲ هزار دلار خواهد بود.', confidence: '۸۷%' },
                'ETH/USDT': { summary: 'اتریوم در کانال نزولی کوتاه‌مدت قرار دارد.', technical: 'RSI در ۴۵ و نشان‌دهنده خنثی است. حمایت کلیدی در ۳,۴۵۰ دلار.', fundamental: 'فعالیت شبکه اتریوم و تعداد تراکنش‌ها در حال افزایش است.', prediction: 'در صورت شکست مقاومت ۳,۵۵۰، رشد تا ۳,۷۰۰ دلار محتمل است.', confidence: '۷۲%' }
            };
            const data = analyses[symbol] || { summary: 'تحلیل این ارز در حال تکمیل است.', technical: 'داده‌های تکنیکال نشان‌دهنده نوسان متوسط است.', fundamental: 'اطلاعات فاندامنتال در حال بروزرسانی.', prediction: 'روند کلی بازار صعودی است.', confidence: '۶۵%' };
            document.getElementById('analysisSummary').textContent = data.summary;
            document.getElementById('analysisTechnical').textContent = data.technical;
            document.getElementById('analysisFundamental').textContent = data.fundamental;
            document.getElementById('analysisPrediction').textContent = data.prediction;
            document.getElementById('analysisConfidence').textContent = data.confidence;
            analysisLoaded = true;
            loading.style.display = 'none';
            result.style.display = 'block';
        });
}

// ===== FAB =====
function toggleFabMenu() {
    fabMenuOpen = !fabMenuOpen;
    document.getElementById('fabPlus').classList.toggle('open', fabMenuOpen);
    document.getElementById('fabMenu').classList.toggle('open', fabMenuOpen);
}
document.addEventListener('click', function(e) {
    const f = document.getElementById('fabPlus'),
        m = document.getElementById('fabMenu');
    if (fabMenuOpen && !f.contains(e.target) && !m.contains(e.target)) {
        fabMenuOpen = false;
        f.classList.remove('open');
        m.classList.remove('open');
    }
});

// ===== WebSocket =====
function connectWebSocket() {
    const token = API.getToken();
    if (!token) return;
    if (wsUnsubscribe) {
        wsUnsubscribe();
        wsUnsubscribe = null;
    }
    wsUnsubscribe = API.WS.subscribe('markets', (data) => {
        if (data.type === 'price_update' && data.symbol === symbol && data.price !== undefined) {
            updateAssetPrice(data.price, data.change);
        }
        if (data.type === 'chat_message' && data.symbol === symbol && data.message) {
            const now = new Date();
            const time = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
            const msg = {
                sender: 'other',
                text: data.message,
                time: time,
                user: data.user || 'کاربر',
                avatar: data.avatar || 'ع'
            };
            chatMessages.push(msg);
            localStorage.setItem('pulset_asset_chat_' + symbol, JSON.stringify(chatMessages));
            renderChatMessages();
        }
    });
}

function updateAssetPrice(price, change) {
    if (assetData) {
        assetData.price = price;
        if (change !== undefined) assetData.change = change;
        currentPrice = price;
        currentChange = change;
        document.getElementById('priceUsd').textContent = '$' + price.toFixed(2);
        const ch = document.getElementById('priceChange');
        ch.textContent = (change >= 0 ? '+' : '') + change.toFixed(2) + '%';
        ch.className = 'price-change ' + (change >= 0 ? 'change-pos' : 'change-neg');
        updateToman(price);
    }
}

// ===== دراور =====
function toggleDrawer() {
    const o = document.getElementById('drawerOverlay');
    o.classList.toggle('open');
    document.body.style.overflow = o.classList.contains('open') ? 'hidden' : '';
    const u = getUser();
    const av = document.getElementById('drawerAvatar');
    if (u.avatar && u.avatar.startsWith('data:image')) {
        av.innerHTML = `<img src="${u.avatar}" alt="${u.name}">`;
    } else {
        av.textContent = getInitials(u.name);
    }
    const un = document.querySelector('.drawer-un');
    if (un) un.textContent = u.name;
    document.getElementById('drawerFollowers').textContent = u.followers + ' ' + (getCurrentLang() === 'fa' ? 'دنبال‌کننده' : 'Followers');
    document.getElementById('drawerFollowing').textContent = u.following + ' ' + (getCurrentLang() === 'fa' ? 'دنبال‌شونده' : 'Following');
}

function closeDrawer() {
    document.getElementById('drawerOverlay').classList.remove('open');
    document.body.style.overflow = '';
}

// ===== مقداردهی اولیه =====
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    const lang = getCurrentLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');

    fetchAssetData().then(() => {
        updateUI();
        connectWebSocket();
        renderChatMessages();
    });

    document.querySelectorAll('.fab-menu-item').forEach(el => {
        const href = el.getAttribute('href');
        if (href) {
            const base = href.split('?')[0];
            el.href = base + '?symbol=' + encodeURIComponent(symbol);
        }
    });

    setTimeout(() => {
        if (document.querySelector('.tab-btn[data-tab="chart"].active')) {
            initTradingView();
        }
    }, 1000);
    setTimeout(() => {
        if (!tvLoaded) {
            document.getElementById('chartError').classList.add('show');
            document.getElementById('chartLoader').classList.add('hidden');
        }
    }, 8000);

    window.addEventListener('beforeunload', function() {
        if (wsUnsubscribe) wsUnsubscribe();
        API.WS.disconnect('markets');
    });

    console.log('✅ asset.js loaded for ' + symbol);
});

// ===== خروجی توابع =====
window.switchTab = switchTab;
window.toggleFullscreen = toggleFullscreen;
window.exitFullscreen = exitFullscreen;
window.sendChat = sendChat;
window.votePoll = votePoll;
window.toggleFav = toggleFav;
window.openShareModal = openShareModal;
window.closeShareModal = closeShareModal;
window.copyLink = copyLink;
window.shareNative = shareNative;
window.toggleFabMenu = toggleFabMenu;
window.toggleDrawer = toggleDrawer;
window.closeDrawer = closeDrawer;
window.loadAnalysis = loadAnalysis;
window.showToast = showToast;
window.toggleDark = toggleDark;
window.toggleLang = toggleLang;
