// ================================================================
// restricted.js - اسکریپت صفحه کاربران محدودشده
// ================================================================

// ===== ترجمه =====
const PAGE_TR = {
    fa: {
        pageTitle: 'کاربران محدودشده',
        emptyTitle: 'هیچ کاربری محدود نشده',
        emptyDesc: 'کاربران محدود شده نمی‌توانند به شما پیام دهند.',
        unrestrict: 'رفع محدودیت',
        unrestricted: '✅ محدودیت برداشته شد'
    },
    en: {
        pageTitle: 'Restricted Users',
        emptyTitle: 'No users restricted',
        emptyDesc: 'Restricted users cannot message you.',
        unrestrict: 'Unrestrict',
        unrestricted: '✅ Restriction removed'
    }
};

// ===== اعمال ترجمه =====
function applyPageTranslations() {
    const lang = getCurrentLang();
    const t = PAGE_TR[lang] || PAGE_TR.fa;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key]) el.textContent = t[key];
    });
}
window.applyPageTranslations = applyPageTranslations;

// ===== تابع t محلی =====
function t(key) {
    const lang = getCurrentLang();
    return PAGE_TR[lang]?.[key] || key;
}

// ===== داده‌های نمونه =====
const sampleRestricted = [
    { id: 'r1', name: 'کاربر پرحرف', handle: '@chatter', avatar: 'پ', reason: 'ارسال پیام‌های زیاد' },
    { id: 'r2', name: 'ربات اسپم', handle: '@spam_bot', avatar: 'ر', reason: 'ارسال لینک‌های تبلیغاتی' },
];

// ===== دریافت لیست =====
function getRestricted() {
    try {
        const b = localStorage.getItem('pulset_restricted');
        if (b) return JSON.parse(b);
    } catch (e) { /* ignore */ }
    return sampleRestricted;
}

function saveRestricted(list) {
    localStorage.setItem('pulset_restricted', JSON.stringify(list));
}

// ===== رفع محدودیت =====
function unrestrictUser(id) {
    const list = getRestricted().filter(function(u) { return u.id !== id; });
    saveRestricted(list);
    renderRestricted();
    showToast(t('unrestricted'));
}

// ===== رندر =====
function renderRestricted() {
    const list = getRestricted();
    const container = document.getElementById('restrictedList');
    if (!list.length) {
        container.innerHTML = `
            <div class="empty-state">
                <span class="icon"><i class="fas fa-user-slash"></i></span>
                <div class="title">${t('emptyTitle')}</div>
                <div class="desc">${t('emptyDesc')}</div>
            </div>
        `;
        return;
    }
    container.innerHTML = list.map(function(u) {
        return `
            <div class="list-item">
                <div class="avatar">${u.avatar || '?'}</div>
                <div class="info">
                    <div class="name">${u.name}</div>
                    <div class="handle">${u.handle}</div>
                    <div class="reason">⛔ ${u.reason}</div>
                </div>
                <button class="action-btn" onclick="unrestrictUser('${u.id}')">${t('unrestrict')}</button>
            </div>
        `;
    }).join('');
}

// ===== مقداردهی اولیه =====
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    const lang = getCurrentLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    applyPageTranslations();

    renderRestricted();
    console.log('✅ restricted.js loaded');
});

// ===== خروجی توابع =====
window.unrestrictUser = unrestrictUser;
window.renderRestricted = renderRestricted;
window.showToast = showToast;
window.toggleDark = toggleDark;
window.toggleLang = toggleLang;
