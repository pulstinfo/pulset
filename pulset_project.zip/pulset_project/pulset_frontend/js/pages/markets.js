// ================================================================
// markets.js - اسکریپت صفحه بازارها
// ================================================================

let assets = [],
    filteredAssets = [],
    watchlist = JSON.parse(localStorage.getItem('pulset_watchlist') || '[]'),
    currentTab = 'all',
    page = 0,
    loading = false,
    hasMore = true,
    observer = null,
    sortKey = 'name',
    sortAsc = true;
let alerts = JSON.parse(localStorage.getItem('pulset_price_alerts') || '[]');
let wsUnsubscribe = null;

function applyPageTranslations() {
    const lang = getCurrentLang();
    const tr = {
        fa: {
            emp: 'هیچ دارایی‌ای یافت نشد',
            end: 'همه دارایی‌ها را دیدید',
            ld: 'در حال بارگذاری...',
            search_placeholder: 'جستجوی دارایی...',
            sort: 'مرتب‌سازی',
            all: 'همه',
            crypto: 'کریپتو',
            forex: 'فارکس',
            commodity: 'کالا',
            iran_stock: 'بورس ایران',
            us_stock: 'بورس آمریکا',
            price_alert: 'هشدار قیمت',
            scanner: 'اسکن سریع',
            compare: 'مقایسه ارزها',
            scanner_all: 'همه',
            scanner_gainers: 'بیشترین رشد',
            scanner_losers: 'بیشترین افت',
            no_result: 'نتیجه‌ای یافت نشد',
            current_price: 'قیمت فعلی:',
            alert_above: 'بالاتر از',
            alert_below: 'پایین‌تر از',
            no_active_alerts: 'هشدار فعالی وجود ندارد',
            select_asset: 'انتخاب ارز',
            alert_type: 'نوع هشدار',
            target_price: 'قیمت هدف',
            save_alert: 'ذخیره هشدار',
            please_select_asset: 'لطفاً یک ارز انتخاب کنید.',
            invalid_price: 'لطفاً قیمت هدف را وارد کنید.',
            price_valid: '✅ قیمت معتبر - قیمت فعلی: ${price}'
        },
        en: {
            emp: 'No assets found',
            end: 'You\'ve seen all',
            ld: 'Loading...',
            search_placeholder: 'Search assets...',
            sort: 'Sort',
            all: 'All',
            crypto: 'Crypto',
            forex: 'Forex',
            commodity: 'Commodity',
            iran_stock: 'Iran Stocks',
            us_stock: 'US Stocks',
            price_alert: 'Price Alert',
            scanner: 'Quick Scan',
            compare: 'Compare Assets',
            scanner_all: 'All',
            scanner_gainers: 'Top Gainers',
            scanner_losers: 'Top Losers',
            no_result: 'No results found',
            current_price: 'Current price:',
            alert_above: 'Above',
            alert_below: 'Below',
            no_active_alerts: 'No active alerts',
            select_asset: 'Select asset',
            alert_type: 'Alert type',
            target_price: 'Target price',
            save_alert: 'Save alert',
            please_select_asset: 'Please select an asset.',
            invalid_price: 'Please enter target price.',
            price_valid: '✅ Valid price - Current price: ${price}'
        }
    };
    const t = tr[lang] || tr.fa;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key] !== undefined) el.textContent = t[key];
    });
    document.getElementById('searchInput').placeholder = t.search_placeholder;
    document.getElementById('sortBtn').innerHTML = t.sort + ' <span class="arrow">▼</span>';
}
window.applyPageTranslations = applyPageTranslations;

function getSparklineData() {
    return Array.from({ length: 10 }, () => Math.floor(Math.random() * 30 + 10));
}

function generateMockAssets(count) {
    const result = [];
    const categories = ['crypto', 'forex', 'commodity', 'iran_stock', 'us_stock'];
    const names = ['بیت‌کوین', 'اتریوم', 'سولانا', 'کاردانو', 'بایننس کوین', 'ریپل', 'دوج کوین', 'پولکادات', 'لایت کوین', 'چین لینک', 'یونی سوآپ', 'آوالانچ', 'پالیگان', 'طلا', 'نقره', 'نفت خام', 'اپل', 'مایکروسافت', 'تسلا', 'آمازون', 'انویدیا', 'متا', 'فولاد مبارکه', 'ملی مس', 'شستا', 'ایران خودرو'];
    const symbols = ['BTC/USDT', 'ETH/USDT', 'SOL/USDT', 'ADA/USDT', 'BNB/USDT', 'XRP/USDT', 'DOGE/USDT', 'DOT/USDT', 'LTC/USDT', 'LINK/USDT', 'UNI/USDT', 'AVAX/USDT', 'MATIC/USDT', 'XAU/USD', 'XAG/USD', 'WTI/USD', 'AAPL', 'MSFT', 'TSLA', 'AMZN', 'NVDA', 'META', 'فولاد', 'فملی', 'شستا', 'خودرو'];
    const icons = ['₿', 'Ξ', '◎', '₳', '🟡', '✕', '🐕', '●', 'Ł', '🔗', '🦄', '▲', '⬡', '🥇', '🥈', '🛢️', '🍎', '💻', '🚗', '📦', '🖥️', '📱', '🏭', '⚒️', '🏛️', '🚗'];
    for (let i = 0; i < Math.min(count, names.length); i++) {
        const price = Math.random() * 50000 + 100;
        const change = (Math.random() * 10) - 5;
        result.push({
            id: 'asset_' + i,
            name: names[i % names.length],
            symbol: symbols[i % symbols.length],
            icon: icons[i % icons.length],
            price: Math.round(price * 100) / 100,
            change: Math.round(change * 10) / 10,
            type: categories[i % categories.length],
            volume: Math.floor(Math.random() * 2000 + 100),
            spark: getSparklineData()
        });
    }
    return result;
}

async function fetchAssets(tab, query, pageNum) {
    try {
        const data = await API.Markets.get(tab, query, pageNum, 20);
        return data.map(item => ({
            id: item.id || 'asset_' + Date.now() + '_' + Math.random(),
            name: item.name || 'نامشخص',
            symbol: item.symbol || '---',
            icon: item.icon || '📊',
            price: item.price || 0,
            change: item.change || 0,
            type: item.type || 'crypto',
            volume: item.volume || 0,
            spark: item.spark || getSparklineData()
        }));
    } catch (e) {
        console.warn('Fetch assets error, using fallback:', e);
        return generateMockAssets(100);
    }
}

function createAssetCard(a) {
    const f = watchlist.includes(a.id) ? 'active' : '';
    const cl = a.change >= 0 ? 'positive' : 'negative';
    const sg = a.change >= 0 ? '+' : '';
    const sp = a.spark || getSparklineData();
    const points = sp.map((v, i) => i * 5 + ',' + (26 - v)).join(' ');
    return `<a class="asset-card" href="asset.html?symbol=${encodeURIComponent(a.symbol)}" data-id="${a.id}" data-symbol="${a.symbol}">
        <div class="asset-icon">${a.icon}</div>
        <div class="asset-info">
            <div class="asset-name">${a.name} <span class="symbol">${a.symbol}</span></div>
            <div class="asset-price">$${a.price.toFixed(2)}</div>
            <div class="asset-change ${cl}">${sg}${a.change.toFixed(2)}%</div>
        </div>
        <svg class="asset-sparkline" viewBox="0 0 50 26">
            <polyline points="${points}" stroke="${a.change >= 0 ? '#2e7d32' : '#c62828'}" stroke-width="2" fill="none"/>
        </svg>
        <button class="asset-fav ${f}" onclick="event.stopPropagation(); toggleWatchlist('${a.id}')">${f ? '★' : '☆'}</button>
    </a>`;
}

function renderAssets() {
    const container = document.getElementById('marketList');
    if (!container) return;
    const q = document.getElementById('searchInput').value.trim().toLowerCase();
    let list = assets.filter(a => {
        const matchTab = currentTab === 'all' || a.type === currentTab;
        const matchSearch = !q || a.name.toLowerCase().includes(q) || a.symbol.toLowerCase().includes(q);
        return matchTab && matchSearch;
    });
    if (sortKey === 'watchlist') {
        list.sort((a, b) => {
            const wa = watchlist.includes(a.id) ? 1 : 0;
            const wb = watchlist.includes(b.id) ? 1 : 0;
            return sortAsc ? wb - wa : wa - wb;
        });
    } else {
        list.sort((a, b) => {
            let va = a[sortKey],
                vb = b[sortKey];
            if (typeof va === 'string') { va = va.toLowerCase();
                vb = vb.toLowerCase(); }
            if (va < vb) return sortAsc ? -1 : 1;
            if (va > vb) return sortAsc ? 1 : -1;
            return 0;
        });
    }
    filteredAssets = list;
    const items = list.slice(0, page * 20 + 20);
    container.innerHTML = '';
    document.getElementById('searchStats').textContent = list.length;
    if (!items.length) {
        container.innerHTML = `<div class="empty-state"><span class="icon">🔍</span>${t('emp')}</div>`;
        hasMore = false;
        return;
    }
    items.forEach(a => container.insertAdjacentHTML('beforeend', createAssetCard(a)));
    hasMore = items.length < list.length;
    const endMsg = document.getElementById('endMessage');
    if (endMsg) { if (!hasMore) endMsg.classList.add('show');
    else endMsg.classList.remove('show'); }
    setupObserver();
}

async function initMarkets() {
    page = 0;
    const data = await fetchAssets(currentTab, '', 0);
    assets = data;
    renderAssets();
    connectWebSocket();
    updateCounts();
}

async function loadMore() {
    if (loading || !hasMore) return;
    loading = true;
    const l = document.getElementById('loaderContainer');
    if (l) l.classList.add('show');
    page++;
    const data = await fetchAssets(currentTab, document.getElementById('searchInput').value.trim(), page);
    if (data.length) {
        assets = [...assets, ...data];
        renderAssets();
    } else {
        hasMore = false;
        const e = document.getElementById('endMessage');
        if (e) e.classList.add('show');
    }
    if (l) l.classList.remove('show');
    loading = false;
}

function setupObserver() {
    if (observer) observer.disconnect();
    const l = document.getElementById('loaderContainer');
    observer = new IntersectionObserver(e => {
        if (e[0].isIntersecting && !loading && hasMore) loadMore();
    }, { threshold: 0.1 });
    if (l) observer.observe(l);
}

function updateCounts() {
    const counts = { all: assets.length };
    ['crypto', 'forex', 'commodity', 'iran_stock', 'us_stock'].forEach(t => {
        counts[t] = assets.filter(a => a.type === t).length;
    });
    document.querySelectorAll('.tab-btn').forEach(b => {
        const t = b.dataset.type;
        const s = b.querySelector('.count');
        if (s) s.textContent = counts[t] || 0;
    });
}

function switchTab(tab, btn) {
    currentTab = tab;
    page = 0;
    hasMore = true;
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    initMarkets();
}

function handleSearch() {
    page = 0;
    hasMore = true;
    renderAssets();
}

function toggleWatchlist(id) {
    const idx = watchlist.indexOf(id);
    if (idx > -1) watchlist.splice(idx, 1);
    else watchlist.push(id);
    localStorage.setItem('pulset_watchlist', JSON.stringify(watchlist));
    renderAssets();
}

function connectWebSocket() {
    if (wsUnsubscribe) {
        wsUnsubscribe();
        wsUnsubscribe = null;
    }
    const token = API.getToken();
    if (!token) return;
    wsUnsubscribe = API.WS.subscribe('markets', (data) => {
        if (data.type === 'price_update' && data.symbol && data.price !== undefined) {
            const asset = assets.find(a => a.symbol === data.symbol);
            if (asset) {
                asset.price = data.price;
                if (data.change !== undefined) asset.change = data.change;
                const card = document.querySelector(`.asset-card[data-symbol="${data.symbol}"]`);
                if (card) {
                    const priceEl = card.querySelector('.asset-price');
                    if (priceEl) priceEl.textContent = '$' + data.price.toFixed(2);
                    const changeEl = card.querySelector('.asset-change');
                    if (changeEl && data.change !== undefined) {
                        const chg = data.change >= 0 ? '+' + data.change.toFixed(2) : data.change.toFixed(2);
                        changeEl.textContent = chg + '%';
                        changeEl.className = 'asset-change ' + (data.change >= 0 ? 'positive' : 'negative');
                    }
                }
                checkAlerts(asset);
            }
        }
    });
}

function checkAlerts(asset) {
    alerts.forEach((alert, idx) => {
        if (alert.assetId === asset.id || alert.symbol === asset.symbol) {
            let triggered = false;
            if (alert.type === 'above' && asset.price >= alert.price) triggered = true;
            else if (alert.type === 'below' && asset.price <= alert.price) triggered = true;
            if (triggered) {
                showToast('🔔 هشدار قیمت برای ' + asset.name + ' فعال شد! قیمت: $' + asset.price.toFixed(2));
                alerts.splice(idx, 1);
                localStorage.setItem('pulset_price_alerts', JSON.stringify(alerts));
                renderAlertList();
            }
        }
    });
}

function openSortSheet() {
    document.getElementById('sortOverlay').classList.add('open');
    updateSortUI();
}

function closeSortSheet() {
    document.getElementById('sortOverlay').classList.remove('open');
}

function applySort(key) {
    if (sortKey === key) sortAsc = !sortAsc;
    else { sortKey = key;
        sortAsc = true; }
    updateSortUI();
    page = 0;
    hasMore = true;
    renderAssets();
    setTimeout(closeSortSheet, 300);
}

function updateSortUI() {
    document.querySelectorAll('.sort-option').forEach(el => {
        el.classList.toggle('active', el.dataset.sort === sortKey);
        const d = el.querySelector('.arrow-dir');
        if (d) d.textContent = sortAsc ? '▲' : '▼';
    });
}

function openAlertSheet() {
    document.getElementById('alertOverlay').classList.add('open');
    populateAlertAssets();
    renderAlertList();
}

function closeAlertSheet() {
    document.getElementById('alertOverlay').classList.remove('open');
}

function populateAlertAssets() {
    const s = document.getElementById('alertAsset');
    s.innerHTML = '';
    assets.forEach(a => {
        const o = document.createElement('option');
        o.value = a.id;
        o.textContent = a.name + ' (' + a.symbol + ')';
        s.appendChild(o);
    });
    if (assets.length > 0) {
        document.getElementById('selectedAssetDisplay').style.display = 'none';
        document.getElementById('assetSearchInput').value = '';
        document.getElementById('assetSearchResults').classList.remove('show');
    }
}

function renderAlertList() {
    const c = document.getElementById('alertList');
    if (!alerts.length) {
        c.innerHTML = '<div style="font-size:12px;color:var(--text3);text-align:center;padding:8px;">هشدار فعالی وجود ندارد</div>';
        return;
    }
    c.innerHTML = alerts.map((a, i) => {
        const tt = a.type === 'above' ? 'بالاتر از' : 'پایین‌تر از';
        return `<div class="alert-item"><span>${a.name || 'نامشخص'} ${tt} $${a.price}</span><span class="del" onclick="removeAlert(${i})">✕</span></div>`;
    }).join('');
}

function saveAlert() {
    const id = document.getElementById('alertAsset').value;
    const type = document.getElementById('alertType').value;
    const price = parseFloat(document.getElementById('alertPrice').value);
    if (!id || !price || isNaN(price)) { showToast('لطفاً اطلاعات کامل را وارد کنید.'); return; }
    const asset = assets.find(a => a.id === id);
    if (!asset) { showToast('دارایی یافت نشد'); return; }
    if ((type === 'above' && price <= asset.price) || (type === 'below' && price >= asset.price)) {
        showToast('⚠️ قیمت هدف باید با منطق هشدار همخوانی داشته باشد.');
        return;
    }
    alerts.push({ assetId: id, symbol: asset.symbol, name: asset.name, type: type, price: price });
    localStorage.setItem('pulset_price_alerts', JSON.stringify(alerts));
    renderAlertList();
    document.getElementById('alertPrice').value = '';
    showToast('✅ هشدار ذخیره شد');
}

function removeAlert(idx) {
    alerts.splice(idx, 1);
    localStorage.setItem('pulset_price_alerts', JSON.stringify(alerts));
    renderAlertList();
}

function filterAssetList() {
    const q = document.getElementById('assetSearchInput').value.trim().toLowerCase();
    const r = document.getElementById('assetSearchResults');
    if (!q) { r.classList.remove('show'); return; }
    const f = assets.filter(a => a.name.toLowerCase().includes(q) || a.symbol.toLowerCase().includes(q));
    if (!f.length) { r.innerHTML = '<div class="item" style="color:var(--text3);">' + t('no_result') + '</div>';
        r.classList.add('show'); return; }
    r.innerHTML = f.map(a => `<div class="item" onclick="selectAlertAsset('${a.id}','${a.name} (${a.symbol})',${a.price})">${a.name} <span class="sub">${a.symbol}</span></div>`).join('');
    r.classList.add('show');
}

function selectAlertAsset(id, dn, p) {
    document.getElementById('alertAsset').value = id;
    document.getElementById('assetSearchInput').value = dn;
    document.getElementById('assetSearchResults').classList.remove('show');
    document.getElementById('selectedAssetDisplay').style.display = 'block';
    document.getElementById('selectedAssetName').textContent = dn;
    document.getElementById('priceHelper').textContent = t('current_price') + ' $' + p.toFixed(2);
}

function resetAssetSearch() {
    document.getElementById('alertAsset').value = '';
    document.getElementById('assetSearchInput').value = '';
    document.getElementById('assetSearchResults').classList.remove('show');
    document.getElementById('selectedAssetDisplay').style.display = 'none';
    document.getElementById('priceHelper').textContent = t('current_price') + ' --';
}

function openScannerSheet() {
    document.getElementById('scannerOverlay').classList.add('open');
    runScanner('all');
}

function closeScannerSheet() {
    document.getElementById('scannerOverlay').classList.remove('open');
}

function runScanner(mode) {
    const c = document.getElementById('scannerResults');
    let list = [...assets];
    if (mode === 'gainers') list.sort((a, b) => b.change - a.change);
    else if (mode === 'losers') list.sort((a, b) => a.change - b.change);
    else list.sort((a, b) => Math.abs(b.change) - Math.abs(a.change));
    const top = list.slice(0, 8);
    if (!top.length) {
        c.innerHTML = '<div class="scanner-empty">' + t('no_result') + '</div>';
        return;
    }
    c.innerHTML = top.map(a => {
        const cl = a.change >= 0 ? 'pos' : 'neg';
        const sg = a.change >= 0 ? '+' : '';
        return `<div class="scanner-card" onclick="window.location.href='asset.html?symbol=${encodeURIComponent(a.symbol)}'">
            <div class="name">${a.name}</div>
            <div class="price">$${a.price.toFixed(2)}</div>
            <div class="chg ${cl}">${sg}${a.change.toFixed(2)}%</div>
        </div>`;
    }).join('');
}

function toggleFabMenu() {
    const menu = document.getElementById('fabMenu');
    const btn = document.getElementById('fabPlus');
    const isOpen = menu.classList.contains('open');
    menu.classList.toggle('open');
    btn.classList.toggle('open');
}

document.addEventListener('click', function(e) {
    const menu = document.getElementById('fabMenu');
    const btn = document.getElementById('fabPlus');
    if (menu && menu.classList.contains('open') && !menu.contains(e.target) && !btn.contains(e.target)) {
        menu.classList.remove('open');
        btn.classList.remove('open');
    }
});

function toggleDark() { /* در main.js تعریف شده */ }
function toggleLang() { /* در main.js تعریف شده */ }
function toggleDrawer() { /* در main.js تعریف شده */ }
function closeDrawer() { /* در main.js تعریف شده */ }

document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    applyPageTranslations();
    initMarkets();
    const path = window.location.pathname.split('/').pop() || 'markets.html';
    const pm = { dashboard: 'dashboard', signals_feed: 'signals_feed', markets: 'markets', explore: 'explore' };
    const cp = pm[path.split('.')[0]] || 'markets';
    document.querySelectorAll('.nav').forEach(n => n.classList.toggle('active', n.dataset.page === cp));
    if (cp === 'signal') document.getElementById('centerBtn')?.classList.add('active');
    console.log('✅ markets.js loaded');
});

window.switchTab = switchTab;
window.handleSearch = handleSearch;
window.toggleWatchlist = toggleWatchlist;
window.openSortSheet = openSortSheet;
window.closeSortSheet = closeSortSheet;
window.applySort = applySort;
window.openAlertSheet = openAlertSheet;
window.closeAlertSheet = closeAlertSheet;
window.saveAlert = saveAlert;
window.removeAlert = removeAlert;
window.filterAssetList = filterAssetList;
window.selectAlertAsset = selectAlertAsset;
window.resetAssetSearch = resetAssetSearch;
window.openScannerSheet = openScannerSheet;
window.closeScannerSheet = closeScannerSheet;
window.runScanner = runScanner;
window.toggleFabMenu = toggleFabMenu;
window.toggleDark = toggleDark;
window.toggleLang = toggleLang;
window.toggleDrawer = toggleDrawer;
window.closeDrawer = closeDrawer;
window.showToast = showToast;
