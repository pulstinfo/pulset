// ================================================================
// notifications.js - اسکریپت صفحه اعلان‌ها
// ================================================================

// ===== ترجمه =====
const PAGE_TR = {
    fa: {
        notif_title: 'اعلان‌ها',
        all: 'همه',
        likes: 'لایک‌ها',
        comments: 'کامنت‌ها',
        follows: 'دنبال‌کننده‌ها',
        signals: 'سیگنال‌ها',
        mark_all_read: 'خوانده شد',
        empty: 'هیچ اعلانی وجود ندارد',
        empty_desc: 'وقتی فعالیتی انجام شود، اینجا ظاهر می‌شود.',
        follow: 'دنبال کردن',
        unfollow: 'لغو دنبال',
        reply: 'پاسخ',
        view_signal: 'مشاهده سیگنال',
        read_all: 'همه اعلان‌ها خوانده شد',
        deleted: 'اعلان حذف شد',
        reply_placeholder: 'پاسخ خود را بنویسید...',
        reply_sent: 'پاسخ ارسال شد',
        cancel: 'انصراف',
        you: 'شما'
    },
    en: {
        notif_title: 'Notifications',
        all: 'All',
        likes: 'Likes',
        comments: 'Comments',
        follows: 'Followers',
        signals: 'Signals',
        mark_all_read: 'Mark read',
        empty: 'No notifications yet',
        empty_desc: 'When activity happens, it will appear here.',
        follow: 'Follow',
        unfollow: 'Unfollow',
        reply: 'Reply',
        view_signal: 'View Signal',
        read_all: 'All notifications marked read',
        deleted: 'Notification deleted',
        reply_placeholder: 'Write your reply...',
        reply_sent: 'Reply sent',
        cancel: 'Cancel',
        you: 'You'
    }
};

// ===== متغیرها =====
let filter = 'all';
let notifications = [];
let openReplyId = null;
let wsUnsubscribe = null;

// ===== اعمال ترجمه =====
function applyPageTranslations() {
    const lang = getCurrentLang();
    const t = PAGE_TR[lang] || PAGE_TR.fa;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key]) el.textContent = t[key];
    });
}
window.applyPageTranslations = applyPageTranslations;

// ===== تابع t محلی =====
function t(key) {
    const lang = getCurrentLang();
    return PAGE_TR[lang]?.[key] || key;
}

// ===== داده‌های نمونه =====
const SAMPLE_NOTIFS = [
    { id: 1, type: 'like', user: 'مریم تریدر', avatar: 'م', handle: '@mary_crypto', text: 'پست شما را لایک کرد.', time: Date.now() - 120000, unread: true, link: 'dashboard.html', replies: [] },
    { id: 2, type: 'comment', user: 'حسین تحلیلگر', avatar: 'ح', handle: '@hossein_fx', text: 'روی پست شما کامنت گذاشت: «تحلیل عالی بود!»', time: Date.now() - 480000, unread: true, link: 'dashboard.html?comment=1', replies: [] },
    { id: 3, type: 'follow', user: 'سارا اسکالپر', avatar: 'س', handle: '@sara_scalp', text: 'شما را دنبال کرد.', time: Date.now() - 1200000, unread: true, link: 'profile.html?user=sara', replies: [] },
    { id: 4, type: 'signal', user: 'Pulset AI', avatar: 'AI', handle: '@pulset_ai', text: 'یک سیگنال جدید برای <span class="highlight">بیت‌کوین</span> منتشر کرد.', time: Date.now() - 2100000, unread: false, link: 'signals_feed.html?tab=public', replies: [{ user: 'شما', text: 'ممنون از سیگنال!', time: Date.now() - 1800000 }] },
    { id: 5, type: 'like', user: 'رضا بورسی', avatar: 'ر', handle: '@reza_bourse', text: 'سیگنال شما را لایک کرد.', time: Date.now() - 3600000, unread: false, link: 'signals_feed.html', replies: [] },
    { id: 6, type: 'comment', user: 'نیما تریدر', avatar: 'ن', handle: '@nima_fx', text: 'روی تحلیل شما کامنت گذاشت: «دقیقاً همین نقطه ورود مناسب است.»', time: Date.now() - 7200000, unread: false, link: 'dashboard.html?comment=2', replies: [] }
];

// ===== دریافت از API =====
async function fetchNotifications() {
    try {
        const data = await API.Notifications.get();
        if (data && data.length) {
            return data.map(n => ({
                id: n.id,
                type: n.type || 'other',
                user: n.user || 'کاربر',
                avatar: n.avatar || 'ع',
                handle: n.handle || '',
                text: n.text || '',
                time: n.time || Date.now(),
                unread: n.unread || false,
                link: n.link || '#',
                replies: n.replies || []
            }));
        }
        return SAMPLE_NOTIFS;
    } catch (e) {
        console.warn('Fetch notifications error, using fallback:', e);
        try {
            const local = localStorage.getItem('pulset_notifications');
            if (local) return JSON.parse(local);
        } catch (e) { /* ignore */ }
        return SAMPLE_NOTIFS;
    }
}

async function markNotifRead(id) {
    try {
        await API.Notifications.markRead(id);
    } catch (e) {
        console.warn('Mark read error:', e);
    }
}

async function markAllReadAPI() {
    try {
        await API.Notifications.markAllRead();
    } catch (e) {
        console.warn('Mark all read error:', e);
    }
}

async function deleteNotifAPI(id) {
    try {
        await API.Notifications.delete(id);
    } catch (e) {
        console.warn('Delete notification error:', e);
    }
}

// ===== WebSocket =====
function connectWebSocket() {
    if (wsUnsubscribe) {
        wsUnsubscribe();
        wsUnsubscribe = null;
    }
    const token = API.getToken();
    if (!token) return;
    wsUnsubscribe = API.WS.subscribe('notifications', (data) => {
        if (data.type === 'new_notification') {
            const newNotif = {
                id: data.id || Date.now(),
                type: data.notification?.type || 'other',
                user: data.notification?.user || 'کاربر',
                avatar: data.notification?.avatar || 'ع',
                handle: data.notification?.handle || '',
                text: data.notification?.text || '',
                time: data.notification?.time || Date.now(),
                unread: true,
                link: data.notification?.link || '#',
                replies: data.notification?.replies || []
            };
            notifications.unshift(newNotif);
            saveNotifs(notifications);
            renderNotifications();
            showToast('🔔 اعلان جدید');
        }
        if (data.type === 'notification_read' && data.id) {
            const n = notifications.find(x => x.id === data.id);
            if (n) { n.unread = false;
                saveNotifs(notifications);
                renderNotifications(); }
        }
    });
}

// ===== مدیریت داده‌ها =====
function getNotifs() {
    try {
        const n = localStorage.getItem('pulset_notifications');
        if (n) {
            const parsed = JSON.parse(n);
            if (parsed.length) return parsed;
        }
    } catch (e) { /* ignore */ }
    return SAMPLE_NOTIFS;
}

function saveNotifs(n) {
    localStorage.setItem('pulset_notifications', JSON.stringify(n));
    updateBadge();
}

function updateBadge() {
    const unreadCount = notifications.filter(n => n.unread).length;
    const badge = document.getElementById('unreadBadge');
    if (badge) badge.textContent = unreadCount;
}

// ===== رندر =====
function renderNotifications() {
    const list = document.getElementById('notifList');
    const filtered = filter === 'all' ? notifications : notifications.filter(n => n.type === filter);
    if (!filtered.length) {
        list.innerHTML = `
            <div class="empty-state">
                <span class="icon">🔔</span>
                <div class="text">${t('empty')}<br><span style="font-size:12px;color:var(--text3);">${t('empty_desc')}</span></div>
            </div>
        `;
        return;
    }
    list.innerHTML = filtered.map(n => {
        const isUnread = n.unread ? 'unread' : '';
        const avatarContent = n.avatar && n.avatar.startsWith('data:image') ?
            `<img src="${n.avatar}" alt="${n.user}">` : (n.avatar || 'ع');
        const actionHtml = getActionHtml(n);
        const replyHtml = getReplyHtml(n);
        const isReplyOpen = openReplyId === n.id;
        return `
            <div class="notif-item ${isUnread}" data-id="${n.id}">
                <div class="avatar" onclick="handleClick(${n.id})">${avatarContent}</div>
                <div class="info">
                    <div class="text" onclick="handleClick(${n.id})"><span class="username">${n.user}</span> ${n.text}</div>
                    <div class="time" onclick="handleClick(${n.id})">${formatTime(n.time)}</div>
                    ${actionHtml}
                    <div class="reply-box ${isReplyOpen?'show':''}" id="replyBox-${n.id}">
                        <input type="text" id="replyInput-${n.id}" placeholder="${t('reply_placeholder')}" onkeydown="if(event.key==='Enter')sendReply(${n.id})">
                        <button class="send-reply" onclick="sendReply(${n.id})"><i class="fas fa-paper-plane"></i></button>
                        <button class="cancel-reply" onclick="closeReply(${n.id})"><i class="fas fa-times"></i></button>
                    </div>
                    ${replyHtml}
                </div>
                ${n.unread ? '<div class="unread-dot"></div>' : ''}
                <button class="delete-btn" onclick="event.stopPropagation();deleteNotif(${n.id})"><i class="fas fa-times"></i></button>
            </div>
        `;
    }).join('');
}

function getReplyHtml(n) {
    if (!n.replies || !n.replies.length) return '';
    return n.replies.map(r =>
        `<div class="reply-item"><span class="reply-user">${r.user}:</span> ${r.text}</div>`
    ).join('');
}

function getActionHtml(n) {
    if (n.type === 'follow') {
        const followed = localStorage.getItem('follow_' + n.id) === 'true';
        const btnClass = followed ? 'following' : 'follow-primary';
        return `<div class="action"><button class="act-btn ${btnClass}" onclick="event.stopPropagation();toggleFollow(${n.id},this)">${followed ? t('unfollow') : t('follow')}</button></div>`;
    } else if (n.type === 'comment' || n.type === 'signal') {
        const isReplyOpen = openReplyId === n.id;
        const btnClass = isReplyOpen ? 'primary' : '';
        return `<div class="action"><button class="act-btn ${btnClass}" onclick="event.stopPropagation();openReply(${n.id})">${t('reply')}</button></div>`;
    }
    return '';
}

function handleClick(id) {
    const n = notifications.find(x => x.id === id);
    if (n && n.unread) {
        n.unread = false;
        markNotifRead(id);
        saveNotifs(notifications);
        renderNotifications();
    }
    if (n && n.link && n.link !== '#') {
        window.location.href = n.link;
    }
}

// ===== Follow =====
function toggleFollow(id, btn) {
    const followed = btn.classList.contains('following');
    if (followed) {
        btn.classList.remove('following');
        btn.classList.add('follow-primary');
        btn.textContent = t('follow');
        localStorage.removeItem('follow_' + id);
        showToast(t('unfollowed'));
    } else {
        btn.classList.remove('follow-primary');
        btn.classList.add('following');
        btn.textContent = t('unfollow');
        localStorage.setItem('follow_' + id, 'true');
        showToast(t('followed'));
    }
}

// ===== Reply =====
function openReply(id) {
    openReplyId = openReplyId === id ? null : id;
    renderNotifications();
    if (openReplyId === id) {
        setTimeout(() => {
            const input = document.getElementById('replyInput-' + id);
            if (input) input.focus();
        }, 100);
    }
}

function closeReply(id) {
    openReplyId = null;
    renderNotifications();
}

async function sendReply(id) {
    const input = document.getElementById('replyInput-' + id);
    if (!input) return;
    const text = input.value.trim();
    if (!text) return;
    const n = notifications.find(x => x.id === id);
    if (!n) return;
    if (!n.replies) n.replies = [];
    n.replies.push({ user: t('you'), text: text, time: Date.now() });
    saveNotifs(notifications);
    input.value = '';
    openReplyId = null;
    renderNotifications();
    showToast(t('reply_sent'));
    try {
        await API.Notifications.reply ? await API.Notifications.reply(id, text) : null;
    } catch (e) {
        console.warn('Reply send error:', e);
    }
}

// ===== Delete =====
async function deleteNotif(id) {
    notifications = notifications.filter(n => n.id !== id);
    saveNotifs(notifications);
    renderNotifications();
    showToast(t('deleted'));
    await deleteNotifAPI(id);
}

// ===== Mark All Read =====
async function markAllRead() {
    notifications.forEach(n => n.unread = false);
    saveNotifs(notifications);
    renderNotifications();
    showToast(t('read_all'));
    await markAllReadAPI();
}

// ===== Filter =====
function setFilter(f, btn) {
    filter = f;
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    renderNotifications();
}

// ===== مقداردهی اولیه =====
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    const lang = getCurrentLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    applyPageTranslations();

    fetchNotifications().then(data => {
        notifications = data;
        saveNotifs(notifications);
        renderNotifications();
        connectWebSocket();
    });

    console.log('✅ notifications.js loaded');
});

// ===== خروجی توابع =====
window.setFilter = setFilter;
window.markAllRead = markAllRead;
window.deleteNotif = deleteNotif;
window.handleClick = handleClick;
window.toggleFollow = toggleFollow;
window.openReply = openReply;
window.closeReply = closeReply;
window.sendReply = sendReply;
window.showToast = showToast;
window.toggleDark = toggleDark;
window.toggleLang = toggleLang;
