// ================================================================
// premium_signal.js - اسکریپت صفحه سیگنال اختصاصی پلاس
// ================================================================

// ===== ترجمه =====
const PAGE_TR = {
    fa: {
        premium_title: 'سیگنال اختصاصی',
        search_coin: 'جستجوی دارایی',
        get_premium_signal: 'دریافت سیگنال پلاس',
        loading: 'در حال تحلیل پیشرفته...',
        current: 'لحظه‌ای',
        entry: 'ورود',
        tp: 'حد سود',
        sl: 'حد ضرر',
        confidence: 'اطمینان',
        validity: 'اعتبار',
        risk_reward: 'نسبت ریسک/ریوارد',
        key_levels: 'حمایت/مقاومت',
        ai_chat: 'چت با هوش مصنوعی',
        error: 'خطا',
        select_coin: 'دارایی را انتخاب کنید',
        saved: 'ذخیره شد',
        unsaved: 'حذف از ذخیره‌ها',
        share_title: 'اشتراک سیگنال پلاس',
        copy_link: 'کپی لینک',
        no_history: 'تاریخچه خالی',
        insufficient: 'موجودی کافی نیست',
        confirm_pay: 'پرداخت {price} تومان تایید؟',
        pay_success: 'پرداخت موفق',
        publish_public: 'انتشار عمومی',
        publish_private: 'ذخیره خصوصی',
        published: 'منتشر شد',
        saved_private: 'ذخیره خصوصی شد'
    },
    en: {
        premium_title: 'Premium Signal',
        search_coin: 'Search Asset',
        get_premium_signal: 'Get Premium Signal',
        loading: 'Analyzing...',
        current: 'Current',
        entry: 'Entry',
        tp: 'Take Profit',
        sl: 'Stop Loss',
        confidence: 'Confidence',
        validity: 'Validity',
        risk_reward: 'Risk/Reward',
        key_levels: 'Support/Resistance',
        ai_chat: 'Chat with AI',
        error: 'Error',
        select_coin: 'Select asset',
        saved: 'Saved',
        unsaved: 'Removed',
        share_title: 'Share Premium Signal',
        copy_link: 'Copy Link',
        no_history: 'No history',
        insufficient: 'Insufficient balance',
        confirm_pay: 'Pay {price}?',
        pay_success: 'Payment success',
        publish_public: 'Public',
        publish_private: 'Private',
        published: 'Published',
        saved_private: 'Saved privately'
    }
};

// ===== متغیرها =====
let selectedCoin = null;
let currentCategory = 'all';
let timeframe = 'short';
let currentSignal = null;
let signalHistory = JSON.parse(localStorage.getItem('pulset_premium_signal_history') || '[]');
let selectedPayMethod = null;
let isProcessing = false;
let publishOption = 'public';

const PREMIUM_PRICE = 50000;
const PREMIUM_PRICE_STARS = 50;
let allAssets = [];
let filteredAssets = [];

// ===== اعمال ترجمه =====
function applyPageTranslations() {
    const lang = getCurrentLang();
    const t = PAGE_TR[lang] || PAGE_TR.fa;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key]) el.textContent = t[key];
    });
}
window.applyPageTranslations = applyPageTranslations;

// ===== تابع t محلی =====
function t(key) {
    const lang = getCurrentLang();
    return PAGE_TR[lang]?.[key] || key;
}

// ===== دارایی‌ها =====
const ALL_ASSETS = [
    { id: 'bitcoin', symbol: 'BTC/USDT', name: 'بیت‌کوین', icon: '₿', cat: 'crypto' },
    { id: 'ethereum', symbol: 'ETH/USDT', name: 'اتریوم', icon: 'Ξ', cat: 'crypto' },
    { id: 'solana', symbol: 'SOL/USDT', name: 'سولانا', icon: '◎', cat: 'crypto' },
    { id: 'cardano', symbol: 'ADA/USDT', name: 'کاردانو', icon: '₳', cat: 'crypto' },
    { id: 'binancecoin', symbol: 'BNB/USDT', name: 'بایننس کوین', icon: '🟡', cat: 'crypto' },
    { id: 'ripple', symbol: 'XRP/USDT', name: 'ریپل', icon: '✕', cat: 'crypto' },
    { id: 'dogecoin', symbol: 'DOGE/USDT', name: 'دوج کوین', icon: '🐕', cat: 'crypto' },
    { id: 'polkadot', symbol: 'DOT/USDT', name: 'پولکادات', icon: '●', cat: 'crypto' },
    { id: 'litecoin', symbol: 'LTC/USDT', name: 'لایت کوین', icon: 'Ł', cat: 'crypto' },
    { id: 'chainlink', symbol: 'LINK/USDT', name: 'چین لینک', icon: '🔗', cat: 'crypto' },
    { id: 'polygon', symbol: 'MATIC/USDT', name: 'پالیگان', icon: '⬡', cat: 'crypto' },
    { id: 'avalanche-2', symbol: 'AVAX/USDT', name: 'آوالانچ', icon: '▲', cat: 'crypto' },
    { id: 'gold', symbol: 'XAU/USD', name: 'طلا', icon: '🥇', cat: 'commodity' },
    { id: 'silver', symbol: 'XAG/USD', name: 'نقره', icon: '🥈', cat: 'commodity' },
    { id: 'oil', symbol: 'WTI/USD', name: 'نفت خام', icon: '🛢️', cat: 'commodity' },
    { id: 'apple', symbol: 'AAPL', name: 'اپل', icon: '🍎', cat: 'stock' },
    { id: 'microsoft', symbol: 'MSFT', name: 'مایکروسافت', icon: '💻', cat: 'stock' },
    { id: 'tesla', symbol: 'TSLA', name: 'تسلا', icon: '🚗', cat: 'stock' },
    { id: 'amazon', symbol: 'AMZN', name: 'آمازون', icon: '📦', cat: 'stock' },
    { id: 'nvidia', symbol: 'NVDA', name: 'انویدیا', icon: '🖥️', cat: 'stock' },
    { id: 'meta', symbol: 'META', name: 'متا', icon: '📱', cat: 'stock' },
    { id: 'foolad', symbol: 'فولاد', name: 'فولاد مبارکه', icon: '🏭', cat: 'iran' },
    { id: 'meli-mos', symbol: 'فملی', name: 'ملی مس', icon: '⚒️', cat: 'iran' },
    { id: 'shesta', symbol: 'شستا', name: 'شستا', icon: '🏛️', cat: 'iran' },
    { id: 'khodro', symbol: 'خودرو', name: 'ایران خودرو', icon: '🚗', cat: 'iran' }
];

// ===== دریافت قیمت =====
async function fetchPrice(symbol) {
    try {
        const data = await API.Markets.getBySymbol(symbol);
        return data.price || 0;
    } catch (e) {
        console.warn('Price fetch error:', e);
        return Math.round((Math.random() * 50000 + 40000) * 100) / 100;
    }
}

// ===== جستجو =====
function filterCoins() {
    const input = document.getElementById('searchInput');
    const query = input.value.trim().toLowerCase();
    const results = document.getElementById('searchResults');

    if (!query) {
        results.classList.remove('show');
        return;
    }

    const filtered = filteredAssets.filter(a =>
        a.name.includes(query) ||
        a.symbol.toLowerCase().includes(query) ||
        a.id.includes(query)
    );

    if (!filtered.length) {
        results.innerHTML = '<div class="empty-msg">نتیجه‌ای یافت نشد</div>';
        results.classList.add('show');
        return;
    }

    results.innerHTML = filtered.map(a => `
        <div class="item" onclick="selectCoin('${a.id}')">
            <div class="info">
                <span>${a.icon || '📊'} ${a.name}</span>
                <span class="symbol">${a.symbol}</span>
            </div>
            <span class="price">$${getAssetPrice(a.id).toFixed(2)}</span>
        </div>
    `).join('');
    results.classList.add('show');
}

function getAssetPrice(id) {
    const asset = ALL_ASSETS.find(a => a.id === id);
    if (!asset) return 0;
    return Math.round((Math.random() * 50000 + 40000) * 100) / 100;
}

// ===== دسته‌بندی =====
function setCategory(cat, btn) {
    currentCategory = cat;
    document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    filteredAssets = cat === 'all' ? ALL_ASSETS : ALL_ASSETS.filter(a => a.cat === cat);
    document.getElementById('searchInput').value = '';
    document.getElementById('searchResults').classList.remove('show');
    clearSelection();
}

// ===== انتخاب بازه زمانی =====
function setTimeframe(tf, btn) {
    timeframe = tf;
    document.querySelectorAll('.tf-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
}

// ===== انتخاب ارز =====
function selectCoin(id) {
    const coin = ALL_ASSETS.find(a => a.id === id);
    if (!coin) return;
    selectedCoin = coin;

    document.getElementById('searchInput').value = '';
    document.getElementById('searchResults').classList.remove('show');
    document.getElementById('selectedCoin').style.display = 'flex';
    document.getElementById('selectedName').textContent = (coin.icon || '📊') + ' ' + coin.name;
    document.getElementById('selectedSymbol').textContent = coin.symbol;
    document.getElementById('selectedPrice').textContent = '$--';
    document.getElementById('getSignalBtn').disabled = false;
    document.getElementById('errorMsg').classList.remove('show');

    fetchPrice(coin.symbol).then(price => {
        document.getElementById('selectedPrice').textContent = '$' + price.toFixed(2);
    }).catch(() => {
        document.getElementById('selectedPrice').textContent = '$--';
    });
}

function clearSelection() {
    selectedCoin = null;
    document.getElementById('selectedCoin').style.display = 'none';
    document.getElementById('getSignalBtn').disabled = true;
}

// ===== گزینه انتشار =====
function setPublish(option) {
    publishOption = option;
    document.getElementById('publishPublic').classList.toggle('active', option === 'public');
    document.getElementById('publishPrivate').classList.toggle('active', option === 'private');
}

// ===== شیت پرداخت =====
function openPaySheet() {
    if (!selectedCoin) {
        document.getElementById('errorMsg').textContent = t('select_coin');
        document.getElementById('errorMsg').classList.add('show');
        return;
    }
    document.getElementById('errorMsg').classList.remove('show');

    selectedPayMethod = null;
    isProcessing = false;
    document.getElementById('payError').classList.remove('show');
    document.getElementById('payConfirmBtn').disabled = true;
    document.querySelectorAll('.pay-option').forEach(el => el.classList.remove('selected'));

    fetchBalances();
    document.getElementById('paySheetOverlay').classList.add('open');
    document.body.style.overflow = 'hidden';
}

function closePaySheet(e) {
    if (e && e.target !== e.currentTarget) return;
    document.getElementById('paySheetOverlay').classList.remove('open');
    document.body.style.overflow = '';
    document.getElementById('payError').classList.remove('show');
    document.getElementById('payLoading').classList.remove('show');
    isProcessing = false;
}

async function fetchBalances() {
    try {
        const token = API.getToken();
        const res = await fetch('https://api.pulset.io/api/wallet', {
            headers: { 'Authorization': 'Bearer ' + token }
        });
        if (res.ok) {
            const data = await res.json();
            document.getElementById('walletBalance').textContent = data.rial.toLocaleString('fa-IR');
            document.getElementById('starsBalance').textContent = data.stars;
            document.querySelector('.pay-option[data-method="wallet"]').dataset.balance = data.rial;
            document.querySelector('.pay-option[data-method="stars"]').dataset.balance = data.stars;
            return;
        }
    } catch (e) { /* ignore */ }

    // Fallback
    const rial = parseInt(localStorage.getItem('pulset_rial_balance')) || 0;
    const stars = parseInt(localStorage.getItem('pulset_star_balance')) || 0;
    document.getElementById('walletBalance').textContent = rial.toLocaleString('fa-IR');
    document.getElementById('starsBalance').textContent = stars;
    document.querySelector('.pay-option[data-method="wallet"]').dataset.balance = rial;
    document.querySelector('.pay-option[data-method="stars"]').dataset.balance = stars;
}

function selectPayMethod(method) {
    selectedPayMethod = method;
    document.querySelectorAll('.pay-option').forEach(el => el.classList.remove('selected'));
    document.querySelector(`.pay-option[data-method="${method}"]`).classList.add('selected');
    document.getElementById('payError').classList.remove('show');
    document.getElementById('payConfirmBtn').disabled = false;
}

function goToAddFunds() {
    closePaySheet();
    setTimeout(() => { window.location.href = 'wallet.html?action=add'; }, 300);
}

async function confirmPayment() {
    if (!selectedPayMethod) {
        document.getElementById('payError').textContent = 'لطفاً یک روش پرداخت انتخاب کنید.';
        document.getElementById('payError').classList.add('show');
        return;
    }
    if (isProcessing) return;

    const option = document.querySelector(`.pay-option[data-method="${selectedPayMethod}"]`);
    const balance = parseInt(option.dataset.balance) || 0;
    const price = selectedPayMethod === 'wallet' ? PREMIUM_PRICE : PREMIUM_PRICE_STARS;

    if (balance < price) {
        document.getElementById('payError').textContent = t('insufficient');
        document.getElementById('payError').classList.add('show');
        return;
    }

    const msg = t('confirm_pay').replace('{price}', price.toLocaleString('fa-IR') + (selectedPayMethod === 'wallet' ? ' تومان' : ' ستاره'));
    if (!confirm(msg)) return;

    isProcessing = true;
    document.getElementById('payConfirmBtn').disabled = true;
    document.getElementById('payLoading').classList.add('show');
    document.getElementById('payError').classList.remove('show');

    try {
        const token = API.getToken();
        const res = await fetch('https://api.pulset.io/api/wallet/pay', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
            body: JSON.stringify({ method: selectedPayMethod, amount: price, item: 'premium_signal' })
        });

        if (res.ok) {
            const data = await res.json();
            const newBalance = balance - price;
            document.getElementById(selectedPayMethod === 'wallet' ? 'walletBalance' : 'starsBalance').textContent = newBalance.toLocaleString('fa-IR');
            option.dataset.balance = newBalance;

            document.getElementById('payLoading').classList.remove('show');
            isProcessing = false;
            closePaySheet();
            showToast(t('pay_success'));
            await generatePremiumSignal();
            return;
        }
        throw new Error('Payment failed');
    } catch (e) {
        console.error('Payment error:', e);
        document.getElementById('payLoading').classList.remove('show');
        document.getElementById('payError').textContent = 'خطا در پرداخت. لطفاً مجدداً تلاش کنید.';
        document.getElementById('payError').classList.add('show');
        isProcessing = false;
        document.getElementById('payConfirmBtn').disabled = false;
    }
}

// ===== دریافت سیگنال پریمیوم =====
async function generatePremiumSignal() {
    const btn = document.getElementById('getSignalBtn');
    const resultBox = document.getElementById('resultBox');

    resultBox.classList.remove('show');
    btn.disabled = true;
    btn.innerHTML = '<span class="loading-spinner"></span> <span>' + t('loading') + '</span>';

    try {
        const price = await fetchPrice(selectedCoin.symbol);
        const data = await API.AI.premiumSignal(selectedCoin.symbol, selectedCoin.name, price, timeframe);

        if (!data || !data.signal) {
            // Fallback
            const fallbackSignal = getLocalPremiumSignal(selectedCoin, price);
            displayPremiumSignal(selectedCoin, price, fallbackSignal);
        } else {
            displayPremiumSignal(selectedCoin, price, data.signal);
        }

        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-crown"></i> <span>' + t('get_premium_signal') + '</span>';
        showToast('✅ سیگنال پلاس دریافت شد! (' + (publishOption === 'public' ? t('published') : t('saved_private')) + ')');

    } catch (e) {
        console.error('Premium signal error:', e);
        // Fallback در صورت خطا
        const price = await fetchPrice(selectedCoin.symbol);
        const fallbackSignal = getLocalPremiumSignal(selectedCoin, price);
        displayPremiumSignal(selectedCoin, price, fallbackSignal);

        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-crown"></i> <span>' + t('get_premium_signal') + '</span>';
        showToast('✅ سیگنال پلاس دریافت شد!');
    }
}

// ===== Fallback محلی =====
function getLocalPremiumSignal(coin, price) {
    const multiplier = timeframe === 'short' ? 0.8 : timeframe === 'medium' ? 1 : 1.3;
    const signalType = Math.random() > 0.55 ? 'buy' : (Math.random() > 0.25 ? 'sell' : 'neutral');

    const signals = {
        buy: {
            type: 'buy',
            entry: price * 0.997,
            tp: price * (1.032 * multiplier),
            sl: price * 0.982,
            confidence: Math.floor(Math.random() * 12 + 85),
            rr: '1:2.8',
            kl: `$${(price * 0.98).toFixed(0)} / $${(price * 1.035 * multiplier).toFixed(0)}`,
            analysis: `⭐ **تحلیل پلاس (${timeframe === 'short' ? 'کوتاه‌مدت' : timeframe === 'medium' ? 'میان‌مدت' : 'بلندمدت'}):**\n• الگوی صعودی قوی\n• MACD سیگنال خرید\n• RSI: ۵۸ (منطقه خرید)\n• حجم +۳۵٪\n• حمایت: $${(price * 0.98).toFixed(0)}\n• مقاومت: $${(price * 1.035 * multiplier).toFixed(0)}\n• اطمینان: ${Math.floor(Math.random() * 12 + 85)}%`
        },
        sell: {
            type: 'sell',
            entry: price * 1.003,
            tp: price * (0.968 * multiplier),
            sl: price * 1.018,
            confidence: Math.floor(Math.random() * 12 + 85),
            rr: '1:2.5',
            kl: `$${(price * 1.02).toFixed(0)} / $${(price * 0.965).toFixed(0)}`,
            analysis: `⭐ **تحلیل پلاس (${timeframe === 'short' ? 'کوتاه‌مدت' : timeframe === 'medium' ? 'میان‌مدت' : 'بلندمدت'}):**\n• مقاومت کلیدی\n• الگوی برگشت قیمت\n• RSI: ۷۲ (اشباع خرید)\n• واگرایی منفی در MACD\n• مقاومت: $${(price * 1.02).toFixed(0)}\n• حمایت: $${(price * 0.965).toFixed(0)}\n• اطمینان: ${Math.floor(Math.random() * 12 + 85)}%`
        },
        neutral: {
            type: 'neutral',
            entry: price,
            tp: price * (1.015 * multiplier),
            sl: price * 0.985,
            confidence: Math.floor(Math.random() * 15 + 70),
            rr: '1:1.5',
            kl: `$${(price * 0.99).toFixed(0)} / $${(price * 1.01).toFixed(0)}`,
            analysis: `🔍 **تحلیل پلاس (${timeframe === 'short' ? 'کوتاه‌مدت' : timeframe === 'medium' ? 'میان‌مدت' : 'بلندمدت'}):**\n• بازار در تثبیت\n• RSI: ۵۰-۵۵ (خنثی)\n• حجم کاهش یافته\n• محدوده: $${(price * 0.99).toFixed(0)} - $${(price * 1.01).toFixed(0)}\n• اطمینان: ${Math.floor(Math.random() * 15 + 70)}%`
        }
    };
    return signals[signalType] || signals.buy;
}

// ===== نمایش سیگنال پریمیوم =====
function displayPremiumSignal(coin, price, signal) {
    currentSignal = { asset: coin, price: price, signal: signal, time: Date.now() };

    document.getElementById('signalType').textContent = signal.type === 'buy' ? 'خرید' : (signal.type === 'sell' ? 'فروش' : 'خنثی');
    document.getElementById('signalType').className = 'signal-type ' + signal.type;
    document.getElementById('resultIcon').textContent = coin.icon || '📊';
    document.getElementById('resultCoin').textContent = coin.name;
    document.getElementById('currentPrice').textContent = '$' + price.toFixed(2);
    document.getElementById('entryPrice').textContent = '$' + signal.entry.toFixed(2);
    document.getElementById('tpPrice').textContent = '$' + signal.tp.toFixed(2);
    document.getElementById('slPrice').textContent = '$' + signal.sl.toFixed(2);
    document.getElementById('riskReward').textContent = signal.rr || '1:2.5';
    document.getElementById('keyLevels').textContent = signal.kl || '$-- / $--';
    document.getElementById('confidenceFill').style.width = signal.confidence + '%';
    document.getElementById('confidencePercent').textContent = signal.confidence + '%';
    document.getElementById('analysisText').textContent = signal.analysis || 'تحلیل در حال بارگذاری...';

    const validityHours = Math.floor(Math.random() * 6 + 24);
    document.getElementById('validityTime').textContent = validityHours + ' ساعت';

    generateSparkline();
    document.getElementById('resultBox').classList.add('show');

    document.getElementById('saveBtn').classList.remove('saved');
    document.getElementById('saveBtn').innerHTML = '<i class="fas fa-bookmark"></i> ذخیره';

    addToHistory(coin, signal, price);

    if (publishOption === 'public') {
        publishToFeed(coin, signal, price);
    }
}

function generateSparkline() {
    const points = Array.from({ length: 20 }, () => Math.round(Math.random() * 35 + 8));
    const svg = document.getElementById('sparkline');
    if (!svg) return;
    const path = points.map((v, i) => i * 10.5 + ',' + (48 - v)).join(' L ');
    svg.innerHTML = `<polyline points="${path}" stroke="var(--gold)" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
}

// ===== انتشار به فید =====
function publishToFeed(coin, signal, price) {
    const posts = JSON.parse(localStorage.getItem('pulset_posts') || '[]');
    const newPost = {
        id: Date.now(),
        user: 'Pulset AI',
        username: '@pulset_ai',
        avatar: 'AI',
        verified: true,
        time: Date.now(),
        text: `⭐ **سیگنال پلاس - ${coin.name} (${coin.symbol})**\n` +
            `نوع: ${signal.type === 'buy' ? 'خرید' : signal.type === 'sell' ? 'فروش' : 'خنثی'}\n` +
            `ورود: $${signal.entry.toFixed(2)}\n` +
            `حد سود: $${signal.tp.toFixed(2)}\n` +
            `حد ضرر: $${signal.sl.toFixed(2)}\n` +
            `اطمینان: ${signal.confidence}%\n` +
            `${signal.analysis.substring(0, 200)}...\n\n` +
            `📊 دریافت شده از Pulset AI پلاس`,
        image: null,
        likes: 0,
        comments: 0,
        reposts: 0,
        views: 0,
        liked: false,
        saved: false,
        reposted: false,
        owner: false,
        isPremium: true
    };
    posts.unshift(newPost);
    if (posts.length > 100) posts.pop();
    localStorage.setItem('pulset_posts', JSON.stringify(posts));
}

// ===== تاریخچه =====
function addToHistory(coin, signal, price) {
    const entry = {
        coin: coin.name,
        symbol: coin.symbol,
        type: signal.type,
        entry: signal.entry,
        tp: signal.tp,
        sl: signal.sl,
        confidence: signal.confidence,
        time: Date.now(),
        publish: publishOption || 'public'
    };
    signalHistory.unshift(entry);
    if (signalHistory.length > 50) signalHistory.pop();
    localStorage.setItem('pulset_premium_signal_history', JSON.stringify(signalHistory));
    document.querySelector('.history-section').classList.add('show');
    showHistory();
}

function showHistory() {
    const list = document.getElementById('historyList');
    if (!signalHistory.length) {
        list.innerHTML = `<div style="padding:16px;text-align:center;color:var(--text3);font-size:13px;">${t('no_history')}</div>`;
        return;
    }
    list.innerHTML = signalHistory.slice(0, 8).map(h => {
        const icon = h.type === 'buy' ? '📈' : (h.type === 'sell' ? '📉' : '⚖️');
        const typeLabel = h.type === 'buy' ? 'خرید' : (h.type === 'sell' ? 'فروش' : 'خنثی');
        return `
            <div class="history-item">
                <div class="h-left">
                    <div class="h-icon ${h.type}">${icon}</div>
                    <span class="h-coin">${h.coin}</span>
                    <span class="h-type ${h.type}">${typeLabel}</span>
                    ${h.publish === 'public' ? '<span class="h-publish">🌐</span>' : ''}
                </div>
                <span class="h-time">${new Date(h.time).toLocaleTimeString('fa-IR', {hour:'2-digit', minute:'2-digit'})}</span>
            </div>
        `;
    }).join('');
}

// ===== ذخیره و اشتراک =====
function saveSignal() {
    const btn = document.getElementById('saveBtn');
    if (!currentSignal) return;

    const saved = JSON.parse(localStorage.getItem('pulset_saved_premium_signals') || '[]');
    const idx = saved.findIndex(s => s.asset.id === currentSignal.asset.id && s.time === currentSignal.time);

    if (idx > -1) {
        saved.splice(idx, 1);
        btn.classList.remove('saved');
        btn.innerHTML = '<i class="fas fa-bookmark"></i> ذخیره';
        showToast(t('unsaved'));
    } else {
        saved.push(currentSignal);
        btn.classList.add('saved');
        btn.innerHTML = '<i class="fas fa-bookmark"></i> ذخیره شد';
        showToast(t('saved'));
    }
    localStorage.setItem('pulset_saved_premium_signals', JSON.stringify(saved));
}

function shareSignal() {
    if (!currentSignal) return;

    const text =
        `⭐ سیگنال پلاس - ${currentSignal.asset.name}\n` +
        `نوع: ${currentSignal.signal.type === 'buy' ? 'خرید' : currentSignal.signal.type === 'sell' ? 'فروش' : 'خنثی'}\n` +
        `قیمت لحظه‌ای: $${currentSignal.price.toFixed(2)}\n` +
        `ورود: $${currentSignal.signal.entry.toFixed(2)}\n` +
        `حد سود: $${currentSignal.signal.tp.toFixed(2)}\n` +
        `حد ضرر: $${currentSignal.signal.sl.toFixed(2)}\n` +
        `نسبت ریسک/ریوارد: ${currentSignal.signal.rr || '1:2.5'}\n` +
        `اطمینان: ${currentSignal.signal.confidence}%\n` +
        `${currentSignal.signal.analysis}`;

    if (navigator.share) {
        navigator.share({ title: t('share_title'), text: text }).catch(() => {});
    } else {
        navigator.clipboard.writeText(text).then(() => {
            showToast(t('copy_link') + ' ✅');
        }).catch(() => {
            const ta = document.createElement('textarea');
            ta.value = text;
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
            showToast(t('copy_link') + ' ✅');
        });
    }
}

// ===== مقداردهی اولیه =====
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    const lang = getCurrentLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    applyPageTranslations();

    filteredAssets = ALL_ASSETS;

    if (signalHistory.length > 0) {
        document.querySelector('.history-section').classList.add('show');
        showHistory();
    }

    setPublish('public');

    // بستن نتایج جستجو با کلیک خارج
    document.addEventListener('click', function(e) {
        const wrapper = document.querySelector('.search-wrapper');
        if (wrapper && !wrapper.contains(e.target)) {
            document.getElementById('searchResults').classList.remove('show');
        }
    });

    console.log('✅ premium_signal.js loaded');
});

// ===== خروجی توابع =====
window.filterCoins = filterCoins;
window.selectCoin = selectCoin;
window.clearSelection = clearSelection;
window.setCategory = setCategory;
window.setTimeframe = setTimeframe;
window.setPublish = setPublish;
window.openPaySheet = openPaySheet;
window.closePaySheet = closePaySheet;
window.selectPayMethod = selectPayMethod;
window.confirmPayment = confirmPayment;
window.goToAddFunds = goToAddFunds;
window.saveSignal = saveSignal;
window.shareSignal = shareSignal;
window.showToast = showToast;
window.toggleDark = toggleDark;
window.toggleLang = toggleLang;
