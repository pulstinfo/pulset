// ================================================================
// shop.js - اسکریپت صفحه فروشگاه
// ================================================================

// ===== متغیرها =====
let products = [];
let cart = JSON.parse(localStorage.getItem('pulset_shop_cart') || '[]');
let currentCategory = 'all';
let giftProductId = null;
let isLoading = false;

// ===== ترجمه =====
const PAGE_TR = {
    fa: {
        add_to_cart: '➕ افزودن',
        in_cart: '✅ در سبد',
        buy: 'خرید',
        gift: '🎁 هدیه',
        buy_stars: '⭐ با ستاره',
        active: '✅ فعال',
        cart_empty: 'سبد خرید خالی است',
        checkout: '💰 پرداخت',
        clear_cart: '🗑️ خالی کردن',
        total: 'جمع کل',
        discount: '🎉 تخفیف ترکیبی {discount}% برای {count} محصول',
        discount_hint: 'خرید ۲ محصول = ۱۰٪ تخفیف، ۳ محصول = ۲۰٪',
        gift_title: '🎁 هدیه دادن',
        gift_desc: 'این محصول را به یکی از دوستان خود هدیه دهید.',
        gift_label: 'ایمیل یا شماره تلفن یا نام کاربری',
        gift_sent: '🎁 هدیه "{product}" برای {recipient} ارسال شد!',
        gift_required: '⚠️ لطفاً اطلاعات گیرنده را وارد کنید',
        buy_stars_confirm: 'آیا از خرید "{product}" با {stars} ستاره مطمئنید؟',
        stars_insufficient: '⚠️ موجودی ستاره شما کافی نیست. ({stars} از {needed})',
        payment_success: '✅ پرداخت موفق! دسترسی‌ها فعال شد.',
        product_added: '✅ به سبد خرید اضافه شد',
        product_removed: '🗑️ حذف شد',
        cart_cleared: '🗑️ سبد خرید خالی شد'
    },
    en: {
        add_to_cart: '➕ Add',
        in_cart: '✅ In Cart',
        buy: 'Buy',
        gift: '🎁 Gift',
        buy_stars: '⭐ With Stars',
        active: '✅ Active',
        cart_empty: 'Cart is empty',
        checkout: '💰 Checkout',
        clear_cart: '🗑️ Clear',
        total: 'Total',
        discount: '🎉 {discount}% combo discount for {count} items',
        discount_hint: 'Buy 2 items = 10% off, 3 items = 20% off',
        gift_title: '🎁 Send as Gift',
        gift_desc: 'Send this product to a friend.',
        gift_label: 'Email, phone, or username',
        gift_sent: '🎁 "{product}" sent to {recipient}!',
        gift_required: '⚠️ Please enter recipient info',
        buy_stars_confirm: 'Buy "{product}" with {stars} stars?',
        stars_insufficient: '⚠️ Insufficient stars. ({stars} of {needed})',
        payment_success: '✅ Payment successful! Access granted.',
        product_added: '✅ Added to cart',
        product_removed: '🗑️ Removed',
        cart_cleared: '🗑️ Cart cleared'
    }
};

function t(key, params) {
    const lang = getCurrentLang();
    let text = PAGE_TR[lang]?.[key] || key;
    if (params) {
        Object.keys(params).forEach(k => {
            text = text.replace(new RegExp('\\{' + k + '\\}', 'g'), params[k]);
        });
    }
    return text;
}

function applyPageTranslations() {
    // ترجمه‌های داینامیک در رندرها انجام می‌شود
}
window.applyPageTranslations = applyPageTranslations;

// ===== داده‌های پیش‌فرض =====
function getDefaultProducts() {
    return [
        { id: 'edu_basic', name: 'بسته آموزشی مقدماتی', icon: '📚', category: 'education', price: 250000, starsPrice: 150, desc: 'آموزش کامل تحلیل تکنیکال و فاندامنتال برای مبتدیان', discount: 0 },
        { id: 'edu_advanced', name: 'بسته آموزشی پیشرفته', icon: '📖', category: 'education', price: 450000, starsPrice: 300, desc: 'استراتژی‌های معاملاتی حرفه‌ای و مدیریت ریسک', discount: 10 },
        { id: 'consulting_30', name: 'مشاوره تخصصی (۳۰ دقیقه)', icon: '🎯', category: 'consulting', price: 350000, starsPrice: 200, desc: 'مشاوره یک‌به‌یک با متخصص ترید', discount: 0 },
        { id: 'consulting_60', name: 'مشاوره تخصصی (۶۰ دقیقه)', icon: '🎯', category: 'consulting', price: 600000, starsPrice: 350, desc: 'مشاوره عمیق با تحلیل پرتفوی', discount: 15 },
        { id: 'ai_premium', name: 'هوش مصنوعی پلاس', icon: '🧠', category: 'ai', price: 500000, starsPrice: 300, desc: 'تحلیل پیشرفته با جزئیات کامل', discount: 0 },
        { id: 'ai_pro', name: 'هوش مصنوعی پرو', icon: '🤖', category: 'ai', price: 850000, starsPrice: 500, desc: 'همه امکانات پلاس + تحلیل پرتفوی خودکار', discount: 20 },
        { id: 'sub_monthly', name: 'اشتراک ماهانه', icon: '📅', category: 'subscription', price: 300000, starsPrice: 180, desc: 'دسترسی کامل به همه خدمات به مدت یک ماه', discount: 0 },
        { id: 'sub_quarterly', name: 'اشتراک ۳ ماهه', icon: '📅', category: 'subscription', price: 750000, starsPrice: 450, desc: 'دسترسی کامل + تخفیف ویژه', discount: 15 },
        { id: 'sub_yearly', name: 'اشتراک سالانه', icon: '📅', category: 'subscription', price: 2500000, starsPrice: 1500, desc: 'دسترسی کامل + تخفیف ۳۰٪ + مشاوره رایگان', discount: 30 }
    ];
}

// ===== دریافت محصولات از API =====
async function loadProducts() {
    const grid = document.getElementById('productsGrid');
    isLoading = true;
    grid.innerHTML = '<div class="loading-shimmer"><div class="spinner"></div><span>در حال بارگذاری محصولات...</span></div>';

    try {
        const data = await API.Shop.getProducts(currentCategory);
        if (data && data.length) {
            products = data;
        } else {
            products = getDefaultProducts();
        }
    } catch (e) {
        console.warn('Load products error, using fallback:', e);
        products = getDefaultProducts();
    }

    isLoading = false;
    renderProducts();
    updateCartBadge();
}

// ===== رندر محصولات =====
function renderProducts() {
    const grid = document.getElementById('productsGrid');
    const filtered = currentCategory === 'all' ? products : products.filter(p => p.category === currentCategory);

    if (!filtered.length) {
        grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:40px 0;color:var(--text3);font-size:14px;">هیچ محصولی در این دسته وجود ندارد</div>';
        return;
    }

    grid.innerHTML = filtered.map(p => {
        const inCart = cart.some(c => c.id === p.id);
        const btnText = inCart ? t('in_cart') : t('add_to_cart');
        const btnClass = inCart ? 'outline' : '';
        const discountHtml = p.discount > 0 ? `<span class="discount">-${p.discount}%</span>` : '';
        const oldPriceHtml = p.discount > 0 ? `<span class="old">${formatPrice(p.price * (1 + p.discount / 100))}</span>` : '';

        // بررسی دسترسی فعال
        let hasAccess = false;
        if (window.Permissions) {
            if (p.id === 'sub_monthly' || p.id === 'sub_quarterly' || p.id === 'sub_yearly') {
                hasAccess = Permissions.isSubscriptionActive() && Permissions.getSubscriptionType() !== 'free';
            } else if (p.category === 'ai') {
                hasAccess = Permissions.hasPremiumSignalAccess();
            } else if (p.category === 'consulting') {
                hasAccess = Permissions.hasConsultingAccess();
            } else if (p.category === 'education') {
                hasAccess = Permissions.hasEducationPackage(p.id.replace('edu_', ''));
            }
        }

        const statusBadge = hasAccess ? `<span class="active-badge">✅ ${t('active')}</span>` : '';

        return `
            <div class="product-card" data-id="${p.id}">
                <span class="icon">${p.icon}</span>
                ${statusBadge}
                <div class="name">${p.name}</div>
                <div class="desc">${p.desc}</div>
                <div class="price-row">
                    <span class="price">${formatPrice(p.price)} <span class="currency">تومان</span></span>
                    ${oldPriceHtml}
                    ${discountHtml}
                </div>
                <div class="stars-price"><i class="fas fa-star" style="color:var(--gold);"></i> ${p.starsPrice} ستاره</div>
                <button class="btn-buy ${btnClass}" onclick="addToCart('${p.id}')" ${hasAccess ? 'disabled' : ''}>
                    <span class="icon-small"><i class="fas ${inCart ? 'fa-check' : 'fa-plus'}"></i></span>
                    ${hasAccess ? t('active') : btnText}
                </button>
                <div class="action-row">
                    <button class="btn" onclick="event.stopPropagation();openGift('${p.id}')" ${hasAccess ? 'disabled' : ''}>
                        <i class="fas fa-gift"></i> ${t('gift')}
                    </button>
                    <button class="btn" onclick="event.stopPropagation();buyWithStars('${p.id}')" ${hasAccess ? 'disabled' : ''}>
                        <i class="fas fa-star"></i> ${t('buy_stars')}
                    </button>
                </div>
            </div>
        `;
    }).join('');
}

// ===== فیلتر =====
function filterProducts(cat, btn) {
    currentCategory = cat;
    document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    renderProducts();
}

// ===== سبد خرید =====
function updateCartBadge() {
    const total = cart.reduce((sum, c) => sum + c.qty, 0);
    const badge = document.getElementById('cartBadge');
    if (badge) badge.textContent = total;
}

function renderCart() {
    const container = document.getElementById('cartContent');
    if (!cart.length) {
        container.innerHTML = `
            <div class="cart-empty">
                <span class="icon"><i class="fas fa-shopping-cart"></i></span>
                <div style="font-size:14px;color:var(--text3);">${t('cart_empty')}</div>
            </div>
        `;
        return;
    }

    let total = 0;
    const html = cart.map(item => {
        const p = products.find(pr => pr.id === item.id);
        if (!p) return '';
        const itemTotal = p.price * item.qty;
        total += itemTotal;
        return `
            <div class="cart-item">
                <span class="icon">${p.icon}</span>
                <div class="info">
                    <div class="name">${p.name}</div>
                    <div class="price">${formatPrice(itemTotal)} تومان</div>
                </div>
                <div class="qty">
                    <button onclick="updateQty('${p.id}',-1)">−</button>
                    <span>${item.qty}</span>
                    <button onclick="updateQty('${p.id}',1)">+</button>
                </div>
                <button class="remove" onclick="removeFromCart('${p.id}')"><i class="fas fa-times"></i></button>
            </div>
        `;
    }).join('');

    let discount = 0;
    if (cart.length >= 3) discount = 20;
    else if (cart.length >= 2) discount = 10;

    const finalTotal = total - (total * discount / 100);

    container.innerHTML = html + `
        <div style="padding:6px 0;font-size:12px;color:var(--text3);">
            ${discount > 0 ? t('discount', { discount: discount, count: cart.length }) : t('discount_hint')}
        </div>
        <div class="cart-total">
            <span>${t('total')}</span>
            <span class="price">${formatPrice(finalTotal)} تومان</span>
        </div>
        <div class="cart-actions">
            <button class="btn outline" onclick="clearCart()">${t('clear_cart')}</button>
            <button class="btn primary" onclick="checkout()" ${cart.length === 0 ? 'disabled' : ''}>${t('checkout')}</button>
        </div>
    `;
    updateCartBadge();
}

function toggleCart() {
    document.getElementById('cartOverlay').classList.toggle('open');
    renderCart();
}

function closeCart() {
    document.getElementById('cartOverlay').classList.remove('open');
}

async function addToCart(id) {
    const existing = cart.find(c => c.id === id);
    if (existing) {
        existing.qty += 1;
    } else {
        cart.push({ id: id, qty: 1 });
    }
    localStorage.setItem('pulset_shop_cart', JSON.stringify(cart));
    try { await API.Shop.addToCart(id, 1); } catch (e) { /* ignore */ }
    renderProducts();
    renderCart();
    showToast(t('product_added'));
}

function updateQty(id, delta) {
    const item = cart.find(c => c.id === id);
    if (!item) return;
    item.qty += delta;
    if (item.qty <= 0) {
        cart = cart.filter(c => c.id !== id);
    }
    localStorage.setItem('pulset_shop_cart', JSON.stringify(cart));
    renderCart();
    renderProducts();
}

function removeFromCart(id) {
    cart = cart.filter(c => c.id !== id);
    localStorage.setItem('pulset_shop_cart', JSON.stringify(cart));
    renderCart();
    renderProducts();
    showToast(t('product_removed'));
}

function clearCart() {
    if (!cart.length) return;
    if (!confirm('آیا از خالی کردن سبد خرید مطمئنید؟')) return;
    cart = [];
    localStorage.setItem('pulset_shop_cart', JSON.stringify(cart));
    try { API.Shop.clearCart().catch(() => {}); } catch (e) { /* ignore */ }
    renderCart();
    renderProducts();
    showToast(t('cart_cleared'));
}

async function checkout() {
    if (!cart.length) {
        showToast('سبد خرید خالی است');
        return;
    }

    let total = 0;
    cart.forEach(item => {
        const p = products.find(pr => pr.id === item.id);
        if (p) total += p.price * item.qty;
    });

    let discount = 0;
    if (cart.length >= 3) discount = 20;
    else if (cart.length >= 2) discount = 10;
    const finalTotal = total - (total * discount / 100);

    showToast('⏳ در حال انتقال به درگاه پرداخت... مبلغ: ' + formatPrice(finalTotal) + ' تومان');

    try {
        const data = await API.Shop.checkout({ items: cart, total: finalTotal, discount: discount });
        if (data && data.success) {
            // اعمال دسترسی‌ها
            cart.forEach(item => {
                if (window.Permissions) {
                    Permissions.applyPurchase(item.id);
                }
            });
            cart = [];
            localStorage.setItem('pulset_shop_cart', JSON.stringify(cart));
            renderCart();
            renderProducts();
            showToast(t('payment_success'));
        } else {
            throw new Error('Checkout failed');
        }
    } catch (e) {
        // Fallback: فعال‌سازی دسترسی‌ها به صورت محلی
        cart.forEach(item => {
            if (window.Permissions) {
                Permissions.applyPurchase(item.id);
            }
        });
        cart = [];
        localStorage.setItem('pulset_shop_cart', JSON.stringify(cart));
        renderCart();
        renderProducts();
        showToast(t('payment_success'));
    }
}

// ===== خرید با ستاره =====
function buyWithStars(id) {
    const p = products.find(pr => pr.id === id);
    if (!p) return;

    const stars = parseInt(localStorage.getItem('pulset_star_balance')) || 0;
    if (stars < p.starsPrice) {
        showToast(t('stars_insufficient', { stars: stars, needed: p.starsPrice }));
        return;
    }

    if (!confirm(t('buy_stars_confirm', { product: p.name, stars: p.starsPrice }))) return;

    const newStars = stars - p.starsPrice;
    localStorage.setItem('pulset_star_balance', String(newStars));
    if (window.Permissions) {
        Permissions.applyPurchase(id);
    }
    showToast('✅ "' + p.name + '" با ' + p.starsPrice + ' ستاره خریداری شد!');
    renderProducts();
}

// ===== هدیه دادن =====
function openGift(id) {
    const p = products.find(pr => pr.id === id);
    if (!p) return;
    giftProductId = id;
    document.getElementById('giftOverlay').classList.add('show');
    document.getElementById('giftInput').value = '';
    document.getElementById('giftInput').focus();
}

function closeGift() {
    document.getElementById('giftOverlay').classList.remove('show');
    giftProductId = null;
}

async function sendGift() {
    const input = document.getElementById('giftInput').value.trim();
    if (!input) {
        showToast(t('gift_required'));
        return;
    }

    const p = products.find(pr => pr.id === giftProductId);
    if (!p) {
        showToast('⚠️ محصول یافت نشد');
        return;
    }

    closeGift();
    showToast(t('gift_sent', { product: p.name, recipient: input }));

    try {
        await API.Shop.gift(giftProductId, input);
    } catch (e) {
        console.warn('Gift API error:', e);
    }
}

// ===== کمکی =====
function formatPrice(price) {
    return price.toLocaleString('fa-IR');
}

// ===== مقداردهی اولیه =====
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    const lang = getCurrentLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    applyPageTranslations();

    loadProducts();
    updateCartBadge();

    // بستن سبد با کلیک خارج
    document.getElementById('cartOverlay').addEventListener('click', function(e) {
        if (e.target === this) closeCart();
    });
    document.getElementById('giftOverlay').addEventListener('click', function(e) {
        if (e.target === this) closeGift();
    });

    console.log('✅ shop.js loaded');
});

// ===== خروجی توابع =====
window.filterProducts = filterProducts;
window.addToCart = addToCart;
window.toggleCart = toggleCart;
window.closeCart = closeCart;
window.updateQty = updateQty;
window.removeFromCart = removeFromCart;
window.clearCart = clearCart;
window.checkout = checkout;
window.openGift = openGift;
window.closeGift = closeGift;
window.sendGift = sendGift;
window.buyWithStars = buyWithStars;
window.showToast = showToast;
window.renderProducts = renderProducts;
window.renderCart = renderCart;
window.loadProducts = loadProducts;
