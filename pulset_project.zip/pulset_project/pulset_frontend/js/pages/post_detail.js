// ================================================================
// post_detail.js - اسکریپت صفحه جزئیات پست
// ================================================================

// ===== ترجمه =====
const PAGE_TR = {
    fa: {
        pageTitle: 'پست',
        like: 'لایک',
        comment: 'کامنت',
        share: 'اشتراک',
        comments_title: 'کامنت‌ها',
        loading: 'در حال بارگذاری...',
        not_found: 'پست یافت نشد',
        liked: 'لایک شد',
        unliked: 'لایک لغو شد',
        share_title: 'اشتراک‌گذاری پست',
        copy_link: 'کپی لینک'
    },
    en: {
        pageTitle: 'Post',
        like: 'Like',
        comment: 'Comment',
        share: 'Share',
        comments_title: 'Comments',
        loading: 'Loading...',
        not_found: 'Post not found',
        liked: 'Liked',
        unliked: 'Unliked',
        share_title: 'Share Post',
        copy_link: 'Copy Link'
    }
};

// ===== متغیرها =====
let postId = null;
let postData = null;
let isLiked = false;

// ===== اعمال ترجمه =====
function applyPageTranslations() {
    const lang = getCurrentLang();
    const t = PAGE_TR[lang] || PAGE_TR.fa;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key]) el.textContent = t[key];
    });
}
window.applyPageTranslations = applyPageTranslations;

// ===== تابع t محلی =====
function t(key) {
    const lang = getCurrentLang();
    return PAGE_TR[lang]?.[key] || key;
}

// ===== دریافت پست =====
async function fetchPost(id) {
    try {
        // تلاش برای دریافت از API
        const data = await API.Posts.getPost ? await API.Posts.getPost(id) : null;
        if (data) return data;
    } catch (e) {
        console.warn('Fetch post API error:', e);
    }

    // Fallback: جستجو در localStorage
    try {
        const posts = JSON.parse(localStorage.getItem('pulset_posts') || '[]');
        const found = posts.find(p => p.id === parseInt(id) || p.id === id);
        if (found) return found;
    } catch (e) { /* ignore */ }

    // نمونه پست
    return {
        id: parseInt(id) || 1,
        user: 'علی معامله‌گر',
        username: '@ali_trades',
        avatar: 'ع',
        text: 'بیت‌کوین در تایم ۴ ساعته به مقاومت ۶۸ هزار دلار رسیده. به نظرتون می‌تونه این بار عبور کنه؟',
        time: Date.now() - 180000,
        likes: 28,
        comments: 12,
        reposts: 4,
        views: 245,
        liked: false,
        image: null
    };
}

// ===== رندر پست =====
function renderPost(post) {
    if (!post) {
        document.getElementById('postText').textContent = t('not_found');
        return;
    }

    postData = post;
    isLiked = post.liked || false;

    document.getElementById('postAvatar').textContent = post.avatar || 'ع';
    document.getElementById('postUserName').textContent = post.user || 'کاربر';
    document.getElementById('postUserHandle').textContent = post.username || '@user';
    document.getElementById('postTime').textContent = formatTime(post.time);
    document.getElementById('postText').textContent = post.text || '';

    // مدیا
    const mediaContainer = document.getElementById('postMedia');
    if (post.image) {
        mediaContainer.innerHTML = `<img src="${post.image}" alt="تصویر پست" loading="lazy" />`;
    } else if (post.media && post.media.length > 0) {
        const img = post.media.find(m => m.type === 'image');
        if (img) mediaContainer.innerHTML = `<img src="${img.url}" alt="تصویر پست" loading="lazy" />`;
        else mediaContainer.innerHTML = '';
    } else {
        mediaContainer.innerHTML = '';
    }

    // آمار
    document.getElementById('postLikes').textContent = post.likes || 0;
    document.getElementById('postComments').textContent = post.comments || 0;
    document.getElementById('postReposts').textContent = post.reposts || 0;
    document.getElementById('postViews').textContent = post.views || 0;

    // دکمه لایک
    const likeBtn = document.getElementById('likeBtn');
    if (isLiked) {
        likeBtn.classList.add('liked');
        likeBtn.querySelector('i').className = 'fas fa-heart';
    } else {
        likeBtn.classList.remove('liked');
        likeBtn.querySelector('i').className = 'far fa-heart';
    }

    // ذخیره در localStorage برای کامنت‌ها
    const commentsContainer = document.getElementById('commentsList');
    if (post.commentsData && post.commentsData.length) {
        commentsContainer.innerHTML = post.commentsData.map(c => `
            <div class="comment-item">
                <div class="comment-avatar">${c.avatar || 'ع'}</div>
                <div class="comment-content">
                    <div class="comment-name">${c.user || 'کاربر'}</div>
                    <div class="comment-text">${c.text}</div>
                </div>
            </div>
        `).join('');
    }
}

// ===== لایک =====
async function toggleLike() {
    if (!postData) return;

    try {
        if (isLiked) {
            await API.Posts.unlike ? await API.Posts.unlike(postData.id) : null;
        } else {
            await API.Posts.like ? await API.Posts.like(postData.id) : null;
        }
    } catch (e) { /* ignore */ }

    isLiked = !isLiked;
    postData.likes += isLiked ? 1 : -1;
    postData.liked = isLiked;
    renderPost(postData);
    showToast(isLiked ? t('liked') : t('unliked'));
}

// ===== اشتراک =====
function sharePost() {
    const url = window.location.href;
    if (navigator.share) {
        navigator.share({
            title: t('share_title'),
            text: postData?.text || 'Pulset',
            url: url
        }).catch(() => {});
    } else {
        navigator.clipboard.writeText(url).then(() => {
            showToast(t('copy_link') + ' ✅');
        }).catch(() => {
            const ta = document.createElement('textarea');
            ta.value = url;
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
            showToast(t('copy_link') + ' ✅');
        });
    }
}

// ===== مقداردهی اولیه =====
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    const lang = getCurrentLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    applyPageTranslations();

    // دریافت ID از URL
    const params = new URLSearchParams(window.location.search);
    postId = params.get('id') || params.get('post') || 1;

    fetchPost(postId).then(post => {
        renderPost(post);
    });

    console.log('✅ post_detail.js loaded for ID:', postId);
});

// ===== خروجی توابع =====
window.toggleLike = toggleLike;
window.sharePost = sharePost;
window.showToast = showToast;
window.toggleDark = toggleDark;
window.toggleLang = toggleLang;
