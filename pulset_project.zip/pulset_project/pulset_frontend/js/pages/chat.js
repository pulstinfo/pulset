// ================================================================
// chat.js - اسکریپت صفحه چت
// ================================================================

// ===== ترجمه صفحه =====
const PAGE_TR = {
    fa: {
        chats_title: 'چت‌ها',
        search: 'جستجوی چت‌ها...',
        online: 'آنلاین',
        offline: 'آفلاین',
        empty: 'هیچ چتی وجود ندارد',
        empty_desc: 'با معامله‌گران دیگر ارتباط برقرار کنید.',
        placeholder: 'پیام خود را بنویسید...',
        blocked: 'کاربر بلاک شد',
        unblocked: 'بلاک کاربر برداشته شد',
        reported: 'گزارش ارسال شد',
        history_cleared: 'تاریخچه پاک شد',
        search_placeholder: 'جستجو در پیام‌ها...',
        no_results: 'نتیجه‌ای یافت نشد',
        you: 'شما'
    },
    en: {
        chats_title: 'Chats',
        search: 'Search chats...',
        online: 'Online',
        offline: 'Offline',
        empty: 'No chats yet',
        empty_desc: 'Connect with other traders.',
        placeholder: 'Write a message...',
        blocked: 'User blocked',
        unblocked: 'User unblocked',
        reported: 'Report sent',
        history_cleared: 'History cleared',
        search_placeholder: 'Search messages...',
        no_results: 'No results found',
        you: 'You'
    }
};

// ===== متغیرها =====
let currentChatId = null;
let isBlocked = false;
let chats = [];
let messages = {};
let dropOpen = false;
let wsUnsubscribe = null;

// ===== اعمال ترجمه =====
function applyPageTranslations() {
    const lang = getCurrentLang();
    const t = PAGE_TR[lang] || PAGE_TR.fa;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key]) el.textContent = t[key];
    });
    document.getElementById('chatInput').placeholder = t.placeholder;
    document.getElementById('searchChats').placeholder = t.search;
    document.getElementById('searchMessagesInput').placeholder = t.search_placeholder;
}
window.applyPageTranslations = applyPageTranslations;

// ===== داده‌های نمونه =====
const SAMPLE_CHATS = [
    { id: 1, name: 'علی معامله‌گر', handle: '@ali_trades', avatar: 'ع', verified: true, online: true, lastMsg: 'سلام! تحلیل بیت‌کوین رو دیدی؟', time: Date.now() - 120000, unread: 2 },
    { id: 2, name: 'مریم تریدر', handle: '@mary_crypto', avatar: 'م', verified: false, online: false, lastMsg: 'ممنون از سیگنالت! عالی بود.', time: Date.now() - 1800000, unread: 0 },
    { id: 3, name: 'حسین تحلیلگر', handle: '@hossein_fx', avatar: 'ح', verified: true, online: true, lastMsg: 'جلسه تحلیل فردا ساعت ۱۰', time: Date.now() - 3600000, unread: 0 },
    { id: 4, name: 'سارا اسکالپر', handle: '@sara_scalp', avatar: 'س', verified: false, online: false, lastMsg: 'توی مارکت امروز چه خبر؟', time: Date.now() - 7200000, unread: 1 }
];

const SAMPLE_MSGS = {
    1: [
        { id: 1, sender: 'other', text: 'سلام! تحلیل بیت‌کوین رو دیدی؟', time: Date.now() - 120000, status: 'read' },
        { id: 2, sender: 'me', text: 'سلام! بله دیدم. نظرت چیه؟', time: Date.now() - 90000, status: 'read' },
        { id: 3, sender: 'other', text: 'به نظر من مقاومت ۶۸K رو می‌شکنه.', time: Date.now() - 60000, status: 'read' },
        { id: 4, sender: 'me', text: 'موافقم. حجم خرید بالاست.', time: Date.now() - 30000, status: 'delivered' }
    ],
    2: [
        { id: 5, sender: 'other', text: 'ممنون از سیگنالت! عالی بود.', time: Date.now() - 1800000, status: 'read' },
        { id: 6, sender: 'me', text: 'خواهش میکنم. بازم سوالی بود بپرس.', time: Date.now() - 1500000, status: 'read' }
    ],
    3: [
        { id: 7, sender: 'other', text: 'جلسه تحلیل فردا ساعت ۱۰', time: Date.now() - 3600000, status: 'read' },
        { id: 8, sender: 'me', text: 'حتما حاضر هستم.', time: Date.now() - 3300000, status: 'read' }
    ],
    4: [
        { id: 9, sender: 'other', text: 'توی مارکت امروز چه خبر؟', time: Date.now() - 7200000, status: 'read' },
        { id: 10, sender: 'me', text: 'همون روند قبلی. بازم سوالی بود بپرس.', time: Date.now() - 6900000, status: 'read' }
    ]
};

// ===== دریافت از API =====
async function fetchChats() {
    try {
        const data = await API.Chat.getChats();
        if (data && data.length) {
            return data.map(c => ({
                id: c.id,
                name: c.name || 'کاربر',
                handle: c.handle || '@' + c.name,
                avatar: c.avatar || 'ع',
                verified: c.verified || false,
                online: c.online || false,
                lastMsg: c.lastMsg || '',
                time: c.time || Date.now(),
                unread: c.unread || 0
            }));
        }
        return SAMPLE_CHATS;
    } catch (e) {
        console.warn('Fetch chats error, using fallback:', e);
        try {
            const local = localStorage.getItem('pulset_chats');
            if (local) return JSON.parse(local);
        } catch (e) { /* ignore */ }
        return SAMPLE_CHATS;
    }
}

async function fetchMessages(chatId) {
    try {
        const data = await API.Chat.getMessages(chatId);
        if (data && data.length) {
            return data;
        }
        return SAMPLE_MSGS[chatId] || [];
    } catch (e) {
        console.warn('Fetch messages error, using fallback:', e);
        try {
            const local = localStorage.getItem('pulset_msgs_' + chatId);
            if (local) return JSON.parse(local);
        } catch (e) { /* ignore */ }
        return SAMPLE_MSGS[chatId] || [];
    }
}

async function sendMessageToAPI(chatId, text) {
    try {
        const data = await API.Chat.sendMessage(chatId, text);
        return data;
    } catch (e) {
        console.warn('Send message error:', e);
        return null;
    }
}

// ===== WebSocket =====
function connectWebSocket(chatId) {
    if (wsUnsubscribe) {
        wsUnsubscribe();
        wsUnsubscribe = null;
    }
    const token = API.getToken();
    if (!token) return;
    wsUnsubscribe = API.WS.subscribe('chat', (data) => {
        if (data.type === 'message' && data.chatId === chatId) {
            const msgs = getMessages(chatId);
            const newMsg = {
                id: data.id || Date.now(),
                sender: data.sender === 'me' ? 'me' : 'other',
                text: data.text,
                time: data.time || Date.now(),
                status: data.status || 'delivered'
            };
            msgs.push(newMsg);
            saveMessages(chatId, msgs);
            renderMessages(chatId);
            const chat = chats.find(c => c.id === chatId);
            if (chat) {
                chat.lastMsg = data.text;
                chat.time = Date.now();
                if (data.sender !== 'me') chat.unread = (chat.unread || 0) + 1;
                saveChats(chats);
                renderChatList();
            }
        }
        if (data.type === 'status_update' && data.chatId === chatId) {
            const chat = chats.find(c => c.id === chatId);
            if (chat) {
                chat.online = data.online || false;
                renderChatList();
                updateRoomStatus(chat.online);
            }
        }
    });
}

// ===== مدیریت داده‌ها =====
function getChats() {
    try {
        const c = localStorage.getItem('pulset_chats');
        if (c) return JSON.parse(c);
    } catch (e) { /* ignore */ }
    return SAMPLE_CHATS;
}

function getMessages(id) {
    try {
        const m = localStorage.getItem('pulset_msgs_' + id);
        if (m) return JSON.parse(m);
    } catch (e) { /* ignore */ }
    return SAMPLE_MSGS[id] || [];
}

function saveChats(c) {
    localStorage.setItem('pulset_chats', JSON.stringify(c));
}

function saveMessages(id, ms) {
    localStorage.setItem('pulset_msgs_' + id, JSON.stringify(ms));
}

function updateRoomStatus(online) {
    const statusEl = document.getElementById('roomStatus');
    if (statusEl) statusEl.textContent = online ? t('online') : t('offline');
    const dot = document.getElementById('roomOnlineDot');
    if (dot) dot.className = 'online-dot ' + (online ? 'on' : 'off');
}

// ===== رندر لیست چت‌ها =====
async function renderChatList() {
    const list = document.getElementById('chatList');
    const q = document.getElementById('searchChats').value.trim().toLowerCase();
    chats = await fetchChats();
    const filtered = chats.filter(c => c.name.includes(q) || (c.handle || '').includes(q));
    if (!filtered.length) {
        list.innerHTML = `
            <div class="empty-state">
                <span class="icon">💬</span>
                <div class="text">${t('empty')}<br><span style="font-size:12px;color:var(--text3);">${t('empty_desc')}</span></div>
            </div>
        `;
        return;
    }
    list.innerHTML = filtered.map(c => {
        const msgs = getMessages(c.id);
        const last = msgs.length ? msgs[msgs.length - 1] : null;
        const lastText = last ? ((last.sender === 'me' ? 'شما: ' : '') + last.text) : c.lastMsg || '';
        const time = last ? formatTime(last.time) : formatTime(c.time);
        const dot = `<div class="online-dot ${c.online ? 'on' : 'off'}"></div>`;
        const v = c.verified ? '<span class="verified">✓</span>' : '';
        const avatarContent = c.avatar && c.avatar.startsWith('data:image') ?
            `<img src="${c.avatar}" alt="${c.name}">` : (c.avatar || 'ع');
        const unread = c.unread > 0 ? `<span class="unread">${c.unread}</span>` : '';
        return `
            <div class="chat-item" onclick="openChat(${c.id})">
                <div class="avatar-wrap">
                    <div class="avatar">${avatarContent}</div>
                    ${dot}
                </div>
                <div class="info">
                    <div class="name">${c.name} ${v}</div>
                    <div class="last-msg">${lastText}</div>
                </div>
                <span class="time">${time}</span>
                ${unread}
            </div>
        `;
    }).join('');
}

function filterChats() {
    renderChatList();
}

// ===== صفحه چت =====
async function openChat(id) {
    currentChatId = id;
    const chat = chats.find(c => c.id === id);
    if (!chat) return;

    isBlocked = localStorage.getItem('pulset_blocked_' + id) === 'true';
    document.getElementById('chatListView').style.display = 'none';
    document.getElementById('chatRoom').classList.add('show');

    // آواتار
    const avatarEl = document.getElementById('roomAvatar');
    if (chat.avatar && chat.avatar.startsWith('data:image')) {
        avatarEl.innerHTML = `<img src="${chat.avatar}" alt="${chat.name}">`;
    } else {
        avatarEl.textContent = chat.avatar || 'ع';
    }

    // وضعیت آنلاین
    updateRoomStatus(chat.online || false);

    // نام
    document.getElementById('roomName').innerHTML = chat.name + (chat.verified ? ' <span class="verified">✓</span>' : '');

    updateInputState();

    // بارگذاری پیام‌ها
    const msgs = await fetchMessages(id);
    if (!messages[id]) messages[id] = msgs;
    renderMessages(id);

    // اتصال WebSocket
    connectWebSocket(id);

    // علامت‌گذاری خوانده‌شده
    const c = chats.find(ch => ch.id === id);
    if (c) {
        c.unread = 0;
        saveChats(chats);
        renderChatList();
    }

    setTimeout(() => {
        const container = document.getElementById('messagesContainer');
        container.scrollTop = container.scrollHeight;
    }, 100);
}

function closeChat() {
    document.getElementById('chatRoom').classList.remove('show');
    document.getElementById('chatListView').style.display = 'flex';
    if (wsUnsubscribe) {
        wsUnsubscribe();
        wsUnsubscribe = null;
    }
    renderChatList();
    document.getElementById('roomDropdown').classList.remove('show');
    dropOpen = false;
    document.getElementById('searchOverlay').classList.remove('show');
}

function updateInputState() {
    const input = document.getElementById('chatInput');
    const send = document.getElementById('sendBtn');
    const blocked = document.getElementById('blockedMsg');
    if (isBlocked) {
        input.style.display = 'none';
        send.style.display = 'none';
        blocked.style.display = 'block';
    } else {
        input.style.display = 'block';
        send.style.display = 'block';
        blocked.style.display = 'none';
    }
}

function renderMessages(id) {
    const container = document.getElementById('messagesContainer');
    const msgs = getMessages(id);
    if (!msgs.length) {
        container.innerHTML = '<div class="empty-state" style="padding:40px 20px;"><span class="icon">💬</span><div class="text">پیامی وجود ندارد</div></div>';
        return;
    }
    let lastDate = '',
        html = '';
    msgs.forEach(m => {
        const d = new Date(m.time).toDateString();
        if (d !== lastDate) {
            lastDate = d;
            const dateStr = new Date(m.time).toLocaleDateString(getCurrentLang() === 'fa' ? 'fa-IR' : 'en-US', {
                weekday: 'long',
                day: 'numeric',
                month: 'long'
            });
            html += `<div class="msg-date"><span>${dateStr}</span></div>`;
        }
        const isMe = m.sender === 'me';
        const stMap = { sent: '✓', delivered: '✓✓', read: '✓✓' };
        const stIcon = isMe ? stMap[m.status] || '✓' : '';
        html += `
            <div class="msg ${isMe ? 'sent' : 'received'}">
                <div class="bubble">${m.text}</div>
                <div class="time">${formatTime(m.time)} ${stIcon}</div>
            </div>
        `;
    });
    container.innerHTML = html;
    setTimeout(() => container.scrollTop = container.scrollHeight, 50);
}

// ===== ارسال پیام =====
async function sendMessage() {
    const input = document.getElementById('chatInput');
    const text = input.value.trim();
    if (!text || !currentChatId || isBlocked) return;
    input.value = '';
    autoResize();

    const msgs = getMessages(currentChatId);
    const newMsg = {
        id: Date.now(),
        sender: 'me',
        text: text,
        time: Date.now(),
        status: 'sent'
    };
    msgs.push(newMsg);
    saveMessages(currentChatId, msgs);

    const chat = chats.find(c => c.id === currentChatId);
    if (chat) {
        chat.lastMsg = text;
        chat.time = Date.now();
        chat.unread = 0;
        saveChats(chats);
    }

    renderMessages(currentChatId);
    renderChatList();

    // ارسال به API
    const result = await sendMessageToAPI(currentChatId, text);
    if (result && result.id) {
        const idx = msgs.findIndex(m => m.id === newMsg.id);
        if (idx !== -1) {
            msgs[idx].id = result.id;
            msgs[idx].status = result.status || 'delivered';
            saveMessages(currentChatId, msgs);
            renderMessages(currentChatId);
        }
    }

    // ارسال از طریق WebSocket
    if (wsUnsubscribe) {
        API.WS.send('chat', { type: 'message', chatId: currentChatId, text: text });
    }

    setTimeout(() => {
        const container = document.getElementById('messagesContainer');
        container.scrollTop = container.scrollHeight;
    }, 100);
}

function handleKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
    }
}

function autoResize() {
    const el = document.getElementById('chatInput');
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 100) + 'px';
}
document.getElementById('chatInput').addEventListener('input', autoResize);

// ===== منوی سه‌نقطه =====
function toggleDropdown() {
    dropOpen = !dropOpen;
    document.getElementById('roomDropdown').classList.toggle('show', dropOpen);
}
document.addEventListener('click', function(e) {
    if (!e.target.closest('.more-btn') && !e.target.closest('.dropdown')) {
        document.getElementById('roomDropdown').classList.remove('show');
        dropOpen = false;
    }
});

// ===== جستجو در پیام‌ها =====
function openSearchInChat() {
    document.getElementById('searchOverlay').classList.add('show');
    document.getElementById('searchMessagesInput').value = '';
    document.getElementById('searchMessagesResults').innerHTML = '';
    document.getElementById('searchMessagesInput').focus();
    document.getElementById('roomDropdown').classList.remove('show');
    dropOpen = false;
}

function closeSearchInChat() {
    document.getElementById('searchOverlay').classList.remove('show');
}

function searchInMessages() {
    const q = document.getElementById('searchMessagesInput').value.trim().toLowerCase();
    const res = document.getElementById('searchMessagesResults');
    if (!q) {
        res.innerHTML = '';
        return;
    }
    const msgs = getMessages(currentChatId);
    const found = msgs.filter(m => m.text.toLowerCase().includes(q));
    if (!found.length) {
        res.innerHTML = '<div style="padding:20px;text-align:center;color:var(--text3);font-size:13px;">' + t('no_results') + '</div>';
        return;
    }
    res.innerHTML = found.map(m => {
        const isMe = m.sender === 'me';
        const sender = isMe ? t('you') : '';
        return `
            <div class="search-result-item" onclick="scrollToMessage(${m.id})">
                <div class="text">${m.text}</div>
                <div class="meta"><span class="sender">${sender}</span><span>${formatTime(m.time)}</span></div>
            </div>
        `;
    }).join('');
}

function scrollToMessage(id) {
    closeSearchInChat();
    const msgs = getMessages(currentChatId);
    const idx = msgs.findIndex(m => m.id === id);
    if (idx === -1) return;
    const container = document.getElementById('messagesContainer');
    const items = container.querySelectorAll('.msg');
    if (items[idx]) {
        items[idx].scrollIntoView({ behavior: 'smooth', block: 'center' });
        items[idx].style.transition = 'background 0.3s';
        items[idx].style.background = 'var(--gold-bg)';
        setTimeout(() => { items[idx].style.background = ''; }, 1500);
    }
}

// ===== بلاک / آنبلاک =====
function blockUser() {
    if (confirm('آیا از بلاک کردن این کاربر مطمئنید؟')) {
        isBlocked = true;
        localStorage.setItem('pulset_blocked_' + currentChatId, 'true');
        updateInputState();
        showToast(t('blocked'));
        document.getElementById('roomDropdown').classList.remove('show');
        dropOpen = false;
    }
}

function unblockUser() {
    if (confirm('آیا می‌خواهید بلاک این کاربر را بردارید؟')) {
        isBlocked = false;
        localStorage.removeItem('pulset_blocked_' + currentChatId);
        updateInputState();
        showToast(t('unblocked'));
    }
}

function clearChatHistory() {
    if (confirm('آیا از پاک کردن تاریخچه این چت مطمئنید؟')) {
        saveMessages(currentChatId, []);
        renderMessages(currentChatId);
        showToast(t('history_cleared'));
    }
    document.getElementById('roomDropdown').classList.remove('show');
    dropOpen = false;
}

function reportUser() {
    if (confirm('آیا از گزارش این کاربر مطمئنید؟')) {
        showToast(t('reported'));
    }
    document.getElementById('roomDropdown').classList.remove('show');
    dropOpen = false;
}

// ===== مقداردهی اولیه =====
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    const lang = getCurrentLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    applyPageTranslations();
    renderChatList();
    console.log('✅ chat.js loaded');
});

// ===== خروجی توابع =====
window.openChat = openChat;
window.closeChat = closeChat;
window.sendMessage = sendMessage;
window.filterChats = filterChats;
window.handleKey = handleKey;
window.toggleDropdown = toggleDropdown;
window.openSearchInChat = openSearchInChat;
window.closeSearchInChat = closeSearchInChat;
window.searchInMessages = searchInMessages;
window.scrollToMessage = scrollToMessage;
window.blockUser = blockUser;
window.unblockUser = unblockUser;
window.clearChatHistory = clearChatHistory;
window.reportUser = reportUser;
window.showToast = showToast;
window.toggleDark = toggleDark;
window.toggleLang = toggleLang;
