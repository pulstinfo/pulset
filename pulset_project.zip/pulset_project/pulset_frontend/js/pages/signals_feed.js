// ================================================================
// signals_feed.js - اسکریپت صفحه سیگنال‌ها
// ================================================================

const PAGE_TR = {
    fa: {
        home: 'خانه', exp: 'اکسپلور', mkt: 'بازارها', sig: 'سیگنال‌ها',
        vi: 'بازدید', sh: 'اشتراک‌گذاری', rp: 'بازنشر', cm: 'کامنت', lk: 'لایک', sv: 'ذخیره',
        emp: 'هیچ سیگنالی یافت نشد', end: 'همه سیگنال‌ها را دیدید', ld: 'در حال بارگذاری...',
        fol: 'دنبال‌کننده', folc: 'دنبال‌شونده', msg: 'پیام‌ها', not: 'اعلان‌ها',
        ai: 'چت با هوش مصنوعی', news: 'اخبار', bm: 'ذخیره‌ها', wal: 'کیف پول',
        set: 'تنظیمات', lo: 'خروج از حساب', prof: 'پروفایل',
        wcm: 'کامنت خود را بنویسید...', snd: 'ارسال',
        ri: 'بازنشر فوری', rq: 'نقل‌قول',
        report: 'گزارش', edit: 'ویرایش',
        public: 'عمومی', market: 'بازار',
        buy: 'خرید', sell: 'فروش',
        entry: 'ورود', tp: 'حد سود', sl: 'حد ضرر', confidence: 'اطمینان',
        no_history: 'هنوز سیگنالی دریافت نکرده‌اید.'
    },
    en: {
        home: 'Home', exp: 'Explore', mkt: 'Markets', sig: 'Signals',
        vi: 'Views', sh: 'Share', rp: 'Repost', cm: 'Comment', lk: 'Like', sv: 'Save',
        emp: 'No signals found', end: 'You\'ve seen all', ld: 'Loading...',
        fol: 'Followers', folc: 'Following', msg: 'Messages', not: 'Notifications',
        ai: 'AI Chat', news: 'News', bm: 'Bookmarks', wal: 'Wallet',
        set: 'Settings', lo: 'Logout', prof: 'Profile',
        wcm: 'Write your comment...', snd: 'Send',
        ri: 'Repost now', rq: 'Quote',
        report: 'Report', edit: 'Edit',
        public: 'Public', market: 'Market',
        buy: 'Buy', sell: 'Sell',
        entry: 'Entry', tp: 'Take Profit', sl: 'Stop Loss', confidence: 'Confidence',
        no_history: 'No signals yet.'
    }
};

let currentTab = 'public';
let signals = [];
let page = 0, loading = false, hasMore = true, observer = null, adCounter = 0, fabMenuOpen = false;
let openDropdownId = null, currentCommentId = null, currentRepostId = null, quoteParentId = null, reportPostId = null, sharePostId = null, shareText = '';
let sendSelectedType = '', sellSelectedType = '', editSelectedType = '', editSignalId = null;
let signalHistory = JSON.parse(localStorage.getItem('pulset_signal_history') || '[]');
let selectedPayMethod = null, currentPurchaseSignalId = null, currentPurchasePrice = 0;

function applyPageTranslations() {
    const lang = getCurrentLang();
    const t = PAGE_TR[lang];
    if (!t) return;
    document.querySelectorAll('.tab').forEach(e => { e.textContent = t[e.dataset.tab] || e.dataset.tab; });
    document.querySelectorAll('.nav .l').forEach(e => { const k = e.dataset.key; if (k && t[k]) e.textContent = t[k]; });
    document.querySelectorAll('.drawer-mi').forEach(e => { const k = e.dataset.key; if (k && t[k]) e.textContent = t[k]; });
    const un = document.querySelector('.drawer-un');
    if (un) un.textContent = lang === 'fa' ? 'علی معامله‌گر' : 'Ali Trader';
    const inp = document.getElementById('commentInput');
    if (inp) inp.placeholder = t.wcm;
    const btn = document.querySelector('.comment-in button');
    if (btn) btn.textContent = t.snd;
    document.querySelectorAll('.repost-o .opt').forEach(e => {
        const txt = e.textContent.trim();
        e.textContent = txt.includes('فوری') || txt.includes('now') ? t.ri : t.rq;
    });
    document.querySelectorAll('.sheet-title').forEach((el, i) => {
        const titles = ['کامنت‌ها', 'بازنشر', 'نقل‌قول', 'گزارش سیگنال', 'ارسال سیگنال عمومی', 'فروش سیگنال', 'ویرایش سیگنال', 'پرداخت سیگنال'];
        const enTitles = ['Comments', 'Repost', 'Quote', 'Report Signal', 'Send Public Signal', 'Sell Signal', 'Edit Signal', 'Pay Signal'];
        el.textContent = lang === 'fa' ? titles[i] : (enTitles[i] || '');
    });
}
window.applyPageTranslations = applyPageTranslations;

function getSampleSignals(tab) {
    const n = Date.now();
    if (tab === 'public') {
        return [
            { id: 101, user: 'نیما تحلیل‌گر', username: '@nima_charts', avatar: 'ن', verified: true, time: n - 120000, type: 'buy', coin: 'بیت‌کوین / USDT', entry: '$67,850', tp: '$69,200', sl: '$67,100', confidence: 85, views: 512, likes: 34, comments: 8, reposts: 5, liked: false, saved: false, reposted: false, owner: false, isMarket: false, isAI: false }
        ];
    } else {
        return [
            { id: 201, user: 'علی معامله‌گر', username: '@ali_trades', avatar: 'ع', verified: true, time: n - 180000, type: 'buy', coin: 'طلا / دلار', entry: '$2,340', tp: '$2,380', sl: '$2,320', confidence: 92, views: 890, likes: 67, comments: 23, reposts: 14, liked: false, saved: false, reposted: false, owner: false, isMarket: true, isPurchased: false, price: 75000, isAI: false }
        ];
    }
}

async function fetchSignals(tab, pageNum) {
    try { const data = await API.Signals.get(tab, pageNum, 5); return data.signals || data || []; } catch (e) { return getSampleSignals(tab); }
}

function createAd() { const posId = (adCounter % 2 === 0) ? 'pos-article-display-card-120295' : 'pos-article-display-card-120298'; adCounter++; return '<div class="sponsor-block"><div class="sponsor-label">تبلیغات</div><div class="sponsor-container"><div id="' + posId + '"></div></div></div>'; }

function createSignalCardHTML(s) {
    const m = s.isMarket === true, p = s.isPurchased === true, o = s.owner === true;
    const time = fmtTime(s.time);
    const tc = s.type === 'buy' ? 'buy' : 'sell';
    const tl = s.type === 'buy' ? 'خرید' : 'فروش';
    const lc = s.liked ? 'liked' : '';
    const sc = s.saved ? 'saved' : '';
    const rc = s.reposted ? 'reposted' : '';
    const vb = s.verified ? '<span class="v">✓</span>' : '';
    const ai = s.isAI ? '<span class="signal-badge ai">AI</span>' : '';
    const bh = m ? '' : `<span class="signal-badge ${tc}">${tl}</span>`;
    const ph = m && s.price ? `<div class="price-tag">${s.price.toLocaleString()} تومان</div>` : '';
    let dh = '', bh2 = '';
    if (m && !p && !o) {
        dh = '<div class="locked-info">🔒 اطلاعات سیگنال پس از خرید نمایش داده می‌شود.</div>';
        bh2 = `<button class="buy-signal-btn" onclick="purchaseSignal(${s.id})">🛒 خرید سیگنال (${s.price.toLocaleString()} تومان)</button>`;
    } else {
        dh = `<div class="signal-details"><div class="signal-detail-item"><div class="signal-detail-label">${t('entry')}</div><div class="signal-detail-value">${s.entry}</div></div><div class="signal-detail-item"><div class="signal-detail-label">${t('tp')}</div><div class="signal-detail-value" style="color:#2e7d32;">${s.tp}</div></div><div class="signal-detail-item"><div class="signal-detail-label">${t('sl')}</div><div class="signal-detail-value" style="color:#c62828;">${s.sl}</div></div></div><div class="signal-confidence"><span>${t('confidence')}</span><div class="bar"><div class="fill" style="width:${s.confidence}%;"></div></div><span class="percent">${s.confidence}%</span></div><svg class="signal-chart" viewBox="0 0 400 120"><rect width="400" height="120" fill="transparent"/><polyline points="10,${Math.random()*60+30} 80,${Math.random()*60+30} 150,${Math.random()*60+30} 220,${Math.random()*60+30} 290,${Math.random()*60+30} 360,${Math.random()*60+30} 390,${Math.random()*60+30}" stroke="var(--gold)" stroke-width="3" fill="none" stroke-linecap="round"/></svg>`;
    }
    const did = 'dropdown-' + s.id;
    const mm = `<div class="signal-right"><span class="signal-t">${time}</span><button class="post-more-btn" onclick="event.stopPropagation();toggleDropdown(${s.id})" aria-label="بیشتر"><svg viewBox="0 0 24 24"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg></button><div class="dropdown-menu" id="${did}">${o?`<button class="dropdown-item" onclick="event.stopPropagation();openEditSignal(${s.id});closeDropdown(${s.id})"><svg viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>${t('edit')}</button>`:''}<button class="dropdown-item" onclick="event.stopPropagation();openReportSheet(${s.id});closeDropdown(${s.id})"><svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M12 8v4"/><path d="M12 16h.01"/></svg>${t('report')}</button></div></div>`;
    const ah = `<div class="signal-a2"><button class="btn like ${lc}" onclick="toggleLike(${s.id})"><svg class="i" viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg><span>${s.likes||0}</span></button><button class="btn" onclick="openComments(${s.id})"><svg class="i" viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg><span>${s.comments||0}</span></button><button class="btn repost-btn ${rc}" onclick="openRepost(${s.id})"><svg class="i" viewBox="0 0 24 24"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg><span>${s.reposts||0}</span></button><button class="btn bookmark ${sc}" onclick="toggleBookmark(${s.id})"><svg class="i" viewBox="0 0 24 24"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg></button><button class="btn share-btn" onclick="openShareModal(${s.id})"><svg class="i" viewBox="0 0 24 24"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg></button><span class="views">${t('vi')} ${s.views||0}</span></div>`;
    return `<div class="signal-card${m?' market':''}" data-id="${s.id}"><div class="signal-h"><a class="signal-a" href="profile.html">${s.avatar}</a><div class="signal-ui" onclick="window.location.href='profile.html'"><div class="signal-un">${s.user} ${vb}</div><div class="signal-usr">${s.username}</div></div>${mm}</div>${bh}${ai}<div class="signal-coin">${s.coin}</div>${ph}${dh}${bh2}${ah}</div>`;
}

function renderSignals() {
    const container = document.getElementById('feedSignals');
    if (!container) return;
    container.innerHTML = '';
    const items = signals.slice(0, page * 5 + 5);
    if (!items.length) { container.innerHTML = '<div style="text-align:center;padding:60px 20px;color:var(--text3);">' + t('emp') + '</div>'; return; }
    items.forEach((s, i) => {
        container.insertAdjacentHTML('beforeend', createSignalCardHTML(s));
        if ((i + 1) % 4 === 0 && (i + 1) < items.length) container.insertAdjacentHTML('beforeend', createAd());
    });
    hasMore = items.length < signals.length;
    const endMsg = document.getElementById('endMessage');
    if (endMsg) { if (!hasMore) endMsg.classList.add('show'); else endMsg.classList.remove('show'); }
    setupObserver();
}

async function initFeed() { page = 0; const data = await fetchSignals(currentTab, 0); signals = data.map(s => ({ ...s, liked: false, saved: false, reposted: false })); renderSignals(); updateFabMenu(); }

async function loadMore() {
    if (loading || !hasMore) return;
    loading = true;
    const l = document.getElementById('loaderContainer');
    if (l) l.classList.add('show');
    try {
        const d = await fetchSignals(currentTab, page + 1);
        let n = [];
        if (d && d.length) n = d.map(s => ({ ...s, liked: false, saved: false, reposted: false }));
        if (!n.length) {
            hasMore = false;
            if (l) l.classList.remove('show');
            const e = document.getElementById('endMessage');
            if (e) e.classList.add('show');
            loading = false;
            return;
        }
        const start = signals.length;
        signals = [...signals, ...n];
        page++;
        const c = document.getElementById('feedSignals');
        n.forEach((s, i) => {
            c.insertAdjacentHTML('beforeend', createSignalCardHTML(s));
            if ((start + i + 1) % 4 === 0 && (start + i + 1) < signals.length) c.insertAdjacentHTML('beforeend', createAd());
        });
        if (l) l.classList.remove('show');
        loading = false;
        hasMore = signals.length < page * 5 + 5;
        if (!hasMore) { const e = document.getElementById('endMessage'); if (e) e.classList.add('show'); }
    } catch (e) { console.error('loadMore error:', e); loading = false; if (l) l.classList.remove('show'); }
}

function setupObserver() {
    if (observer) observer.disconnect();
    const l = document.getElementById('loaderContainer');
    observer = new IntersectionObserver(e => {
        if (e[0].isIntersecting && !loading && hasMore) loadMore();
    }, { threshold: .1 });
    if (l) observer.observe(l);
}

async function toggleLike(id) { const s = signals.find(x => x.id === id); if (!s) return; try { const data = await API.Signals.like(id); s.liked = data.liked; s.likes = data.likes; } catch (e) { s.liked = !s.liked; s.likes += s.liked ? 1 : -1; } renderSignals(); }
async function toggleBookmark(id) { const s = signals.find(x => x.id === id); if (!s) return; try { const data = await API.Signals.bookmark(id); s.saved = data.saved; } catch (e) { s.saved = !s.saved; } renderSignals(); }

async function purchaseSignal(id) {
    const s = signals.find(x => x.id === id);
    if (!s || !s.isMarket) return;
    currentPurchaseSignalId = id;
    currentPurchasePrice = s.price || 0;
    document.getElementById('paySignalCoin').textContent = s.coin || 'دارایی';
    document.getElementById('paySignalPrice').textContent = 'قیمت: ' + (s.price ? s.price.toLocaleString() : '۰') + ' تومان';
    await fetchBalances();
    selectedPayMethod = null;
    document.querySelectorAll('.pay-option').forEach(el => el.classList.remove('selected'));
    document.querySelectorAll('.pay-check').forEach(el => el.style.display = 'none');
    document.getElementById('confirmPayBtn').disabled = true;
    document.getElementById('payError').style.display = 'none';
    document.getElementById('paySignalSheet').classList.add('open');
    document.body.style.overflow = 'hidden';
}

function closePaySheet() {
    document.getElementById('paySignalSheet').classList.remove('open');
    document.body.style.overflow = '';
    selectedPayMethod = null;
    currentPurchaseSignalId = null;
}

async function fetchBalances() {
    try {
        const data = await API.Wallet.get();
        if (data) {
            document.getElementById('walletBalanceDisplay').textContent = data.rial ? data.rial.toLocaleString() : '۰';
            document.getElementById('starsBalanceDisplay').textContent = data.stars ? data.stars.toLocaleString() : '۰';
            return;
        }
    } catch (e) { console.warn('Fetch balances error, using localStorage:', e); }
    const rial = parseInt(localStorage.getItem('pulset_rial_balance')) || 0;
    const stars = parseInt(localStorage.getItem('pulset_star_balance')) || 0;
    document.getElementById('walletBalanceDisplay').textContent = rial.toLocaleString();
    document.getElementById('starsBalanceDisplay').textContent = stars.toLocaleString();
}

function selectPayMethod(method) {
    selectedPayMethod = method;
    document.querySelectorAll('.pay-option').forEach(el => el.classList.remove('selected'));
    document.querySelectorAll('.pay-check').forEach(el => el.style.display = 'none');
    const option = document.querySelector(`.pay-option:has(.pay-check#${method}Check)`);
    if (option) { option.classList.add('selected'); }
    document.getElementById(method + 'Check').style.display = 'block';
    document.getElementById('confirmPayBtn').disabled = false;
    document.getElementById('payError').style.display = 'none';
}

function goToAddFunds(type) {
    closePaySheet();
    setTimeout(() => { window.location.href = 'wallet.html?action=' + type; }, 300);
}

async function confirmPayment() {
    if (!selectedPayMethod || !currentPurchaseSignalId) return;
    const btn = document.getElementById('confirmPayBtn');
    btn.disabled = true;
    btn.textContent = '⏳ در حال پردازش...';
    document.getElementById('payError').style.display = 'none';
    const s = signals.find(x => x.id === currentPurchaseSignalId);
    if (!s) { showToast('❌ سیگنال یافت نشد'); btn.disabled = false; btn.textContent = 'تایید پرداخت'; return; }
    try {
        let success = false;
        if (selectedPayMethod === 'wallet') {
            const rial = parseInt(localStorage.getItem('pulset_rial_balance')) || 0;
            if (rial < currentPurchasePrice) { document.getElementById('payError').textContent = '⚠️ موجودی کیف پول کافی نیست.'; document.getElementById('payError').style.display = 'block'; btn.disabled = false; btn.textContent = 'تایید پرداخت'; return; }
            const newRial = rial - currentPurchasePrice;
            localStorage.setItem('pulset_rial_balance', String(newRial));
            document.getElementById('walletBalanceDisplay').textContent = newRial.toLocaleString();
            const data = await API.Signals.purchase(currentPurchaseSignalId);
            success = data && data.success;
        } else if (selectedPayMethod === 'stars') {
            const starsNeeded = Math.ceil(currentPurchasePrice / 70);
            const stars = parseInt(localStorage.getItem('pulset_star_balance')) || 0;
            if (stars < starsNeeded) { document.getElementById('payError').textContent = '⚠️ موجودی ستاره کافی نیست.'; document.getElementById('payError').style.display = 'block'; btn.disabled = false; btn.textContent = 'تایید پرداخت'; return; }
            const newStars = stars - starsNeeded;
            localStorage.setItem('pulset_star_balance', String(newStars));
            document.getElementById('starsBalanceDisplay').textContent = newStars.toLocaleString();
            const data = await API.Signals.purchase(currentPurchaseSignalId);
            success = data && data.success;
        } else if (selectedPayMethod === 'gateway') {
            showToast('💳 در حال اتصال به درگاه پرداخت...');
            const data = await API.Signals.purchase(currentPurchaseSignalId);
            success = data && data.success;
        }
        if (success) { s.isPurchased = true; renderSignals(); closePaySheet(); showToast('✅ سیگنال با موفقیت خریداری شد!'); } else { throw new Error('پرداخت ناموفق'); }
    } catch (e) { console.error('Payment error:', e); document.getElementById('payError').textContent = '❌ خطا در پرداخت. لطفاً مجدداً تلاش کنید.'; document.getElementById('payError').style.display = 'block'; btn.disabled = false; btn.textContent = 'تایید پرداخت'; }
}

function openEditSignal(id) {
    const s = signals.find(x => x.id === id);
    if (!s || !s.owner) return;
    editSignalId = id;
    editSelectedType = s.type;
    document.getElementById('editCoinSelected').textContent = s.coin;
    const options = document.querySelectorAll('#editCoinOptions .opt');
    let found = false;
    options.forEach(opt => {
        const label = opt.textContent.trim();
        if (label.includes(s.coin) || s.coin.includes(label.replace(/\(.*\)/, '').trim())) { opt.classList.add('selected');
            found = true; } else { opt.classList.remove('selected'); }
    });
    if (!found && options.length > 0) { options[0].classList.add('selected');
        document.getElementById('editCoinSelected').textContent = options[0].textContent.trim(); }
    document.querySelectorAll('#editSignalBody .btn-type').forEach(b => { b.classList.toggle('selected', b.dataset.type === s.type); });
    document.getElementById('editEntry').value = s.entry ? s.entry.replace('$', '').trim() : '';
    document.getElementById('editTP').value = s.tp ? s.tp.replace('$', '').trim() : '';
    document.getElementById('editSL').value = s.sl ? s.sl.replace('$', '').trim() : '';
    document.getElementById('editConfidence').value = s.confidence || '';
    document.getElementById('editDesc').value = s.desc || '';
    const priceField = document.querySelector('#editSignalBody .price-field');
    if (s.isMarket) { if (priceField) { priceField.style.display = 'block';
            document.getElementById('editPrice').value = s.price || '';
            document.getElementById('editPriceError').style.display = 'none'; } } else { if (priceField) priceField.style.display = 'none'; }
    document.getElementById('editSignalSheet').classList.add('open');
    document.querySelectorAll('#editSignalBody .error-msg').forEach(e => e.classList.remove('show'));
    document.getElementById('editSignalBtn').disabled = false;
    document.getElementById('editSignalBtn').textContent = 'ذخیره تغییرات';
}

function closeEditSignalSheet() { document.getElementById('editSignalSheet').classList.remove('open');
    editSignalId = null; }

function validateEditSignal() {
    let valid = true;
    const coin = document.getElementById('editCoinSelected').textContent;
    if (!coin || coin === 'انتخاب کنید') { document.getElementById('editCoinError').classList.add('show');
        valid = false; } else { document.getElementById('editCoinError').classList.remove('show'); }
    if (!editSelectedType) { document.getElementById('editTypeError').classList.add('show');
        valid = false; } else { document.getElementById('editTypeError').classList.remove('show'); }
    const entry = parseFloat(document.getElementById('editEntry').value.trim());
    if (isNaN(entry) || entry <= 0) { document.getElementById('editEntryError').classList.add('show');
        valid = false; } else { document.getElementById('editEntryError').classList.remove('show'); }
    const tp = parseFloat(document.getElementById('editTP').value.trim());
    if (isNaN(tp) || tp <= 0) { document.getElementById('editTPError').classList.add('show');
        valid = false; } else { document.getElementById('editTPError').classList.remove('show'); }
    const sl = parseFloat(document.getElementById('editSL').value.trim());
    if (isNaN(sl) || sl <= 0) { document.getElementById('editSLError').classList.add('show');
        valid = false; } else { document.getElementById('editSLError').classList.remove('show'); }
    const conf = document.getElementById('editConfidence').value.trim();
    if (conf !== '') { const c = parseFloat(conf); if (isNaN(c) || c < 0 || c > 100) { document.getElementById('editConfidenceError').classList.add('show');
            valid = false; } else { document.getElementById('editConfidenceError').classList.remove('show'); } }
    const priceField = document.querySelector('#editSignalBody .price-field');
    if (priceField && priceField.style.display !== 'none') { const price = parseFloat(document.getElementById('editPrice').value.trim().replace(/,/g, '')); if (isNaN(price) || price <= 0) { document.getElementById('editPriceError').classList.add('show');
            valid = false; } else { document.getElementById('editPriceError').classList.remove('show'); } }
    return valid;
}

async function updateSignal() {
    if (!validateEditSignal() || !editSignalId) return;
    const btn = document.getElementById('editSignalBtn');
    btn.disabled = true;
    btn.textContent = '⏳ در حال ذخیره...';
    const coin = document.getElementById('editCoinSelected').textContent;
    const entry = document.getElementById('editEntry').value.trim();
    const tp = document.getElementById('editTP').value.trim();
    const sl = document.getElementById('editSL').value.trim();
    const confidence = document.getElementById('editConfidence').value.trim() || '۸۰';
    const desc = document.getElementById('editDesc').value.trim();
    const data = { coin: coin, type: editSelectedType, entry: entry, tp: tp, sl: sl, confidence: parseInt(confidence),
        desc: desc };
    const s = signals.find(x => x.id === editSignalId);
    if (s && s.isMarket) { const priceField = document.querySelector('#editSignalBody .price-field'); if (priceField && priceField.style.display !== 'none') { const price = parseInt(document.getElementById('editPrice').value.trim().replace(/,/g, '')); if (!isNaN(price) && price > 0) { data.price = price; } } }
    try {
        await API.Signals.update(editSignalId, data);
        if (s) { s.coin = data.coin;
            s.type = data.type;
            s.entry = '$' + data.entry;
            s.tp = '$' + data.tp;
            s.sl = '$' + data.sl;
            s.confidence = data.confidence;
            s.desc = data.desc; if (data.price) s.price = data.price; }
        renderSignals();
        closeEditSignalSheet();
        showToast('✅ سیگنال با موفقیت ویرایش شد');
    } catch (e) { console.error('Update error:', e); if (s) { s.coin = data.coin;
            s.type = data.type;
            s.entry = '$' + data.entry;
            s.tp = '$' + data.tp;
            s.sl = '$' + data.sl;
            s.confidence = data.confidence;
            s.desc = data.desc; if (data.price) s.price = data.price; } renderSignals();
        closeEditSignalSheet();
        showToast('✅ سیگنال با موفقیت ویرایش شد'); }
    btn.disabled = false;
    btn.textContent = 'ذخیره تغییرات';
}

function openComments(id) { currentCommentId = id;
    document.getElementById('commentOverlay').classList.add('open');
    loadComments(id); }
function closeCommentSheet() { document.getElementById('commentOverlay').classList.remove('open');
    currentCommentId = null; }
async function loadComments(id) {
    const list = document.getElementById('commentsList');
    list.innerHTML = '<div style="text-align:center;padding:20px;color:var(--text3);">در حال بارگذاری...</div>';
    try { const data = await API.Signals.getComments(id); if (data && data.length) { list.innerHTML = data.map(c => `<div class="comment"><div class="comment-a">${c.avatar||'ع'}</div><div class="comment-c"><div class="comment-n">${c.user||'کاربر'}</div><div class="comment-t">${c.text}</div></div></div>`).join(''); } else { list.innerHTML = '<div style="text-align:center;padding:20px;color:var(--text3);">هیچ کامنتی وجود ندارد.</div>'; } } catch (e) { list.innerHTML = '<div style="text-align:center;padding:20px;color:var(--text3);">هیچ کامنتی وجود ندارد.</div>'; } }
async function addComment() {
    const inp = document.getElementById('commentInput');
    const txt = inp.value.trim();
    if (!txt) { showToast('لطفاً متن کامنت را وارد کنید.'); return; }
    if (!currentCommentId) { showToast('خطا: شناسه کامنت معتبر نیست.'); return; }
    try { await API.Signals.addComment(currentCommentId, txt);
        inp.value = '';
        loadComments(currentCommentId);
        const s = signals.find(x => x.id === currentCommentId); if (s) { s.comments = (s.comments || 0) + 1;
            renderSignals(); } } catch (e) { inp.value = '';
        loadComments(currentCommentId);
        const s = signals.find(x => x.id === currentCommentId); if (s) { s.comments = (s.comments || 0) + 1;
            renderSignals(); }
        showToast('✅ کامنت ارسال شد'); }
}

function openRepost(id) { currentRepostId = id;
    document.getElementById('repostOverlay').classList.add('open'); }
function closeRepostSheet() { document.getElementById('repostOverlay').classList.remove('open');
    currentRepostId = null; }
function doRepost(type) {
    if (!currentRepostId) return;
    if (type === 'quote') { openQuoteSheet(currentRepostId);
        closeRepostSheet(); return; }
    const s = signals.find(x => x.id === currentRepostId);
    if (s) { s.reposts = (s.reposts || 0) + 1;
        s.reposted = true;
        renderSignals();
        API.Signals.repost(currentRepostId, 'instant').catch(() => {}); }
    closeRepostSheet();
    showToast('🔄 بازنشر شد');
}

function openQuoteSheet(id) {
    quoteParentId = id;
    const p = signals.find(x => x.id === id);
    if (!p) { showToast('سیگنال اصلی یافت نشد.'); return; }
    document.getElementById('quoteOverlay').classList.add('open');
    document.getElementById('quoteContent').value = '';
    const display = document.getElementById('quoteOriginalDisplay');
    display.innerHTML = `<div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;"><div style="width:28px;height:28px;border-radius:50%;background:var(--avatar);color:var(--avatar-text);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;flex-shrink:0;">${p.avatar}</div><div style="font-size:14px;font-weight:600;color:var(--text);">${p.user} ${p.verified ? '✓' : ''}</div></div><div style="font-size:14px;color:var(--text2);line-height:1.8;white-space:pre-wrap;">${p.text || 'سیگنال: ' + p.coin + ' - ' + p.entry}</div>`;
    document.getElementById('quoteContent').focus();
}

function closeQuoteSheet() { document.getElementById('quoteOverlay').classList.remove('open');
    quoteParentId = null; }

function publishQuote() {
    const text = document.getElementById('quoteContent').value.trim();
    if (!text) { showToast('متن نقل‌قول را بنویسید.'); return; }
    const original = signals.find(x => x.id === quoteParentId);
    if (!original) { showToast('سیگنال اصلی یافت نشد.'); return; }
    const user = getUser();
    const newPost = {
        id: Date.now(),
        user: user.name || 'شما',
        username: '@' + (user.name || 'user').replace(/\s/g, ''),
        avatar: user.avatar || 'ش',
        verified: true,
        time: Date.now(),
        text: text,
        media: [],
        likes: 0,
        comments: 0,
        reposts: 0,
        views: 0,
        liked: false,
        saved: false,
        reposted: false,
        owner: true,
        type: 'quote',
        quoted_parent_id: original.id,
        quoted_parent_user: original.user,
        quoted_parent_text: original.text || 'سیگنال: ' + original.coin,
        quoted_parent_avatar: original.avatar,
        quoted_parent_image: null,
        quoted_parent_verified: original.verified,
        quoted_parent_username: original.username
    };
    signals.unshift(newPost);
    renderSignals();
    closeQuoteSheet();
    showToast('📝 نقل‌قول منتشر شد');
    API.Signals.quote(original.id, text).catch(() => {});
}

function openReportSheet(id) { reportPostId = id;
    document.getElementById('reportOverlay').classList.add('open', 'show-report'); }
function closeReportSheet() { document.getElementById('reportOverlay').classList.remove('open', 'show-report');
    reportPostId = null; }
async function submitReport(reason) { if (!reportPostId) return; try { await API.Signals.report(reportPostId, reason);
        showToast('✅ گزارش شما ثبت شد.'); } catch (e) { showToast('✅ گزارش شما ثبت شد.'); }
    closeReportSheet(); }

function openShareModal(id) { const s = signals.find(x => x.id === id); if (!s) return;
    sharePostId = id;
    shareText = s.coin + ' - ' + s.type + ' ' + t('entry') + ': ' + s.entry;
    document.getElementById('shareModal').classList.add('show'); }
function closeShareModal() { document.getElementById('shareModal').classList.remove('show');
    sharePostId = null; }
function copyLink() { const url = window.location.href + '?signal=' + sharePostId;
    navigator.clipboard.writeText(url).then(() => { showToast('✅ لینک کپی شد!');
        closeShareModal(); }).catch(() => { const ta = document.createElement('textarea');
        ta.value = url;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        showToast('✅ لینک کپی شد!');
        closeShareModal(); }); }
function shareNative() { if (navigator.share) { navigator.share({ title: 'Pulset Signal', text: shareText, url: window.location.href + '?signal=' + sharePostId }).catch(() => {}).finally(closeShareModal); } else { copyLink(); } }

function toggleDropdown(id) {
    const el = document.getElementById('dropdown-' + id);
    if (!el) return;
    if (openDropdownId === id) { el.classList.remove('show');
        openDropdownId = null; } else { if (openDropdownId) { const p = document.getElementById('dropdown-' + openDropdownId); if (p) p.classList.remove('show'); }
        el.classList.add('show');
        openDropdownId = id; }
}
document.addEventListener('click', function(e) { if (!e.target.closest('.signal-right') && openDropdownId) { const el = document.getElementById('dropdown-' + openDropdownId); if (el) el.classList.remove('show');
        openDropdownId = null; } });

function updateFabMenu() {
    const divPublic = document.getElementById('fabDividerPublic');
    const btnPublic = document.getElementById('fabSendPublic');
    const divMarket = document.getElementById('fabDividerMarket');
    const btnSell = document.getElementById('fabSellSignal');
    if (currentTab === 'public') { divPublic.style.display = 'block';
        btnPublic.style.display = 'flex';
        divMarket.style.display = 'none';
        btnSell.style.display = 'none'; } else { divPublic.style.display = 'none';
        btnPublic.style.display = 'none';
        divMarket.style.display = 'block';
        btnSell.style.display = 'flex'; }
}

function toggleFabMenu() {
    fabMenuOpen = !fabMenuOpen;
    document.getElementById('fabPlus').classList.toggle('open', fabMenuOpen);
    document.getElementById('fabMenu').classList.toggle('open', fabMenuOpen);
}
document.addEventListener('click', function(e) { const f = document.getElementById('fabPlus'),
        m = document.getElementById('fabMenu'); if (fabMenuOpen && !f.contains(e.target) && !m.contains(e.target)) { fabMenuOpen = false;
        f.classList.remove('open');
        m.classList.remove('open'); } });

function switchTab(tab, btn) {
    currentTab = tab;
    document.querySelectorAll('.tab').forEach(e => e.classList.remove('active'));
    if (btn) btn.classList.add('active');
    page = 0;
    hasMore = true;
    adCounter = 0;
    signals = [];
    document.getElementById('feedSignals').innerHTML = '';
    document.getElementById('endMessage').classList.remove('show');
    initFeed();
    updateFabMenu();
}

function toggleDrawer() { const o = document.getElementById('drawerOverlay');
    o.classList.toggle('open');
    document.body.style.overflow = o.classList.contains('open') ? 'hidden' : '';
    const u = getUser();
    const av = document.querySelector('.drawer-av'); if (av) av.textContent = u.avatar;
    const un = document.querySelector('.drawer-un'); if (un) un.textContent = u.name;
    document.getElementById('drawerFollowers').textContent = u.followers + ' ' + t('fol');
    document.getElementById('drawerFollowing').textContent = u.following + ' ' + t('folc'); }
function closeDrawer() { document.getElementById('drawerOverlay').classList.remove('open');
    document.body.style.overflow = ''; }

function goTo(p) { const map = { dashboard: 'dashboard.html', signals_feed: 'signals_feed.html', markets: 'markets.html',
        explore: 'explore.html', signal: 'signal-request.html' };
    const url = map[p]; if (url) window.location.href = url; }

function openSendSignalSheet() {
    document.getElementById('sendSignalSheet').classList.add('open');
    sendSelectedType = '';
    document.querySelectorAll('#sendSignalBody .btn-type').forEach(b => b.classList.remove('selected'));
    document.querySelectorAll('#sendSignalBody .error-msg').forEach(e => e.classList.remove('show'));
    document.getElementById('sendCoinSelected').textContent = 'انتخاب کنید';
    document.getElementById('sendCoinSelect').querySelector('.options').classList.remove('show');
    document.getElementById('sendEntry').value = '';
    document.getElementById('sendTP').value = '';
    document.getElementById('sendSL').value = '';
    document.getElementById('sendConfidence').value = '';
    document.getElementById('sendDesc').value = '';
    const firstOpt = document.querySelector('#sendCoinOptions .opt'); if (firstOpt) selectOption('sendCoinSelect', firstOpt.dataset.value, firstOpt.textContent.trim());
    document.getElementById('sendSignalBtn').disabled = false;
}

function closeSendSignalSheet() { document.getElementById('sendSignalSheet').classList.remove('open'); }

function openSellSignalSheet() {
    document.getElementById('sellSignalSheet').classList.add('open');
    sellSelectedType = '';
    document.querySelectorAll('#sellSignalBody .btn-type').forEach(b => b.classList.remove('selected'));
    document.querySelectorAll('#sellSignalBody .error-msg').forEach(e => e.classList.remove('show'));
    document.getElementById('sellCoinSelected').textContent = 'انتخاب کنید';
    document.getElementById('sellCoinSelect').querySelector('.options').classList.remove('show');
    document.getElementById('sellEntry').value = '';
    document.getElementById('sellTP').value = '';
    document.getElementById('sellSL').value = '';
    document.getElementById('sellPrice').value = '';
    document.getElementById('sellDesc').value = '';
    const firstOpt = document.querySelector('#sellCoinOptions .opt'); if (firstOpt) selectOption('sellCoinSelect', firstOpt.dataset.value, firstOpt.textContent.trim());
    document.getElementById('sellSignalBtn').disabled = false;
}

function closeSellSignalSheet() { document.getElementById('sellSignalSheet').classList.remove('open'); }

function toggleSelect(id) {
    const wrapper = document.getElementById(id);
    const opts = wrapper.querySelector('.options');
    const isOpen = opts.classList.contains('show');
    document.querySelectorAll('.select-wrapper .options').forEach(o => o.classList.remove('show'));
    if (!isOpen) opts.classList.add('show');
}

function filterSelectOptions(id, val) {
    const wrapper = document.getElementById(id);
    const opts = wrapper.querySelectorAll('.opt');
    const q = val.trim().toLowerCase();
    opts.forEach(o => { const txt = o.textContent.trim().toLowerCase();
        o.style.display = txt.includes(q) ? 'block' : 'none'; });
}

function selectOption(id, value, label) {
    const wrapper = document.getElementById(id);
    wrapper.querySelector('.selected span:first-child').textContent = label;
    wrapper.querySelector('.options').classList.remove('show');
    wrapper.querySelectorAll('.opt').forEach(o => o.classList.remove('selected'));
    const opt = wrapper.querySelector(`.opt[data-value="${value}"]`); if (opt) opt.classList.add('selected');
    const errId = id === 'sendCoinSelect' ? 'sendCoinError' : (id === 'sellCoinSelect' ? 'sellCoinError' :
        'editCoinError');
    document.getElementById(errId).classList.remove('show');
}

function selectSignalType(prefix, type) {
    const container = document.getElementById(prefix + 'SignalBody');
    container.querySelectorAll('.btn-type').forEach(b => b.classList.remove('selected'));
    const btn = container.querySelector(`.btn-type[data-type="${type}"]`); if (btn) btn.classList.add('selected');
    if (prefix === 'send') sendSelectedType = type;
    else if (prefix === 'sell') sellSelectedType = type;
    else if (prefix === 'edit') editSelectedType = type;
    document.getElementById(prefix + 'TypeError').classList.remove('show');
}

function validateSendSignal() {
    let valid = true;
    const coin = document.getElementById('sendCoinSelected').textContent;
    if (!coin || coin === 'انتخاب کنید') { document.getElementById('sendCoinError').classList.add('show');
        valid = false; }
    if (!sendSelectedType) { document.getElementById('sendTypeError').classList.add('show');
        valid = false; }
    const entry = parseFloat(document.getElementById('sendEntry').value.trim());
    if (isNaN(entry) || entry <= 0) { document.getElementById('sendEntryError').classList.add('show');
        valid = false; }
    const tp = parseFloat(document.getElementById('sendTP').value.trim());
    if (isNaN(tp) || tp <= 0) { document.getElementById('sendTPError').classList.add('show');
        valid = false; }
    const sl = parseFloat(document.getElementById('sendSL').value.trim());
    if (isNaN(sl) || sl <= 0) { document.getElementById('sendSLError').classList.add('show');
        valid = false; }
    const conf = document.getElementById('sendConfidence').value.trim();
    if (conf !== '') { const c = parseFloat(conf); if (isNaN(c) || c < 0 || c > 100) { document.getElementById('sendConfidenceError').classList.add('show');
            valid = false; } }
    return valid;
}

async function publishPublicSignal() {
    if (!validateSendSignal()) return;
    const btn = document.getElementById('sendSignalBtn');
    btn.disabled = true;
    btn.textContent = '⏳ در حال انتشار...';
    const data = {
        coin: document.getElementById('sendCoinSelected').textContent,
        type: sendSelectedType,
        entry: document.getElementById('sendEntry').value.trim(),
        tp: document.getElementById('sendTP').value.trim(),
        sl: document.getElementById('sendSL').value.trim(),
        confidence: document.getElementById('sendConfidence').value.trim() || '۸۰',
        desc: document.getElementById('sendDesc').value.trim(),
    };
    try {
        const newSignal = await API.Signals.createPublic(data);
        signals.unshift({
            id: newSignal.id || Date.now(),
            user: 'شما',
            username: '@' + getUser().name.replace(/\s/g, ''),
            avatar: getUser().avatar || 'ش',
            verified: true,
            time: Date.now(),
            type: data.type,
            coin: data.coin,
            entry: '$' + data.entry,
            tp: '$' + data.tp,
            sl: '$' + data.sl,
            confidence: parseInt(data.confidence) || 80,
            views: 0,
            likes: 0,
            comments: 0,
            reposts: 0,
            liked: false,
            saved: false,
            reposted: false,
            owner: true,
            isMarket: false,
            isAI: false,
            desc: data.desc
        });
        renderSignals();
        btn.disabled = false;
        btn.textContent = 'انتشار سیگنال';
        closeSendSignalSheet();
        showToast('✅ سیگنال با موفقیت منتشر شد');
    } catch (e) {
        const signalsLocal = JSON.parse(localStorage.getItem('pulset_signals') || '[]');
        const newSignal = {
            id: Date.now(),
            user: 'شما',
            username: '@' + getUser().name.replace(/\s/g, ''),
            avatar: getUser().avatar || 'ش',
            verified: true,
            time: Date.now(),
            type: data.type,
            coin: data.coin,
            entry: '$' + data.entry,
            tp: '$' + data.tp,
            sl: '$' + data.sl,
            confidence: parseInt(data.confidence) || 80,
            views: 0,
            likes: 0,
            comments: 0,
            reposts: 0,
            liked: false,
            saved: false,
            reposted: false,
            owner: true,
            isMarket: false,
            isAI: false,
            desc: data.desc
        };
        signalsLocal.unshift(newSignal);
        localStorage.setItem('pulset_signals', JSON.stringify(signalsLocal));
        signals.unshift(newSignal);
        renderSignals();
        btn.disabled = false;
        btn.textContent = 'انتشار سیگنال';
        closeSendSignalSheet();
        showToast('✅ سیگنال با موفقیت منتشر شد');
    }
}

function validateSellSignal() {
    let valid = true;
    const coin = document.getElementById('sellCoinSelected').textContent;
    if (!coin || coin === 'انتخاب کنید') { document.getElementById('sellCoinError').classList.add('show');
        valid = false; }
    if (!sellSelectedType) { document.getElementById('sellTypeError').classList.add('show');
        valid = false; }
    const entry = parseFloat(document.getElementById('sellEntry').value.trim());
    if (isNaN(entry) || entry <= 0) { document.getElementById('sellEntryError').classList.add('show');
        valid = false; }
    const tp = parseFloat(document.getElementById('sellTP').value.trim());
    if (isNaN(tp) || tp <= 0) { document.getElementById('sellTPError').classList.add('show');
        valid = false; }
    const sl = parseFloat(document.getElementById('sellSL').value.trim());
    if (isNaN(sl) || sl <= 0) { document.getElementById('sellSLError').classList.add('show');
        valid = false; }
    const price = parseFloat(document.getElementById('sellPrice').value.trim().replace(/,/g, ''));
    if (isNaN(price) || price <= 0) { document.getElementById('sellPriceError').classList.add('show');
        valid = false; }
    return valid;
}

async function publishMarketSignal() {
    if (!validateSellSignal()) return;
    const btn = document.getElementById('sellSignalBtn');
    btn.disabled = true;
    btn.textContent = '⏳ در حال انتشار...';
    const price = parseFloat(document.getElementById('sellPrice').value.trim().replace(/,/g, ''));
    const data = {
        coin: document.getElementById('sellCoinSelected').textContent,
        type: sellSelectedType,
        entry: document.getElementById('sellEntry').value.trim(),
        tp: document.getElementById('sellTP').value.trim(),
        sl: document.getElementById('sellSL').value.trim(),
        price: price,
        desc: document.getElementById('sellDesc').value.trim(),
    };
    try {
        const newSignal = await API.Signals.createMarket(data);
        signals.unshift({
            id: newSignal.id || Date.now(),
            user: 'شما',
            username: '@' + getUser().name.replace(/\s/g, ''),
            avatar: getUser().avatar || 'ش',
            verified: true,
            time: Date.now(),
            type: data.type,
            coin: data.coin,
            entry: '$' + data.entry,
            tp: '$' + data.tp,
            sl: '$' + data.sl,
            confidence: 80,
            price: data.price,
            views: 0,
            likes: 0,
            comments: 0,
            reposts: 0,
            liked: false,
            saved: false,
            reposted: false,
            owner: true,
            isMarket: true,
            isAI: false,
            isPurchased: false,
            desc: data.desc
        });
        renderSignals();
        btn.disabled = false;
        btn.textContent = 'انتشار در بازار';
        closeSellSignalSheet();
        showToast('✅ سیگنال با موفقیت در بازار منتشر شد');
    } catch (e) {
        const signalsLocal = JSON.parse(localStorage.getItem('pulset_signals') || '[]');
        const newSignal = {
            id: Date.now(),
            user: 'شما',
            username: '@' + getUser().name.replace(/\s/g, ''),
            avatar: getUser().avatar || 'ش',
            verified: true,
            time: Date.now(),
            type: data.type,
            coin: data.coin,
            entry: '$' + data.entry,
            tp: '$' + data.tp,
            sl: '$' + data.sl,
            confidence: 80,
            price: data.price,
            views: 0,
            likes: 0,
            comments: 0,
            reposts: 0,
            liked: false,
            saved: false,
            reposted: false,
            owner: true,
            isMarket: true,
            isAI: false,
            isPurchased: false,
            desc: data.desc
        };
        signalsLocal.unshift(newSignal);
        localStorage.setItem('pulset_signals', JSON.stringify(signalsLocal));
        signals.unshift(newSignal);
        renderSignals();
        btn.disabled = false;
        btn.textContent = 'انتشار در بازار';
        closeSellSignalSheet();
        showToast('✅ سیگنال با موفقیت در بازار منتشر شد');
    }
}

function showHistory() {
    const list = document.getElementById('historyList');
    if (!signalHistory.length) {
        list.innerHTML =
        `<div style="padding:16px;text-align:center;color:var(--text3);font-size:13px;">${t('no_history')}</div>`;
        return;
    }
    list.innerHTML = signalHistory.slice(0, 8).map(h => {
        const icon = h.type === 'buy' ? '📈' : (h.type === 'sell' ? '📉' : '⚖️');
        const typeLabel = h.type === 'buy' ? 'خرید' : (h.type === 'sell' ? 'فروش' : 'خنثی');
        return `<div class="history-item"><div class="h-left"><div class="h-icon ${h.type}">${icon}</div><span class="h-coin">${h.coin}</span><span class="h-type ${h.type}">${typeLabel}</span></div><span class="h-time">${new Date(h.time).toLocaleTimeString('fa-IR', {hour:'2-digit', minute:'2-digit'})}</span></div>`;
    }).join('');
}

document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    applyPageTranslations();
    initFeed();
    updateFabMenu();
    const path = window.location.pathname.split('/').pop() || 'signals_feed.html';
    const pm = { dashboard: 'dashboard', signals_feed: 'signals_feed', markets: 'markets', explore: 'explore' };
    const cp = pm[path.split('.')[0]] || 'signals_feed';
    document.querySelectorAll('.nav').forEach(n => n.classList.toggle('active', n.dataset.page === cp));
    if (cp === 'signal') document.getElementById('centerBtn')?.classList.add('active');
    if (signalHistory.length > 0) showHistory();
    console.log('✅ signals_feed.js loaded');
});

window.toggleDark = toggleDark;
window.toggleLang = toggleLang;
window.switchTab = switchTab;
window.toggleDrawer = toggleDrawer;
window.closeDrawer = closeDrawer;
window.toggleLike = toggleLike;
window.toggleBookmark = toggleBookmark;
window.purchaseSignal = purchaseSignal;
window.closePaySheet = closePaySheet;
window.selectPayMethod = selectPayMethod;
window.goToAddFunds = goToAddFunds;
window.confirmPayment = confirmPayment;
window.openEditSignal = openEditSignal;
window.closeEditSignalSheet = closeEditSignalSheet;
window.updateSignal = updateSignal;
window.openComments = openComments;
window.closeCommentSheet = closeCommentSheet;
window.addComment = addComment;
window.openRepost = openRepost;
window.closeRepostSheet = closeRepostSheet;
window.doRepost = doRepost;
window.openQuoteSheet = openQuoteSheet;
window.closeQuoteSheet = closeQuoteSheet;
window.publishQuote = publishQuote;
window.openReportSheet = openReportSheet;
window.closeReportSheet = closeReportSheet;
window.submitReport = submitReport;
window.openShareModal = openShareModal;
window.closeShareModal = closeShareModal;
window.copyLink = copyLink;
window.shareNative = shareNative;
window.toggleFabMenu = toggleFabMenu;
window.toggleDropdown = toggleDropdown;
window.openSendSignalSheet = openSendSignalSheet;
window.closeSendSignalSheet = closeSendSignalSheet;
window.openSellSignalSheet = openSellSignalSheet;
window.closeSellSignalSheet = closeSellSignalSheet;
window.selectSignalType = selectSignalType;
window.toggleSelect = toggleSelect;
window.filterSelectOptions = filterSelectOptions;
window.selectOption = selectOption;
window.publishPublicSignal = publishPublicSignal;
window.publishMarketSignal = publishMarketSignal;
window.showToast = showToast;
