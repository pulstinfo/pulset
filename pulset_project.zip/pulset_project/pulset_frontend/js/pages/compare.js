// ================================================================
// compare.js - اسکریپت صفحه مقایسه ارزها
// ================================================================

// ===== ترجمه =====
const PAGE_TR = {
    fa: {
        pageTitle: 'مقایسه ارزها',
        slot1_label: 'انتخاب ارز اول',
        slot2_label: 'انتخاب ارز دوم',
        get_analysis: 'دریافت تحلیل مقایسه‌ای',
        timeframe: 'بازه زمانی تحلیل',
        short_term: 'کوتاه‌مدت (ساعتی)',
        medium_term: 'میان‌مدت (روزانه)',
        long_term: 'بلندمدت (هفتگی)',
        analysis_type: 'نوع تحلیل',
        both: 'تکنیکال + فاندامنتال',
        technical_only: 'فقط تکنیکال',
        fundamental_only: 'فقط فاندامنتال',
        criterion: 'معیار اصلی مقایسه',
        performance: 'عملکرد قیمتی',
        volume: 'حجم معاملات',
        volatility: 'نوسان‌پذیری',
        risk_reward_criterion: 'نسبت ریسک/ریوارد',
        min_volume: 'حداقل حجم روزانه',
        min_volume_hint: 'حداقل حجم معاملات روزانه (میلیون دلار)',
        risk_filter: 'فیلتر ریسک',
        all_risk: 'همه',
        low_risk: 'کم‌ریسک',
        medium_risk: 'متوسط',
        high_risk: 'پرریسک',
        priority: 'اولویت',
        growth: 'رشد',
        stability: 'پایداری',
        momentum: 'لحظه‌ای',
        close: 'بستن',
        copy: 'کپی تحلیل',
        save: 'ذخیره',
        saved: 'ذخیره شد',
        unsaved: 'حذف از ذخیره‌ها',
        copied: '✅ تحلیل کپی شد',
        error: 'خطا در دریافت تحلیل'
    },
    en: {
        pageTitle: 'Compare Assets',
        slot1_label: 'Select first asset',
        slot2_label: 'Select second asset',
        get_analysis: 'Get Comparison Analysis',
        timeframe: 'Timeframe',
        short_term: 'Short-term (Hourly)',
        medium_term: 'Medium-term (Daily)',
        long_term: 'Long-term (Weekly)',
        analysis_type: 'Analysis Type',
        both: 'Technical + Fundamental',
        technical_only: 'Technical Only',
        fundamental_only: 'Fundamental Only',
        criterion: 'Main Criterion',
        performance: 'Price Performance',
        volume: 'Trading Volume',
        volatility: 'Volatility',
        risk_reward_criterion: 'Risk/Reward Ratio',
        min_volume: 'Min Daily Volume',
        min_volume_hint: 'Minimum daily trading volume (million USD)',
        risk_filter: 'Risk Filter',
        all_risk: 'All',
        low_risk: 'Low Risk',
        medium_risk: 'Medium Risk',
        high_risk: 'High Risk',
        priority: 'Priority',
        growth: 'Growth',
        stability: 'Stability',
        momentum: 'Momentum',
        close: 'Close',
        copy: 'Copy Analysis',
        save: 'Save',
        saved: 'Saved',
        unsaved: 'Removed from saved',
        copied: '✅ Analysis copied',
        error: 'Error getting analysis'
    }
};

// ===== متغیرها =====
let allAssets = [];
let selectedAssets = [null, null];
let savedAnalyses = JSON.parse(localStorage.getItem('pulset_compare_saved') || '[]');
let currentAnalysis = null;
let activeSlot = 0;

// ===== اعمال ترجمه =====
function applyPageTranslations() {
    const lang = getCurrentLang();
    const t = PAGE_TR[lang] || PAGE_TR.fa;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key]) el.textContent = t[key];
    });
}
window.applyPageTranslations = applyPageTranslations;

// ===== تابع t محلی =====
function t(key) {
    const lang = getCurrentLang();
    return PAGE_TR[lang]?.[key] || key;
}

// ===== داده‌های دارایی‌ها =====
function getDefaultAssets() {
    return [
        { id: 'btc', name: 'بیت‌کوین', symbol: 'BTC/USDT', icon: '₿', price: 67245, change: 2.34 },
        { id: 'eth', name: 'اتریوم', symbol: 'ETH/USDT', icon: 'Ξ', price: 3515, change: -1.12 },
        { id: 'sol', name: 'سولانا', symbol: 'SOL/USDT', icon: '◎', price: 178, change: 5.72 },
        { id: 'ada', name: 'کاردانو', symbol: 'ADA/USDT', icon: '₳', price: 0.452, change: 3.85 },
        { id: 'bnb', name: 'بایننس کوین', symbol: 'BNB/USDT', icon: '🟡', price: 598, change: 1.92 },
        { id: 'xrp', name: 'ریپل', symbol: 'XRP/USDT', icon: '✕', price: 0.621, change: -0.75 },
        { id: 'doge', name: 'دوج کوین', symbol: 'DOGE/USDT', icon: '🐕', price: 0.158, change: 4.2 },
        { id: 'dot', name: 'پولکادات', symbol: 'DOT/USDT', icon: '●', price: 7.25, change: -2.1 },
        { id: 'ltc', name: 'لایت کوین', symbol: 'LTC/USDT', icon: 'Ł', price: 82.4, change: 1.3 },
        { id: 'avax', name: 'آوالانچ', symbol: 'AVAX/USDT', icon: '▲', price: 45.8, change: 3.2 },
        { id: 'matic', name: 'پالیگان', symbol: 'MATIC/USDT', icon: '⬡', price: 0.92, change: -0.8 },
        { id: 'gold', name: 'طلا', symbol: 'XAU/USD', icon: '🥇', price: 2340, change: 1.1 },
        { id: 'silver', name: 'نقره', symbol: 'XAG/USD', icon: '🥈', price: 28.9, change: -0.5 },
        { id: 'oil', name: 'نفت خام', symbol: 'WTI/USD', icon: '🛢️', price: 78.5, change: 0.8 }
    ];
}

// ===== دریافت دارایی‌ها از API =====
async function fetchAssets() {
    try {
        const data = await API.Markets.get('all', '', 0, 30);
        if (data && data.length) {
            return data.map(item => ({
                id: item.id || item.symbol || 'asset_' + Math.random(),
                name: item.name || 'نامشخص',
                symbol: item.symbol || '---',
                icon: item.icon || '📊',
                price: item.price || 0,
                change: item.change || 0
            }));
        }
        return getDefaultAssets();
    } catch (e) {
        console.warn('Fetch assets error, using fallback:', e);
        return getDefaultAssets();
    }
}

// ===== رندر اسلات‌ها =====
function renderSlots() {
    for (let i = 0; i < 2; i++) {
        const slot = document.getElementById('slot' + (i + 1));
        const asset = selectedAssets[i];
        if (asset) {
            slot.className = 'slot filled';
            slot.innerHTML = `
                <span class="icon">${asset.icon}</span>
                <span class="name">${asset.name}</span>
                <span class="symbol">${asset.symbol}</span>
                <span class="price">$${asset.price.toFixed(2)}</span>
                <button class="remove-btn" onclick="event.stopPropagation();removeAsset(${i})"><i class="fas fa-times"></i></button>
            `;
        } else {
            slot.className = 'slot';
            slot.innerHTML = `
                <span class="add-icon"><i class="fas fa-plus-circle"></i></span>
                <span class="label">${i === 0 ? t('slot1_label') : t('slot2_label')}</span>
            `;
        }
    }
    updateSettingsVisibility();
    updateCompareBtn();
}

function updateSettingsVisibility() {
    const area = document.getElementById('settingsArea');
    const filled = selectedAssets.filter(a => a !== null).length;
    area.classList.toggle('show', filled === 2);
}

function updateCompareBtn() {
    const btn = document.getElementById('compareBtn');
    const filled = selectedAssets.filter(a => a !== null).length;
    btn.disabled = filled < 2;
    if (filled < 2) {
        btn.innerHTML = '<i class="fas fa-robot"></i> <span>' + t('get_analysis') + '</span>';
    } else {
        btn.innerHTML = '<i class="fas fa-robot"></i> <span>' + t('get_analysis') + '</span>';
    }
}

// ===== جستجو =====
function openSearchModal(slotIndex) {
    if (selectedAssets[slotIndex]) return;
    activeSlot = slotIndex;
    document.getElementById('searchModal').classList.add('show');
    document.getElementById('searchInput').value = '';
    document.getElementById('searchResults').innerHTML = '';
    document.getElementById('searchInput').focus();
    filterSearch();
}

function closeSearchModal() {
    document.getElementById('searchModal').classList.remove('show');
}

function filterSearch() {
    const q = document.getElementById('searchInput').value.trim().toLowerCase();
    const results = document.getElementById('searchResults');
    const filtered = allAssets.filter(a => {
        if (selectedAssets[0] && selectedAssets[0].id === a.id) return false;
        if (selectedAssets[1] && selectedAssets[1].id === a.id) return false;
        return a.name.includes(q) || a.symbol.toLowerCase().includes(q);
    });
    if (filtered.length === 0) {
        results.innerHTML = '<div style="padding:12px;text-align:center;color:var(--text3);">نتیجه‌ای یافت نشد</div>';
        return;
    }
    results.innerHTML = filtered.map(a =>
        `<div class="result-item" onclick="selectAsset('${a.id}')">
            <span class="icon">${a.icon}</span>
            <div class="info"><div class="name">${a.name}</div><div class="symbol">${a.symbol}</div></div>
            <div class="price">$${a.price.toFixed(2)}</div>
        </div>`
    ).join('');
}

document.getElementById('searchInput').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
        const first = document.querySelector('.result-item');
        if (first) first.click();
    }
    if (e.key === 'Escape') closeSearchModal();
});
document.getElementById('searchModal').addEventListener('click', function(e) {
    if (e.target === this) closeSearchModal();
});

// ===== انتخاب و حذف =====
function selectAsset(id) {
    const asset = allAssets.find(a => a.id === id);
    if (!asset) return;
    selectedAssets[activeSlot] = asset;
    closeSearchModal();
    renderSlots();
}

function removeAsset(index) {
    selectedAssets[index] = null;
    renderSlots();
}

// ===== تنظیمات =====
function getSettings() {
    return {
        timeframe: document.getElementById('timeframe').value,
        analysisType: document.getElementById('analysisType').value,
        criterion: document.getElementById('criterion').value,
        minVolume: parseInt(document.getElementById('minVolume').value) || 10,
        riskFilter: document.getElementById('riskFilter').value,
        priority: document.getElementById('priority').value
    };
}

// ===== تحلیل با AI =====
async function compareWithAI() {
    const a1 = selectedAssets[0],
        a2 = selectedAssets[1];
    if (!a1 || !a2) {
        showToast('لطفاً هر دو ارز را انتخاب کنید.');
        return;
    }

    const settings = getSettings();
    const overlay = document.getElementById('analysisSheetOverlay');
    const loading = document.getElementById('analysisLoading');
    const result = document.getElementById('analysisResult');
    const error = document.getElementById('analysisError');

    overlay.classList.add('open');
    loading.classList.add('show');
    result.classList.remove('show');
    error.classList.remove('show');

    try {
        const data = await getAIComparison(a1, a2, settings);
        if (data && data.summary) {
            displayComparison(data, a1, a2);
            loading.classList.remove('show');
            result.classList.add('show');
        } else {
            throw new Error('Invalid response');
        }
    } catch (e) {
        console.error('Comparison error:', e);
        loading.classList.remove('show');
        error.classList.add('show');
    }
}

async function getAIComparison(a1, a2, settings) {
    const prompt = `
        تحلیل مقایسه‌ای حرفه‌ای بین دو دارایی:
        ${a1.name} (${a1.symbol}): قیمت $${a1.price.toFixed(2)}، تغییر ${a1.change > 0 ? '+' : ''}${a1.change}%
        ${a2.name} (${a2.symbol}): قیمت $${a2.price.toFixed(2)}، تغییر ${a2.change > 0 ? '+' : ''}${a2.change}%

        تنظیمات تحلیل:
        - بازه زمانی: ${settings.timeframe === 'short' ? 'کوتاه‌مدت (ساعتی)' : settings.timeframe === 'medium' ? 'میان‌مدت (روزانه)' : 'بلندمدت (هفتگی)'}
        - نوع تحلیل: ${settings.analysisType === 'technical' ? 'فقط تکنیکال' : settings.analysisType === 'fundamental' ? 'فقط فاندامنتال' : 'تکنیکال + فاندامنتال'}
        - معیار اصلی: ${settings.criterion === 'performance' ? 'عملکرد قیمتی' : settings.criterion === 'volume' ? 'حجم معاملات' : settings.criterion === 'volatility' ? 'نوسان‌پذیری' : 'نسبت ریسک/ریوارد'}
        - حداقل حجم روزانه: ${settings.minVolume} میلیون دلار
        - فیلتر ریسک: ${settings.riskFilter === 'low' ? 'کم‌ریسک' : settings.riskFilter === 'medium' ? 'متوسط' : 'پرریسک'}
        - اولویت: ${settings.priority === 'growth' ? 'رشد' : settings.priority === 'stability' ? 'پایداری' : 'لحظه‌ای'}

        لطفاً تحلیل جامع و حرفه‌ای با ساختار زیر ارائه بده:
        ۱. خلاصه مقایسه (مختصر و دقیق)
        ۲. تحلیل تکنیکال (با اشاره به اندیکاتورها و سطوح کلیدی)
        ۳. تحلیل فاندامنتال (بر اساس داده‌های موجود)
        ۴. پیش‌بینی کوتاه‌مدت و توصیه سرمایه‌گذاری
        ۵. سطح اطمینان (به درصد)

        پاسخ باید به زبان فارسی و با لحن حرفه‌ای تحلیلگران ارشد باشد.
    `;

    try {
        const response = await API.AI.chat(prompt, 'openai');
        if (response && response.reply) {
            return parseAIResponse(response.reply);
        }
        return getLocalComparison(a1, a2, settings);
    } catch (e) {
        console.warn('AI error, using fallback:', e);
        return getLocalComparison(a1, a2, settings);
    }
}

function parseAIResponse(reply) {
    try {
        const result = { summary: '', technical: '', fundamental: '', prediction: '', confidence: 70 };
        const sections = reply.split(/\n(?=[*#]|\d+\.)/);
        sections.forEach(part => {
            const lower = part.toLowerCase();
            if (lower.includes('خلاصه') || lower.includes('summary')) {
                result.summary = part.replace(/^.*?(خلاصه|summary)[\s:]*/i, '').trim();
            } else if (lower.includes('تکنیکال') || lower.includes('technical')) {
                result.technical = part.replace(/^.*?(تکنیکال|technical)[\s:]*/i, '').trim();
            } else if (lower.includes('فاندامنتال') || lower.includes('fundamental')) {
                result.fundamental = part.replace(/^.*?(فاندامنتال|fundamental)[\s:]*/i, '').trim();
            } else if (lower.includes('پیش‌بینی') || lower.includes('توصیه') || lower.includes('prediction')) {
                result.prediction = part.replace(/^.*?(پیش‌بینی|توصیه|prediction)[\s:]*/i, '').trim();
            } else if (lower.includes('اطمینان') || lower.includes('confidence')) {
                const conf = part.match(/(\d+)/);
                if (conf) result.confidence = parseInt(conf[1]) || 70;
            }
        });
        if (!result.summary && !result.technical && !result.fundamental && !result.prediction) {
            result.summary = reply;
        }
        return result;
    } catch (e) {
        return { summary: reply, technical: '', fundamental: '', prediction: '', confidence: 70 };
    }
}

function getLocalComparison(a1, a2, settings) {
    const better = a1.change > a2.change ? a1.name : (a2.change > a1.change ? a2.name : 'هر دو');
    const timeMap = { short: 'کوتاه‌مدت', medium: 'میان‌مدت', long: 'بلندمدت' };
    return {
        summary: `مقایسه ${a1.name} و ${a2.name} در بازه ${timeMap[settings.timeframe]}:\n` +
            `${a1.name}: $${a1.price.toFixed(2)} (${a1.change > 0 ? '+' : ''}${a1.change}%)\n` +
            `${a2.name}: $${a2.price.toFixed(2)} (${a2.change > 0 ? '+' : ''}${a2.change}%)\n` +
            `${better} عملکرد بهتری داشته است. با توجه به معیار ${settings.criterion === 'performance' ? 'عملکرد قیمتی' : 'حجم معاملات'}، ${a1.price > a2.price ? a1.name : a2.name} ارزش بالاتری دارد.`,
        technical: `تحلیل تکنیکال: ${a1.name} در محدوده ${a1.change > 0 ? 'صعودی' : 'نوسانی'} و ${a2.name} در محدوده ${a2.change > 0 ? 'صعودی' : 'نوسانی'} قرار دارد. RSI و MACD نشان‌دهنده ${a1.change > a2.change ? 'قدرت خریداران در ' + a1.name : 'احتیاط در ' + a2.name} است.`,
        fundamental: `تحلیل فاندامنتال: ${a1.price > a2.price ? a1.name : a2.name} ارزش بازار بالاتری دارد. با در نظر گرفتن حداقل حجم ${settings.minVolume} میلیون دلار، هر دو دارایی نقدشوندگی قابل قبولی دارند.`,
        prediction: `پیش‌بینی: در بازه ${timeMap[settings.timeframe]}، ${a1.change > a2.change ? a1.name : a2.name} احتمال رشد بیشتری دارد. توصیه می‌شود با مدیریت ریسک و حد ضرر مناسب وارد معامله شوید.`,
        confidence: Math.floor(Math.random() * 20 + 70)
    };
}

// ===== نمایش تحلیل =====
function displayComparison(data, a1, a2) {
    currentAnalysis = { assets: [{ ...a1 }, { ...a2 }], data: data, time: Date.now() };

    const header = document.getElementById('compareHeader');
    header.innerHTML = `
        <div class="asset">
            <span class="icon">${a1.icon}</span>
            <span class="name">${a1.name}</span>
            <span class="price">$${a1.price.toFixed(2)}</span>
        </div>
        <span class="vs">VS</span>
        <div class="asset">
            <span class="icon">${a2.icon}</span>
            <span class="name">${a2.name}</span>
            <span class="price">$${a2.price.toFixed(2)}</span>
        </div>
    `;

    document.getElementById('analysisSummary').textContent = data.summary || 'خلاصه‌ای یافت نشد.';
    document.getElementById('analysisTechnical').textContent = data.technical || 'تحلیل تکنیکال یافت نشد.';
    document.getElementById('analysisFundamental').textContent = data.fundamental || 'تحلیل فاندامنتال یافت نشد.';
    document.getElementById('analysisPrediction').textContent = data.prediction || 'پیش‌بینی یافت نشد.';

    const conf = data.confidence || 70;
    document.getElementById('confidenceFill').style.width = conf + '%';
    document.getElementById('confidencePercent').textContent = conf + '%';

    const saveBtn = document.getElementById('saveAnalysisBtn');
    const isSaved = savedAnalyses.some(s =>
        s.assets[0].id === a1.id && s.assets[1].id === a2.id && s.time === currentAnalysis.time
    );
    saveBtn.classList.toggle('saved', isSaved);
    saveBtn.innerHTML = isSaved ?
        '<i class="fas fa-bookmark"></i> <span>' + t('saved') + '</span>' :
        '<i class="fas fa-bookmark"></i> <span>' + t('save') + '</span>';
}

function closeAnalysisSheet() {
    document.getElementById('analysisSheetOverlay').classList.remove('open');
}

// ===== ذخیره و کپی =====
function saveAnalysis() {
    if (!currentAnalysis) return;
    const a1 = currentAnalysis.assets[0],
        a2 = currentAnalysis.assets[1];
    const idx = savedAnalyses.findIndex(s =>
        s.assets[0].id === a1.id && s.assets[1].id === a2.id && s.time === currentAnalysis.time
    );
    const btn = document.getElementById('saveAnalysisBtn');
    if (idx > -1) {
        savedAnalyses.splice(idx, 1);
        btn.classList.remove('saved');
        btn.innerHTML = '<i class="fas fa-bookmark"></i> <span>' + t('save') + '</span>';
        showToast(t('unsaved'));
    } else {
        savedAnalyses.push({ ...currentAnalysis });
        btn.classList.add('saved');
        btn.innerHTML = '<i class="fas fa-bookmark"></i> <span>' + t('saved') + '</span>';
        showToast(t('saved'));
    }
    localStorage.setItem('pulset_compare_saved', JSON.stringify(savedAnalyses));
}

function copyAnalysis() {
    if (!currentAnalysis) return;
    const a1 = currentAnalysis.assets[0],
        a2 = currentAnalysis.assets[1];
    const text = '🤖 تحلیل مقایسه‌ای ' + a1.name + ' و ' + a2.name + '\n\n' +
        '📊 خلاصه: ' + currentAnalysis.data.summary + '\n\n' +
        '📈 تحلیل تکنیکال: ' + currentAnalysis.data.technical + '\n\n' +
        '📉 تحلیل فاندامنتال: ' + currentAnalysis.data.fundamental + '\n\n' +
        '🎯 پیش‌بینی: ' + currentAnalysis.data.prediction + '\n\n' +
        '📊 سطح اطمینان: ' + (currentAnalysis.data.confidence || 70) + '%\n\n' +
        '📱 دریافت شده از Pulset AI';

    navigator.clipboard.writeText(text).then(() => {
        showToast(t('copied'));
    }).catch(() => {
        const ta = document.createElement('textarea');
        ta.value = text;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        showToast(t('copied'));
    });
}

// ===== مقداردهی اولیه =====
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    const lang = getCurrentLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    applyPageTranslations();

    fetchAssets().then(data => {
        allAssets = data;
        renderSlots();
    });

    // بستن مودال با کلیک خارج
    document.addEventListener('click', function(e) {
        if (e.target.closest('.search-modal') && !e.target.closest('.box')) {
            closeSearchModal();
        }
    });

    console.log('✅ compare.js loaded');
});

// ===== خروجی توابع =====
window.openSearchModal = openSearchModal;
window.closeSearchModal = closeSearchModal;
window.filterSearch = filterSearch;
window.selectAsset = selectAsset;
window.removeAsset = removeAsset;
window.renderSlots = renderSlots;
window.compareWithAI = compareWithAI;
window.closeAnalysisSheet = closeAnalysisSheet;
window.saveAnalysis = saveAnalysis;
window.copyAnalysis = copyAnalysis;
window.showToast = showToast;
window.toggleDark = toggleDark;
window.toggleLang = toggleLang;
