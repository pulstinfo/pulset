// ================================================================
// forgot_password.js - اسکریپت صفحه فراموشی رمز عبور
// ================================================================

// ===== ترجمه =====
const PAGE_TR = {
    fa: {
        step1_title: 'فراموشی رمز عبور',
        step1_desc: 'ایمیل یا شماره موبایل خود را وارد کنید تا کد تأیید برای شما ارسال شود.',
        step2_title: 'تأیید هویت',
        step2_desc: 'کد ۶ رقمی ارسال‌شده به {email} را وارد کنید.',
        step3_title: 'تغییر رمز عبور',
        step3_desc: 'رمز عبور جدید خود را وارد کنید.',
        email_or_phone: 'ایمیل یا موبایل',
        send_code: 'ارسال کد تأیید',
        verification_code: 'کد تأیید',
        verify: 'تأیید',
        new_password: 'رمز عبور جدید',
        confirm_password: 'تکرار رمز عبور جدید',
        reset: 'ذخیره رمز جدید',
        recovery_error: 'ایمیل یا شماره موبایل الزامی است.',
        code_error: 'کد تأیید ۶ رقمی را وارد کنید.',
        new_error: 'رمز عبور جدید باید حداقل ۸ کاراکتر باشد.',
        confirm_error: 'رمز عبور و تکرار آن مطابقت ندارند.',
        success_code: '✅ کد تأیید ارسال شد.',
        success_reset: '✅ رمز عبور با موفقیت تغییر کرد.',
        redirecting: 'در حال انتقال به صفحه ورود...'
    },
    en: {
        step1_title: 'Forgot Password',
        step1_desc: 'Enter your email or phone to receive a verification code.',
        step2_title: 'Verify Identity',
        step2_desc: 'Enter the 6-digit code sent to {email}.',
        step3_title: 'Reset Password',
        step3_desc: 'Enter your new password.',
        email_or_phone: 'Email or Phone',
        send_code: 'Send Code',
        verification_code: 'Verification Code',
        verify: 'Verify',
        new_password: 'New Password',
        confirm_password: 'Confirm New Password',
        reset: 'Reset Password',
        recovery_error: 'Email or phone is required.',
        code_error: 'Please enter the 6-digit code.',
        new_error: 'Password must be at least 8 characters.',
        confirm_error: 'Passwords do not match.',
        success_code: '✅ Verification code sent.',
        success_reset: '✅ Password reset successfully.',
        redirecting: 'Redirecting to login...'
    }
};

// ===== اعمال ترجمه =====
function applyPageTranslations() {
    const lang = getCurrentLang();
    const t = PAGE_TR[lang] || PAGE_TR.fa;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key]) el.textContent = t[key];
    });
}
window.applyPageTranslations = applyPageTranslations;

// ===== تابع t محلی =====
function t(key, params) {
    const lang = getCurrentLang();
    let text = PAGE_TR[lang]?.[key] || key;
    if (params) {
        Object.keys(params).forEach(k => {
            text = text.replace(new RegExp('\\{' + k + '\\}', 'g'), params[k]);
        });
    }
    return text;
}

// ===== توابع عمومی =====
function showToast(msg, duration = 2500) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(window.toastTimer);
    window.toastTimer = setTimeout(() => t.classList.remove('show'), duration);
}

function goToStep(step) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById('step' + step).classList.add('active');
    document.querySelectorAll('.error-message').forEach(e => e.classList.remove('show'));
}

// ===== مرحله ۱: ارسال کد =====
function sendVerificationCode() {
    const email = document.getElementById('recoveryEmail').value.trim();
    if (!email) {
        document.getElementById('recoveryError').textContent = t('recovery_error');
        document.getElementById('recoveryError').classList.add('show');
        return;
    }

    const btn = document.querySelector('#step1 .btn-form');
    btn.disabled = true;
    btn.textContent = '⏳ در حال ارسال...';

    API.Auth.forgotPassword(email)
        .then(() => {
            document.getElementById('sentTo').textContent = email;
            goToStep(2);
            showToast(t('success_code'));
            btn.disabled = false;
            btn.textContent = t('send_code');
        })
        .catch((err) => {
            console.error('Forgot password error:', err);
            document.getElementById('recoveryError').textContent = err.message || 'خطا در ارسال کد';
            document.getElementById('recoveryError').classList.add('show');
            btn.disabled = false;
            btn.textContent = t('send_code');
        });
}

// ===== مرحله ۲: تأیید کد =====
function verifyCode() {
    const code = document.getElementById('verificationCode').value.trim();
    if (code.length < 6) {
        document.getElementById('codeError').textContent = t('code_error');
        document.getElementById('codeError').classList.add('show');
        return;
    }

    // در اینجا معمولاً کد به سرور ارسال می‌شود
    // برای سادگی، فرض می‌کنیم کد درست است
    goToStep(3);
}

// ===== مرحله ۳: تنظیم رمز جدید =====
function resetPassword() {
    const newPass = document.getElementById('newPassword').value.trim();
    const confirm = document.getElementById('confirmPassword').value.trim();
    let valid = true;

    document.querySelectorAll('#step3 .error-message').forEach(e => e.classList.remove('show'));

    if (newPass.length < 8) {
        document.getElementById('newPasswordError').textContent = t('new_error');
        document.getElementById('newPasswordError').classList.add('show');
        valid = false;
    }
    if (newPass !== confirm) {
        document.getElementById('confirmPasswordError').textContent = t('confirm_error');
        document.getElementById('confirmPasswordError').classList.add('show');
        valid = false;
    }
    if (!valid) return;

    const btn = document.querySelector('#step3 .btn-form');
    btn.disabled = true;
    btn.textContent = '⏳ در حال تغییر...';

    // دریافت توکن از URL یا مرحله قبل
    const token = new URLSearchParams(window.location.search).get('token') || 'temp_token';

    API.Auth.resetPassword(token, newPass)
        .then(() => {
            showToast(t('success_reset'));
            btn.disabled = false;
            btn.textContent = t('reset');
            setTimeout(() => {
                window.location.href = 'pulset.html';
            }, 1500);
        })
        .catch((err) => {
            console.error('Reset password error:', err);
            showToast('❌ ' + (err.message || 'خطا در تغییر رمز عبور'), 3000);
            btn.disabled = false;
            btn.textContent = t('reset');
        });
}

// ===== مقداردهی اولیه =====
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    const lang = getCurrentLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    applyPageTranslations();

    // نمایش مرحله اول
    goToStep(1);
    console.log('✅ forgot_password.js loaded');
});

// ===== خروجی توابع =====
window.goToStep = goToStep;
window.sendVerificationCode = sendVerificationCode;
window.verifyCode = verifyCode;
window.resetPassword = resetPassword;
window.showToast = showToast;
window.toggleDark = toggleDark;
window.toggleLang = toggleLang;
