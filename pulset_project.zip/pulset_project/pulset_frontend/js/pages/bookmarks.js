// ================================================================
// bookmarks.js - اسکریپت صفحه ذخیره‌ها
// ================================================================

// ===== ترجمه =====
const PAGE_TR = {
    fa: {
        pageTitle: 'ذخیره‌ها',
        emptyTitle: 'هیچ‌چیزی ذخیره نشده',
        emptyDesc: 'پست‌ها و سیگنال‌هایی که ذخیره می‌کنید، اینجا ظاهر می‌شوند.',
        removed: '🗑️ از ذخیره‌ها حذف شد',
        post: 'پست',
        signal: 'سیگنال',
        unknown: 'ناشناس'
    },
    en: {
        pageTitle: 'Bookmarks',
        emptyTitle: 'Nothing saved yet',
        emptyDesc: 'Posts and signals you save will appear here.',
        removed: '🗑️ Removed from bookmarks',
        post: 'Post',
        signal: 'Signal',
        unknown: 'Unknown'
    }
};

// ===== اعمال ترجمه =====
function applyPageTranslations() {
    const lang = getCurrentLang();
    const t = PAGE_TR[lang] || PAGE_TR.fa;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key]) el.textContent = t[key];
    });
}
window.applyPageTranslations = applyPageTranslations;

// ===== تابع t محلی =====
function t(key) {
    const lang = getCurrentLang();
    return PAGE_TR[lang]?.[key] || key;
}

// ===== داده‌های نمونه =====
function getSampleBookmarks() {
    return [
        { id: 'sample1', type: 'post', title: 'تحلیل بیت‌کوین: مقاومت ۶۸ هزار دلاری', user: 'علی معامله‌گر', link: 'dashboard.html?post=1', coin: 'BTC/USDT' },
        { id: 'sample2', type: 'signal', title: 'سیگنال خرید اتریوم با اطمینان ۸۵٪', user: 'Pulset AI', link: 'signals_feed.html?id=102', coin: 'ETH/USDT' },
        { id: 'sample3', type: 'post', title: 'بررسی تکنیکال سولانا: شکست مثلث', user: 'مریم تریدر', link: 'dashboard.html?post=2', coin: 'SOL/USDT' },
        { id: 'sample4', type: 'signal', title: 'سیگنال فروش طلا با اطمینان ۷۲٪', user: 'حسین تحلیلگر', link: 'signals_feed.html?id=103', coin: 'XAU/USD' }
    ];
}

// ===== دریافت از API =====
async function fetchBookmarks() {
    try {
        // ابتدا از localStorage بخوان
        let stored = [];
        try {
            const s = localStorage.getItem('pulset_bookmarks');
            if (s) {
                const parsed = JSON.parse(s);
                if (parsed && parsed.length) stored = parsed;
            }
        } catch (e) { /* ignore */ }

        // سپس از API دریافت کن (اگر وجود داشته باشد)
        try {
            // فرض می‌کنیم API.Profile یا API.Posts متد getBookmarks دارد
            const data = await API.Posts.getBookmarks ? await API.Posts.getBookmarks() : null;
            if (data && data.length) {
                // اگر API داده داد، آن را با localStorage ادغام کن
                const merged = [...data, ...stored.filter(s => !data.find(d => d.id === s.id))];
                localStorage.setItem('pulset_bookmarks', JSON.stringify(merged));
                return merged;
            }
        } catch (e) {
            console.warn('Fetch bookmarks API error, using stored:', e);
        }

        // اگر API داده‌ای نداشت، از localStorage استفاده کن
        if (stored.length) return stored;

        // اگر هیچ‌کدام نبود، نمونه‌ها را برگردان و ذخیره کن
        const samples = getSampleBookmarks();
        localStorage.setItem('pulset_bookmarks', JSON.stringify(samples));
        return samples;
    } catch (e) {
        console.warn('Fetch bookmarks error, using sample:', e);
        return getSampleBookmarks();
    }
}

function saveBookmarks(list) {
    localStorage.setItem('pulset_bookmarks', JSON.stringify(list));
}

// ===== حذف از ذخیره‌ها =====
async function removeBookmark(id) {
    let list = await fetchBookmarks();
    list = list.filter(item => item.id !== id);
    saveBookmarks(list);
    renderBookmarks();
    showToast(t('removed'));

    // اگر API پشتیبانی کند
    try {
        if (API.Posts.removeBookmark) {
            await API.Posts.removeBookmark(id);
        }
    } catch (e) {
        console.warn('Remove bookmark API error:', e);
    }
}

// ===== رندر =====
async function renderBookmarks() {
    const container = document.getElementById('bookmarksContainer');
    const list = await fetchBookmarks();

    if (list.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <span class="icon"><i class="fas fa-bookmark"></i></span>
                <div class="title">${t('emptyTitle')}</div>
                <div class="desc">${t('emptyDesc')}</div>
            </div>
        `;
        return;
    }

    container.innerHTML = list.map(item => {
        const typeLabel = item.type === 'post' ? t('post') : (item.type === 'signal' ? t('signal') : t('unknown'));
        const icon = item.type === 'post' ? 'fa-file-alt' : (item.type === 'signal' ? 'fa-chart-line' : 'fa-bookmark');
        const title = item.title || item.text || 'بدون عنوان';
        const displayTitle = title.length > 60 ? title.substring(0, 60) + '...' : title;
        const meta = [];
        if (item.user) meta.push(item.user);
        if (item.coin) meta.push(item.coin);
        const metaHtml = meta.length ? meta.join(' · ') : '';

        return `
            <div class="bookmark-item" onclick="window.location.href='${item.link || '#'}'">
                <div class="icon"><i class="fas ${icon}"></i></div>
                <div class="info">
                    <div class="title">${displayTitle}</div>
                    <div class="meta">
                        <span>${metaHtml}</span>
                        <span class="tag">${typeLabel}</span>
                    </div>
                </div>
                <button class="remove-btn" onclick="event.stopPropagation();removeBookmark('${item.id}')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
    }).join('');
}

// ===== مقداردهی اولیه =====
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    const lang = getCurrentLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    applyPageTranslations();

    renderBookmarks();
    console.log('✅ bookmarks.js loaded');
});

// ===== خروجی توابع =====
window.removeBookmark = removeBookmark;
window.renderBookmarks = renderBookmarks;
window.showToast = showToast;
window.toggleDark = toggleDark;
window.toggleLang = toggleLang;
