// ================================================================
// ai_chat.js - اسکریپت صفحه چت با هوش مصنوعی
// ================================================================

// ===== ترجمه =====
const PAGE_TR = {
    fa: {
        ai_chat_title: 'چت با هوش مصنوعی',
        welcome_msg: 'سلام! من دستیار هوش مصنوعی Pulset هستم. در مورد بازارهای مالی، تحلیل، سیگنال‌ها یا هر سوال دیگری که داری، بپرس.',
        placeholder: 'پیام خود را بنویسید...',
        error: 'خطا در ارتباط با AI. لطفاً مجدداً تلاش کنید.',
        clear_confirm: 'آیا مطمئنید؟ تمام تاریخچه چت پاک می‌شود.',
        clear_all: 'پاک کردن همه',
        model_label: 'مدل:',
        models: 'مدل‌ها',
        new_chat: 'چت جدید',
        history: 'تاریخچه',
        delete_confirm: 'آیا از حذف این چت مطمئنید؟',
        no_chats: 'هنوز چتی وجود ندارد'
    },
    en: {
        ai_chat_title: 'Chat with AI',
        welcome_msg: 'Hi! I\'m Pulset AI assistant. Ask me about financial markets, analysis, signals or anything else.',
        placeholder: 'Write your message...',
        error: 'Error connecting to AI. Please try again.',
        clear_confirm: 'Are you sure? All chat history will be cleared.',
        clear_all: 'Clear All',
        model_label: 'Model:',
        models: 'Models',
        new_chat: 'New Chat',
        history: 'History',
        delete_confirm: 'Are you sure you want to delete this chat?',
        no_chats: 'No chats yet'
    }
};

// ===== متغیرها =====
let currentModel = 'openai';
let currentChatId = null;
let isProcessing = false;
let allChats = JSON.parse(localStorage.getItem('pulset_ai_chats')) || [];
let chatMessages = {};

// ===== اعمال ترجمه =====
function applyPageTranslations() {
    const lang = getCurrentLang();
    const t = PAGE_TR[lang] || PAGE_TR.fa;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key]) el.textContent = t[key];
    });
    document.getElementById('chatInput').placeholder = t.placeholder;
}
window.applyPageTranslations = applyPageTranslations;

// ===== تابع t محلی =====
function t(key) {
    const lang = getCurrentLang();
    return PAGE_TR[lang]?.[key] || key;
}

// ===== مدیریت مدل =====
function selectModel(model, btn) {
    currentModel = model;
    document.querySelectorAll('.sidebar-item[data-model]').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    updateWelcomeModel();
    closeSidebar();
    showToast('✅ مدل به ' + (model === 'openai' ? 'OpenAI' : model === 'deepseek' ? 'DeepSeek' : 'xAI') + ' تغییر کرد');
}

function getModelLabel(model) {
    const map = { openai: 'OpenAI', deepseek: 'DeepSeek', xai: 'xAI' };
    return map[model] || model;
}

function updateWelcomeModel() {
    const el = document.getElementById('welcomeModel');
    if (el) el.textContent = t('model_label') + ' ' + getModelLabel(currentModel);
}

// ===== مدیریت چت‌ها =====
function generateChatTitle() {
    const now = new Date();
    const lang = getCurrentLang();
    return 'چت ' + now.toLocaleDateString(lang === 'fa' ? 'fa-IR' : 'en-US', { day: 'numeric', month: 'short' }) +
        ' ' + now.toLocaleTimeString(lang === 'fa' ? 'fa-IR' : 'en-US', { hour: '2-digit', minute: '2-digit' });
}

function getMessages(chatId) {
    if (!chatMessages[chatId]) {
        try {
            const stored = localStorage.getItem('pulset_ai_msgs_' + chatId);
            if (stored) {
                chatMessages[chatId] = JSON.parse(stored);
            } else {
                chatMessages[chatId] = [];
            }
        } catch (e) {
            chatMessages[chatId] = [];
        }
    }
    return chatMessages[chatId];
}

function saveMessages(chatId, msgs) {
    chatMessages[chatId] = msgs;
    localStorage.setItem('pulset_ai_msgs_' + chatId, JSON.stringify(msgs));
}

function saveAllChats() {
    localStorage.setItem('pulset_ai_chats', JSON.stringify(allChats));
}

function newChat() {
    const chat = {
        id: Date.now(),
        title: generateChatTitle(),
        created: Date.now(),
        model: currentModel
    };
    allChats.unshift(chat);
    saveAllChats();
    currentChatId = chat.id;
    chatMessages[chat.id] = [];
    saveMessages(chat.id, []);
    closeSidebar();
    renderChatList();
    renderMessages(chat.id);
    updateWelcomeModel();
    showToast('✅ چت جدید');
}

function deleteChat(chatId, e) {
    if (e) e.stopPropagation();
    if (!confirm(t('delete_confirm'))) return;
    allChats = allChats.filter(c => c.id !== chatId);
    delete chatMessages[chatId];
    localStorage.removeItem('pulset_ai_msgs_' + chatId);
    saveAllChats();
    if (currentChatId === chatId) {
        if (allChats.length > 0) {
            loadChat(allChats[0].id);
        } else {
            newChat();
        }
    }
    renderChatList();
    showToast('🗑️ چت حذف شد');
}

function loadChat(chatId) {
    const chat = allChats.find(c => c.id === chatId);
    if (!chat) return;
    currentChatId = chatId;
    currentModel = chat.model || 'openai';
    document.querySelectorAll('.sidebar-item[data-model]').forEach(b => {
        b.classList.toggle('active', b.dataset.model === currentModel);
    });
    closeSidebar();
    renderMessages(chatId);
    updateWelcomeModel();
    renderChatList();
}

function renderChatList() {
    const container = document.getElementById('chatHistoryList');
    if (!allChats.length) {
        container.innerHTML = '<div class="empty-chats">' + t('no_chats') + '</div>';
        return;
    }
    container.innerHTML = allChats.map(chat => `
        <div class="chat-list-item ${chat.id === currentChatId ? 'active' : ''}" onclick="loadChat(${chat.id})">
            <div class="chat-info">
                <div class="chat-title">${chat.title}</div>
                <div class="chat-date">${new Date(chat.created).toLocaleDateString(getCurrentLang() === 'fa' ? 'fa-IR' : 'en-US', { day: 'numeric', month: 'short' })} · ${new Date(chat.created).toLocaleTimeString(getCurrentLang() === 'fa' ? 'fa-IR' : 'en-US', { hour: '2-digit', minute: '2-digit' })}</div>
            </div>
            <button class="chat-delete" onclick="deleteChat(${chat.id}, event)"><i class="fas fa-times"></i></button>
        </div>
    `).join('');
}

function clearAllChats() {
    if (!confirm(t('clear_confirm'))) return;
    allChats = [];
    chatMessages = {};
    localStorage.removeItem('pulset_ai_chats');
    allChats.forEach(c => localStorage.removeItem('pulset_ai_msgs_' + c.id));
    saveAllChats();
    currentChatId = null;
    renderChatList();
    newChat();
    showToast('🗑️ همه چت‌ها پاک شد');
}

// ===== رندر پیام‌ها =====
function renderMessages(chatId) {
    const container = document.getElementById('messagesContainer');
    const msgs = getMessages(chatId);
    container.innerHTML = '';
    if (!msgs.length) {
        const welcomeDiv = document.createElement('div');
        welcomeDiv.className = 'msg ai';
        const time = formatTime(Date.now());
        welcomeDiv.innerHTML = `
            <div class="msg-avatar">AI</div>
            <div class="msg-bubble">
                <span class="welcome-badge">🤖 Pulset AI</span><br>
                <span data-i18n="welcome_msg">${t('welcome_msg')}</span>
                <span class="msg-time">${time}</span>
                <span class="msg-model">${t('model_label')} ${getModelLabel(currentModel)}</span>
            </div>
        `;
        container.appendChild(welcomeDiv);
        scrollToBottom();
        applyPageTranslations();
        return;
    }
    msgs.forEach(msg => {
        const isUser = msg.role === 'user';
        const model = msg.model || null;
        const time = formatTime(msg.time);
        const div = document.createElement('div');
        div.className = 'msg ' + (isUser ? 'user' : 'ai');
        const avatar = isUser ? 'ش' : 'AI';
        const modelHtml = model && !isUser ? `<span class="msg-model">${t('model_label')} ${getModelLabel(model)}</span>` : '';
        div.innerHTML = `
            <div class="msg-avatar">${avatar}</div>
            <div class="msg-bubble">
                ${msg.content.replace(/\n/g, '<br>')}
                ${modelHtml}
                <span class="msg-time">${time}</span>
            </div>
        `;
        container.appendChild(div);
    });
    scrollToBottom();
    applyPageTranslations();
}

function scrollToBottom() {
    const container = document.getElementById('messagesContainer');
    setTimeout(() => { container.scrollTop = container.scrollHeight; }, 50);
}

function formatTime(ts) {
    const lang = getCurrentLang();
    const date = new Date(ts);
    return date.toLocaleTimeString(lang === 'fa' ? 'fa-IR' : 'en-US', { hour: '2-digit', minute: '2-digit' });
}

// ===== سایدبار =====
function toggleSidebar() {
    document.getElementById('sidebarOverlay').classList.toggle('open');
    renderChatList();
}

function closeSidebar() {
    document.getElementById('sidebarOverlay').classList.remove('open');
}

// ===== ورودی =====
function handleKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
    }
}

function autoResize() {
    const el = document.getElementById('chatInput');
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 120) + 'px';
}
document.getElementById('chatInput').addEventListener('input', autoResize);

function closeKeyboard() {
    if (document.activeElement && document.activeElement.tagName === 'TEXTAREA') {
        document.activeElement.blur();
    }
}

// ===== دریافت پاسخ AI =====
async function getAIResponse(message, model) {
    try {
        const data = await API.AI.chat(message, model);
        if (data && data.reply) return data.reply;
        if (data && data.signal && data.signal.analysis) return data.signal.analysis;
        if (data && data.signal) {
            const s = data.signal;
            return `📊 **تحلیل هوشمند**\nنوع: ${s.type === 'buy' ? 'خرید' : s.type === 'sell' ? 'فروش' : 'خنثی'}\nورود: $${s.entry}\nحد سود: $${s.tp}\nحد ضرر: $${s.sl}\nاطمینان: ${s.confidence}%\n${s.analysis || ''}`;
        }
        if (data && data.error) throw new Error(data.error);
        return getLocalFallback(message);
    } catch (e) {
        console.error('AI Error:', e);
        return getLocalFallback(message);
    }
}

// ===== Fallback محلی =====
function getLocalFallback(message) {
    const lower = message.toLowerCase();
    const replies = {
        'بیت‌کوین|BTC|bitcoin|btc': '📊 **تحلیل بیت‌کوین (BTC/USDT)**\n• قیمت فعلی: $67,245.80\n• مقاومت کلیدی: ۶۸,۰۰۰ دلار\n• حمایت: ۶۵,۸۰۰ دلار\n• RSI: ۶۲ (خنثی)\n• پیش‌بینی: در صورت شکست مقاومت، هدف ۷۲,۰۰۰ دلار خواهد بود.',
        'اتریوم|ETH|ethereum|eth': '📊 **تحلیل اتریوم (ETH/USDT)**\n• قیمت فعلی: $3,515.20\n• مقاومت: ۳,۶۰۰ دلار\n• حمایت: ۳,۴۵۰ دلار\n• RSI: ۴۵ (خنثی)',
        'سولانا|SOL|solana|sol': '📊 **تحلیل سولانا (SOL/USDT)**\n• قیمت فعلی: $178.30\n• مقاومت: ۱۹۰ دلار\n• حمایت: ۱۷۰ دلار\n• RSI: ۵۸ (خنثی)',
        'طلا|XAU|gold': '📊 **تحلیل طلا (XAU/USD)**\n• قیمت فعلی: $۲,۳۴۰\n• مقاومت: ۲,۳۸۰ دلار\n• حمایت: ۲,۳۰۰ دلار',
        'نفت|WTI|oil': '📊 **تحلیل نفت خام (WTI)**\n• قیمت فعلی: $۷۸.۵۰\n• محدوده نوسان: ۷۵-۸۲ دلار'
    };
    for (const [keys, reply] of Object.entries(replies)) {
        if (keys.split('|').some(k => lower.includes(k))) {
            return reply + '\n\n⚠️ (تحلیل صرفاً جنبه آموزشی دارد و توصیه مالی نیست.)';
        }
    }
    if (lower.includes('سلام') || lower.includes('hi') || lower.includes('hello') || lower.includes('درود')) {
        return '👋 سلام! چطور می‌تونم بهت کمک کنم؟ درباره کدوم ارز یا بازار مالی سوال داری؟';
    }
    if (lower.includes('سیگنال') || lower.includes('signal') || lower.includes('خرید') || lower.includes('فروش')) {
        return '📈 برای دریافت سیگنال، لطفاً مشخص کن که به کدام ارز یا دارایی علاقه‌داری.';
    }
    return '🤖 من دستیار هوش مصنوعی Pulset هستم. سوالت رو دقیق‌تر بپرس تا بهتر بتونم کمک کنم. مثلاً:\n- «بیت‌کوین رو تحلیل کن»\n- «طلا چطوره؟»\n- «سیگنال خرید اتریوم»';
}

// ===== ارسال پیام =====
async function sendMessage() {
    const input = document.getElementById('chatInput');
    const text = input.value.trim();
    if (!text || isProcessing) return;

    if (!currentChatId) {
        newChat();
    }

    input.value = '';
    autoResize();
    closeKeyboard();

    const msgs = getMessages(currentChatId);
    msgs.push({ role: 'user', content: text, model: currentModel, time: Date.now() });
    saveMessages(currentChatId, msgs);
    renderMessages(currentChatId);

    const chat = allChats.find(c => c.id === currentChatId);
    if (chat && msgs.length === 1) {
        const newTitle = text.length > 30 ? text.substring(0, 30) + '...' : text;
        chat.title = newTitle;
        saveAllChats();
        renderChatList();
    }

    isProcessing = true;
    document.getElementById('sendBtn').disabled = true;
    document.getElementById('typingIndicator').classList.add('show');

    try {
        const reply = await getAIResponse(text, currentModel);
        document.getElementById('typingIndicator').classList.remove('show');
        const msgs2 = getMessages(currentChatId);
        msgs2.push({ role: 'assistant', content: reply, model: currentModel, time: Date.now() });
        saveMessages(currentChatId, msgs2);
        renderMessages(currentChatId);
    } catch (e) {
        document.getElementById('typingIndicator').classList.remove('show');
        showToast(t('error'), true);
        const msgs2 = getMessages(currentChatId);
        msgs2.push({ role: 'assistant', content: '⚠️ ' + t('error'), model: currentModel, time: Date.now() });
        saveMessages(currentChatId, msgs2);
        renderMessages(currentChatId);
    } finally {
        isProcessing = false;
        document.getElementById('sendBtn').disabled = false;
    }
}

// ===== مقداردهی اولیه =====
function init() {
    initTheme();
    const lang = getCurrentLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    applyPageTranslations();

    if (allChats.length > 0) {
        const lastActive = allChats.find(c => c.id === currentChatId) || allChats[0];
        currentChatId = lastActive.id;
        currentModel = lastActive.model || 'openai';
        document.querySelectorAll('.sidebar-item[data-model]').forEach(b => {
            b.classList.toggle('active', b.dataset.model === currentModel);
        });
        renderMessages(currentChatId);
        updateWelcomeModel();
    } else {
        newChat();
    }
    renderChatList();
    console.log('✅ ai_chat.js loaded');
}

document.addEventListener('DOMContentLoaded', init);

// ===== خروجی توابع =====
window.selectModel = selectModel;
window.newChat = newChat;
window.deleteChat = deleteChat;
window.loadChat = loadChat;
window.clearAllChats = clearAllChats;
window.sendMessage = sendMessage;
window.handleKey = handleKey;
window.toggleSidebar = toggleSidebar;
window.closeSidebar = closeSidebar;
window.showToast = showToast;
window.toggleDark = toggleDark;
window.toggleLang = toggleLang;
