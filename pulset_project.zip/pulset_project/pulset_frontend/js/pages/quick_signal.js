// ================================================================
// quick_signal.js - اسکریپت صفحه سیگنال سریع
// ================================================================

// ===== ترجمه =====
const PAGE_TR = {
    fa: {
        quick_signal_title: 'دریافت سیگنال هوشمند',
        search_coin: 'جستجوی دارایی',
        get_signal: 'دریافت سیگنال',
        loading: 'در حال تحلیل...',
        current: 'لحظه‌ای',
        entry: 'ورود',
        tp: 'حد سود',
        sl: 'حد ضرر',
        confidence: 'اطمینان',
        validity: 'اعتبار',
        premium_desc: 'سیگنال دقیق‌تر با تحلیل عمیق و اطمینان بالاتر',
        get_premium: 'دریافت',
        ai_chat: 'چت با هوش مصنوعی',
        error: 'خطا در دریافت سیگنال. لطفاً مجدداً تلاش کنید.',
        select_coin: 'لطفاً یک دارایی انتخاب کنید.',
        saved: 'ذخیره شد',
        unsaved: 'حذف از ذخیره‌ها',
        share_title: 'اشتراک‌گذاری سیگنال',
        copy_link: 'کپی لینک',
        no_history: 'هنوز سیگنالی دریافت نکرده‌اید.'
    },
    en: {
        quick_signal_title: 'Get Smart Signal',
        search_coin: 'Search Asset',
        get_signal: 'Get Signal',
        loading: 'Analyzing...',
        current: 'Current',
        entry: 'Entry',
        tp: 'Take Profit',
        sl: 'Stop Loss',
        confidence: 'Confidence',
        validity: 'Validity',
        premium_desc: 'More accurate signal with deep analysis',
        get_premium: 'Get',
        ai_chat: 'Chat with AI',
        error: 'Error getting signal. Please try again.',
        select_coin: 'Please select an asset.',
        saved: 'Saved',
        unsaved: 'Removed from saved',
        share_title: 'Share Signal',
        copy_link: 'Copy Link',
        no_history: 'No signals yet.'
    }
};

// ===== متغیرها =====
let selectedCoin = null;
let currentCategory = 'all';
let currentSignal = null;
let signalHistory = JSON.parse(localStorage.getItem('pulset_signal_history') || '[]');
let allAssets = [];

// ===== اعمال ترجمه =====
function applyPageTranslations() {
    const lang = getCurrentLang();
    const t = PAGE_TR[lang] || PAGE_TR.fa;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key]) el.textContent = t[key];
    });
}
window.applyPageTranslations = applyPageTranslations;

// ===== تابع t محلی =====
function t(key) {
    const lang = getCurrentLang();
    return PAGE_TR[lang]?.[key] || key;
}

// ===== دارایی‌ها =====
const ALL_ASSETS = [
    { id: 'bitcoin', symbol: 'BTC/USDT', name: 'بیت‌کوین', icon: '₿', cat: 'crypto' },
    { id: 'ethereum', symbol: 'ETH/USDT', name: 'اتریوم', icon: 'Ξ', cat: 'crypto' },
    { id: 'solana', symbol: 'SOL/USDT', name: 'سولانا', icon: '◎', cat: 'crypto' },
    { id: 'cardano', symbol: 'ADA/USDT', name: 'کاردانو', icon: '₳', cat: 'crypto' },
    { id: 'binancecoin', symbol: 'BNB/USDT', name: 'بایننس کوین', icon: '🟡', cat: 'crypto' },
    { id: 'ripple', symbol: 'XRP/USDT', name: 'ریپل', icon: '✕', cat: 'crypto' },
    { id: 'dogecoin', symbol: 'DOGE/USDT', name: 'دوج کوین', icon: '🐕', cat: 'crypto' },
    { id: 'polkadot', symbol: 'DOT/USDT', name: 'پولکادات', icon: '●', cat: 'crypto' },
    { id: 'litecoin', symbol: 'LTC/USDT', name: 'لایت کوین', icon: 'Ł', cat: 'crypto' },
    { id: 'chainlink', symbol: 'LINK/USDT', name: 'چین لینک', icon: '🔗', cat: 'crypto' },
    { id: 'polygon', symbol: 'MATIC/USDT', name: 'پالیگان', icon: '⬡', cat: 'crypto' },
    { id: 'avalanche-2', symbol: 'AVAX/USDT', name: 'آوالانچ', icon: '▲', cat: 'crypto' },
    { id: 'gold', symbol: 'XAU/USD', name: 'طلا', icon: '🥇', cat: 'commodity' },
    { id: 'silver', symbol: 'XAG/USD', name: 'نقره', icon: '🥈', cat: 'commodity' },
    { id: 'oil', symbol: 'WTI/USD', name: 'نفت خام', icon: '🛢️', cat: 'commodity' },
    { id: 'apple', symbol: 'AAPL', name: 'اپل', icon: '🍎', cat: 'stock' },
    { id: 'microsoft', symbol: 'MSFT', name: 'مایکروسافت', icon: '💻', cat: 'stock' },
    { id: 'tesla', symbol: 'TSLA', name: 'تسلا', icon: '🚗', cat: 'stock' },
    { id: 'amazon', symbol: 'AMZN', name: 'آمازون', icon: '📦', cat: 'stock' },
    { id: 'nvidia', symbol: 'NVDA', name: 'انویدیا', icon: '🖥️', cat: 'stock' },
    { id: 'meta', symbol: 'META', name: 'متا', icon: '📱', cat: 'stock' },
    { id: 'foolad', symbol: 'فولاد', name: 'فولاد مبارکه', icon: '🏭', cat: 'iran' },
    { id: 'meli-mos', symbol: 'فملی', name: 'ملی مس', icon: '⚒️', cat: 'iran' },
    { id: 'shesta', symbol: 'شستا', name: 'شستا', icon: '🏛️', cat: 'iran' },
    { id: 'khodro', symbol: 'خودرو', name: 'ایران خودرو', icon: '🚗', cat: 'iran' }
];

let filteredAssets = ALL_ASSETS;

// ===== دریافت قیمت =====
async function fetchPrice(symbol) {
    try {
        const data = await API.Markets.getBySymbol(symbol);
        return data.price || 0;
    } catch (e) {
        console.warn('Price fetch error:', e);
        return Math.round((Math.random() * 50000 + 40000) * 100) / 100;
    }
}

// ===== جستجو =====
function filterCoins() {
    const input = document.getElementById('searchInput');
    const query = input.value.trim().toLowerCase();
    const results = document.getElementById('searchResults');

    if (!query) {
        results.classList.remove('show');
        return;
    }

    const filtered = filteredAssets.filter(a =>
        a.name.includes(query) ||
        a.symbol.toLowerCase().includes(query) ||
        a.id.includes(query)
    );

    if (!filtered.length) {
        results.innerHTML = '<div class="empty-msg">نتیجه‌ای یافت نشد</div>';
        results.classList.add('show');
        return;
    }

    results.innerHTML = filtered.map(a => `
        <div class="item" onclick="selectCoin('${a.id}')">
            <div class="info">
                <span>${a.icon || '📊'} ${a.name}</span>
                <span class="symbol">${a.symbol}</span>
            </div>
            <span class="price">$${getAssetPrice(a.id).toFixed(2)}</span>
        </div>
    `).join('');
    results.classList.add('show');
}

function getAssetPrice(id) {
    const asset = ALL_ASSETS.find(a => a.id === id);
    if (!asset) return 0;
    return Math.round((Math.random() * 50000 + 40000) * 100) / 100;
}

// ===== دسته‌بندی =====
function setCategory(cat, btn) {
    currentCategory = cat;
    document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    filteredAssets = cat === 'all' ? ALL_ASSETS : ALL_ASSETS.filter(a => a.cat === cat);
    document.getElementById('searchInput').value = '';
    document.getElementById('searchResults').classList.remove('show');
    clearSelection();
}

// ===== انتخاب ارز =====
function selectCoin(id) {
    const coin = ALL_ASSETS.find(a => a.id === id);
    if (!coin) return;
    selectedCoin = coin;

    document.getElementById('searchInput').value = '';
    document.getElementById('searchResults').classList.remove('show');
    document.getElementById('selectedCoin').style.display = 'flex';
    document.getElementById('selectedName').textContent = (coin.icon || '📊') + ' ' + coin.name;
    document.getElementById('selectedSymbol').textContent = coin.symbol;
    document.getElementById('selectedPrice').textContent = '$--';
    document.getElementById('getSignalBtn').disabled = false;
    document.getElementById('errorMsg').classList.remove('show');

    fetchPrice(coin.symbol).then(price => {
        document.getElementById('selectedPrice').textContent = '$' + price.toFixed(2);
    }).catch(() => {
        document.getElementById('selectedPrice').textContent = '$--';
    });
}

function clearSelection() {
    selectedCoin = null;
    document.getElementById('selectedCoin').style.display = 'none';
    document.getElementById('getSignalBtn').disabled = true;
}

// ===== دریافت سیگنال =====
async function getSignal() {
    const btn = document.getElementById('getSignalBtn');
    const errorMsg = document.getElementById('errorMsg');
    const resultBox = document.getElementById('resultBox');

    if (!selectedCoin) {
        errorMsg.textContent = t('select_coin');
        errorMsg.classList.add('show');
        return;
    }

    errorMsg.classList.remove('show');
    resultBox.classList.remove('show');
    btn.disabled = true;
    btn.innerHTML = '<span class="loading-spinner"></span> <span>' + t('loading') + '</span>';

    try {
        const currentPrice = await fetchPrice(selectedCoin.symbol);
        const data = await API.AI.quickSignal(selectedCoin.symbol, selectedCoin.name, currentPrice);

        if (!data || !data.signal) {
            throw new Error('Invalid response from AI');
        }

        displaySignal({
            signal: data.signal,
            price: currentPrice,
            coin: selectedCoin
        });

        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-bolt"></i> <span>' + t('get_signal') + '</span>';

    } catch (e) {
        console.error('Signal error:', e);
        errorMsg.textContent = t('error');
        errorMsg.classList.add('show');
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-bolt"></i> <span>' + t('get_signal') + '</span>';
    }
}

// ===== نمایش سیگنال =====
function displaySignal(data) {
    const signal = data.signal;
    const price = data.price;
    const coin = data.coin;

    currentSignal = { asset: coin, price: price, signal: signal, time: Date.now() };

    document.getElementById('signalType').textContent = signal.type === 'buy' ? 'خرید' : (signal.type === 'sell' ? 'فروش' : 'خنثی');
    document.getElementById('signalType').className = 'signal-type ' + signal.type;
    document.getElementById('resultIcon').textContent = coin.icon || '📊';
    document.getElementById('resultCoin').textContent = coin.name;
    document.getElementById('currentPrice').textContent = '$' + price.toFixed(2);
    document.getElementById('entryPrice').textContent = '$' + signal.entry.toFixed(2);
    document.getElementById('tpPrice').textContent = '$' + signal.tp.toFixed(2);
    document.getElementById('slPrice').textContent = '$' + signal.sl.toFixed(2);
    document.getElementById('confidenceFill').style.width = signal.confidence + '%';
    document.getElementById('confidencePercent').textContent = signal.confidence + '%';
    document.getElementById('analysisText').textContent = signal.analysis || 'تحلیل در حال بارگذاری...';

    const validityHours = Math.floor(Math.random() * 12 + 6);
    document.getElementById('validityTime').textContent = validityHours + ' ساعت';

    generateSparkline();
    document.getElementById('resultBox').classList.add('show');

    document.getElementById('saveBtn').classList.remove('saved');
    document.getElementById('saveBtn').innerHTML = '<i class="fas fa-bookmark"></i> ذخیره';

    addToHistory(coin, signal, price);
}

function generateSparkline() {
    const points = Array.from({ length: 20 }, () => Math.round(Math.random() * 35 + 8));
    const svg = document.getElementById('sparkline');
    if (!svg) return;
    const path = points.map((v, i) => i * 10.5 + ',' + (48 - v)).join(' L ');
    svg.innerHTML = `<polyline points="${path}" stroke="var(--gold)" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
}

// ===== تاریخچه =====
function addToHistory(coin, signal, price) {
    const entry = {
        coin: coin.name,
        symbol: coin.symbol,
        type: signal.type,
        entry: signal.entry,
        tp: signal.tp,
        sl: signal.sl,
        confidence: signal.confidence,
        time: Date.now()
    };
    signalHistory.unshift(entry);
    if (signalHistory.length > 50) signalHistory.pop();
    localStorage.setItem('pulset_signal_history', JSON.stringify(signalHistory));
    document.querySelector('.history-section').classList.add('show');
    showHistory();
}

function showHistory() {
    const list = document.getElementById('historyList');
    if (!signalHistory.length) {
        list.innerHTML = `<div style="padding:16px;text-align:center;color:var(--text3);font-size:13px;">${t('no_history')}</div>`;
        return;
    }
    list.innerHTML = signalHistory.slice(0, 8).map(h => {
        const icon = h.type === 'buy' ? '📈' : (h.type === 'sell' ? '📉' : '⚖️');
        const typeLabel = h.type === 'buy' ? 'خرید' : (h.type === 'sell' ? 'فروش' : 'خنثی');
        return `
            <div class="history-item">
                <div class="h-left">
                    <div class="h-icon ${h.type}">${icon}</div>
                    <span class="h-coin">${h.coin}</span>
                    <span class="h-type ${h.type}">${typeLabel}</span>
                </div>
                <span class="h-time">${new Date(h.time).toLocaleTimeString('fa-IR', {hour:'2-digit', minute:'2-digit'})}</span>
            </div>
        `;
    }).join('');
}

// ===== ذخیره و اشتراک =====
function saveSignal() {
    const btn = document.getElementById('saveBtn');
    if (!currentSignal) return;

    const saved = JSON.parse(localStorage.getItem('pulset_saved_signals') || '[]');
    const idx = saved.findIndex(s => s.asset.id === currentSignal.asset.id && s.time === currentSignal.time);

    if (idx > -1) {
        saved.splice(idx, 1);
        btn.classList.remove('saved');
        btn.innerHTML = '<i class="fas fa-bookmark"></i> ذخیره';
        showToast(t('unsaved'));
    } else {
        saved.push(currentSignal);
        btn.classList.add('saved');
        btn.innerHTML = '<i class="fas fa-bookmark"></i> <span data-i18n="saved">ذخیره شد</span>';
        showToast(t('saved'));
    }
    localStorage.setItem('pulset_saved_signals', JSON.stringify(saved));
}

function shareSignal() {
    if (!currentSignal) return;

    const text = `${currentSignal.asset.name} - ${currentSignal.signal.type === 'buy' ? 'خرید' : 'فروش'}\n` +
        `قیمت لحظه‌ای: $${currentSignal.price.toFixed(2)}\n` +
        `ورود: $${currentSignal.signal.entry.toFixed(2)}\n` +
        `حد سود: $${currentSignal.signal.tp.toFixed(2)}\n` +
        `حد ضرر: $${currentSignal.signal.sl.toFixed(2)}\n` +
        `اطمینان: ${currentSignal.signal.confidence}%\n` +
        `${currentSignal.signal.analysis}\n\n` +
        `دریافت شده از Pulset AI`;

    if (navigator.share) {
        navigator.share({ title: t('share_title'), text: text }).catch(() => {});
    } else {
        navigator.clipboard.writeText(text).then(() => {
            showToast(t('copy_link') + ' ✅');
        }).catch(() => {
            const ta = document.createElement('textarea');
            ta.value = text;
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
            showToast(t('copy_link') + ' ✅');
        });
    }
}

// ===== مقداردهی اولیه =====
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    const lang = getCurrentLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    applyPageTranslations();

    if (signalHistory.length > 0) {
        document.querySelector('.history-section').classList.add('show');
        showHistory();
    }

    // بستن نتایج جستجو با کلیک خارج
    document.addEventListener('click', function(e) {
        const wrapper = document.querySelector('.search-wrapper');
        if (wrapper && !wrapper.contains(e.target)) {
            document.getElementById('searchResults').classList.remove('show');
        }
    });

    console.log('✅ quick_signal.js loaded');
});

// ===== خروجی توابع =====
window.getSignal = getSignal;
window.filterCoins = filterCoins;
window.selectCoin = selectCoin;
window.clearSelection = clearSelection;
window.setCategory = setCategory;
window.saveSignal = saveSignal;
window.shareSignal = shareSignal;
window.showToast = showToast;
window.toggleDark = toggleDark;
window.toggleLang = toggleLang;
