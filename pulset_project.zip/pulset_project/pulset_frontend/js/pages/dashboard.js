// ================================================================
// dashboard.js - اسکریپت صفحه خانه
// ================================================================

// ===== ترجمه صفحه =====
const PAGE_TR = {
    fa: {
        home: 'خانه', exp: 'اکسپلور', mkt: 'بازارها', sig: 'سیگنال‌ها',
        vi: 'بازدید', sh: 'اشتراک‌گذاری', rp: 'بازنشر', cm: 'کامنت', lk: 'لایک', sv: 'ذخیره',
        emp: 'هیچ پستی یافت نشد', end: 'همه پست‌ها را دیدید', ld: 'در حال بارگذاری...',
        fol: 'دنبال‌کننده', folc: 'دنبال‌شونده', msg: 'پیام‌ها', not: 'اعلان‌ها',
        ai: 'چت با هوش مصنوعی', news: 'اخبار', bm: 'ذخیره‌ها', wal: 'کیف پول',
        set: 'تنظیمات', lo: 'خروج از حساب', prof: 'پروفایل',
        wcm: 'کامنت خود را بنویسید...', snd: 'ارسال',
        ri: 'بازنشر فوری', rq: 'نقل‌قول',
        report: 'گزارش', edit: 'ویرایش', del: 'حذف',
        reposted: '🔄 بازنشر شد',
        quoted: '📝 نقل‌قول منتشر شد',
        for_you: 'برای تو', following: 'دنبال‌کنندگان'
    },
    en: {
        home: 'Home', exp: 'Explore', mkt: 'Markets', sig: 'Signals',
        vi: 'Views', sh: 'Share', rp: 'Repost', cm: 'Comment', lk: 'Like', sv: 'Save',
        emp: 'No posts found', end: 'You\'ve seen all', ld: 'Loading...',
        fol: 'Followers', folc: 'Following', msg: 'Messages', not: 'Notifications',
        ai: 'AI Chat', news: 'News', bm: 'Bookmarks', wal: 'Wallet',
        set: 'Settings', lo: 'Logout', prof: 'Profile',
        wcm: 'Write your comment...', snd: 'Send',
        ri: 'Repost now', rq: 'Quote',
        report: 'Report', edit: 'Edit', del: 'Delete',
        reposted: '🔄 Reposted',
        quoted: '📝 Quote published',
        for_you: 'For You', following: 'Following'
    }
};

// ===== متغیرهای سراسری =====
let posts = [], page = 0, loading = false, hasMore = true, observer = null, tab = 'for-you', adCounter = 0;
let openDropdownId = null, currentCommentId = null, currentRepostId = null, quoteParentId = null;
let sharePostId = null, shareText = '', editPostId = null;
let createMediaList = [], createTags = [], editMediaList = [];
let cropperInstance = null, cropRealIndex = -1;
const CREATE_MAX_FILES = 5;

// ===== توابع کمکی =====
function getUser() {
    try {
        const s = JSON.parse(localStorage.getItem('pulset_profile') || '{}');
        return { name: s.displayName || 'علی معامله‌گر', avatar: s.avatar || '', followers: s.followers || '۱.۲K', following: s.following || '۳۲۰' };
    } catch (e) { return { name: 'کاربر', avatar: '', followers: '۰', following: '۰' }; }
}

function getInitials(name) {
    if (!name) return 'ع';
    const parts = name.trim().split(' ');
    if (parts.length >= 2) return parts[0][0] + parts[1][0];
    return name[0] || 'ع';
}

function getAvatarDisplay(avatar, name) {
    if (avatar && avatar.startsWith('data:image')) { return `<img src="${avatar}" alt="${name}">`; }
    return getInitials(name);
}

function fmtTime(ts) {
    const lang = getCurrentLang();
    const d = Math.floor((Date.now() - ts) / 1000);
    if (lang === 'en') {
        if (d < 60) return 'just now';
        if (d < 3600) return Math.floor(d / 60) + 'm ago';
        if (d < 86400) return Math.floor(d / 3600) + 'h ago';
        return new Date(ts).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }
    if (d < 60) return 'لحظاتی پیش';
    if (d < 3600) return Math.floor(d / 60) + ' دقیقه پیش';
    if (d < 86400) return Math.floor(d / 3600) + ' ساعت پیش';
    return new Date(ts).toLocaleDateString('fa-IR');
}

function applyPageTranslations() {
    const lang = getCurrentLang();
    const t = PAGE_TR[lang];
    if (!t) return;
    document.querySelectorAll('.tab').forEach(e => {
        const key = e.dataset.tab;
        if (key === 'for-you') e.textContent = t.for_you;
        else if (key === 'following') e.textContent = t.following;
    });
    document.querySelectorAll('.nav .l').forEach(e => { const k = e.dataset.key; if (k && t[k]) e.textContent = t[k]; });
    document.querySelectorAll('.drawer-mi').forEach(e => { const k = e.dataset.key; if (k && t[k]) e.textContent = t[k]; });
    const un = document.querySelector('.drawer-un');
    if (un) un.textContent = lang === 'fa' ? 'علی معامله‌گر' : 'Ali Trader';
    const inp = document.getElementById('commentInput');
    if (inp) inp.placeholder = t.wcm;
    const btn = document.querySelector('.comment-in button');
    if (btn) btn.textContent = t.snd;
    document.querySelectorAll('.repost-o .opt').forEach(e => {
        const txt = e.textContent.trim();
        e.textContent = txt.includes('فوری') || txt.includes('now') ? t.ri : t.rq;
    });
    document.querySelectorAll('.sheet-title').forEach((el, i) => {
        const titles = ['کامنت‌ها', 'بازنشر', 'نقل‌قول', 'گزارش پست'];
        const enTitles = ['Comments', 'Repost', 'Quote', 'Report Post'];
        el.textContent = lang === 'fa' ? titles[i] : (enTitles[i] || '');
    });
}
window.applyPageTranslations = applyPageTranslations;

// ===== توابع اصلی =====
function getSamplePosts(tab) {
    const now = Date.now();
    if (tab === 'for-you') {
        return [
            { id: 1, user: 'علی معامله‌گر', username: '@ali_trades', avatar: 'ع', verified: true, time: now - 180000, text: 'بیت‌کوین در تایم ۴ ساعته به مقاومت ۶۸ هزار دلار رسیده...', media: [], likes: 28, comments: 12, reposts: 4, views: 245, liked: false, saved: false, reposted: false, owner: true },
            { id: 2, user: 'مریم تریدر', username: '@mary_crypto', avatar: 'م', verified: false, time: now - 720000, text: 'این چارت سولانا رو نگاه کنید...', media: [], likes: 15, comments: 8, reposts: 2, views: 180, liked: false, saved: false, reposted: false, owner: false }
        ];
    } else {
        return [{ id: 4, user: 'نیما تحلیل‌گر', username: '@nima_charts', avatar: 'ن', verified: true, time: now - 600000, text: 'تحلیل هفتگی: بازار رمزارزها در فاز تجمیع قرار دارد.', media: [], likes: 45, comments: 22, reposts: 11, views: 580, liked: false, saved: false, reposted: false, owner: false }];
    }
}

async function fetchPosts(tab, pageNum) {
    try {
        const data = await API.Posts.get(tab, pageNum, 5);
        return data.posts || data || [];
    } catch (e) {
        console.warn('Fetch posts error, using fallback:', e);
        return getSamplePosts(tab);
    }
}

function createAd() { const posId = (adCounter % 2 === 0) ? 'pos-article-display-card-120295' : 'pos-article-display-card-120298'; adCounter++; return '<div class="sponsor-block"><div class="sponsor-label">تبلیغات</div><div class="sponsor-container"><div id="' + posId + '"></div></div></div>'; }

function renderCarousel(media) {
    if (!media || media.length === 0) return '';
    let itemsHtml = media.map((item, idx) => {
        let overlay = '';
        if (idx === 3 && media.length > 4) overlay = `<div class="g-overlay">+${media.length - 3}</div>`;
        let content = '';
        if (item.type === 'video') {
            content = `
                <div class="video-wrapper">
                    <div class="video-loader" id="vloader-${Date.now()}-${idx}">
                        <div class="spinner"></div>
                        <span class="label">در حال بارگذاری ویدیو...</span>
                    </div>
                    <video src="${item.url}" preload="metadata" playsinline></video>
                    <button class="play-btn" onclick="togglePlay(this)">
                        <span class="icon">▶</span>
                    </button>
                </div>
            `;
        } else {
            content = `<img src="${item.url}" alt="تصویر ${idx+1}" loading="lazy" />`;
        }
        return `<div class="carousel-item">${overlay}${content}</div>`;
    }).join('');
    let dotsHtml = media.map((_, idx) => `<div class="carousel-dot" data-index="${idx}"></div>`).join('');
    return `<div class="post-carousel"><div class="carousel-track">${itemsHtml}</div><div class="carousel-indicators">${dotsHtml}</div><div class="carousel-counter"><span class="current">1</span><span>/</span><span class="total">${Math.min(media.length,4)}</span></div></div>`;
}

function createPostHTML(p) {
    const v = p.verified ? '<span class="v">✓</span>' : '';
    const time = fmtTime(p.time);
    const isLiked = p.liked ? 'liked' : '';
    const isSaved = p.saved ? 'saved' : '';
    const isReposted = p.reposted ? 'reposted' : '';
    let avatarContent = (p.avatar && p.avatar.startsWith('data:image')) ?
        `<img src="${p.avatar}" alt="${p.user}">` : (p.avatar || getInitials(p.user));
    let pollHtml = '';
    if (p.poll) {
        const total = p.poll.votes.reduce((a, b) => a + b, 0) || 1;
        const pcts = p.poll.votes.map(v => Math.round(v / total * 100));
        const opts = p.poll.options.map((opt, idx) => {
            const selected = p.poll.userVote === idx ? 'selected' : '';
            return '<button class="poll-opt ' + selected + '" onclick="votePoll(' + p.id + ',' + idx + ')">' + opt +
                '<span class="pct">' + (pcts[idx] || 0) + '%</span></button>';
        }).join('');
        pollHtml = '<div class="poll-container"><div class="poll-title">' + p.poll.question +
            '</div><div class="poll-options">' + opts +
            '</div><div class="poll-bar"><div class="fill bull" style="width:' + (pcts[0] || 0) +
            '%"></div><div class="fill bear" style="width:' + (pcts[1] || 0) +
            '%"></div></div><div class="poll-stats"><span>' + total +
            ' رای</span><span>' + (p.poll.userVote !== null ? 'رای شما ثبت شد' : 'نظر خود را ثبت کنید') +
            '</span></div></div>';
    }
    const dropdownId = 'dropdown-' + p.id;
    let menuItems = '';
    if (p.owner) {
        menuItems =
            `<button class="dropdown-item" onclick="event.stopPropagation(); openEditSheet(${p.id}); closeDropdown(${p.id})"><svg viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>${t('edit')}</button><button class="dropdown-item" onclick="event.stopPropagation(); deletePost(${p.id}); closeDropdown(${p.id})"><svg viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>${t('del')}</button>`;
    } else {
        menuItems =
            `<button class="dropdown-item" onclick="event.stopPropagation(); openReportSheet(${p.id}); closeDropdown(${p.id})"><svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M12 8v4"/><path d="M12 16h.01"/></svg>${t('report')}</button>`;
    }
    const moreMenu =
        '<div class="post-right"><span class="post-t">' + time +
        '</span><button class="post-more-btn" onclick="event.stopPropagation(); toggleDropdown(' + p.id +
        ')" aria-label="بیشتر"><svg viewBox="0 0 24 24"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg></button><div class="dropdown-menu" id="' +
        dropdownId + '">' + menuItems + '</div></div>';

    let bodyHtml = '';
    if (p.type === 'repost') {
        const imgHtml = p.repost_parent_image ?
            `<img class="rp-img" src="${p.repost_parent_image}" alt="تصویر اصلی" loading="lazy" />` : '';
        bodyHtml =
            `<div class="repost-container" data-parent-id="${p.repost_parent_id}" onclick="goToParentPost(${p.repost_parent_id})"><div class="rp-header"><svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg> ${p.user} این پست را بازنشر کرد</div><div class="rp-user"><div class="rp-av">${p.repost_parent_avatar || 'ع'}</div><div class="rp-n">${p.repost_parent_user || 'کاربر'} ${p.repost_parent_verified?'<span class="v">✓</span>':''} <span class="rp-u">${p.repost_parent_username || ''}</span></div></div><div class="rp-text">${p.repost_parent_text || ''}</div>${imgHtml}</div>`;
    } else if (p.type === 'quote') {
        const imgHtml = p.quoted_parent_image ?
            `<img class="qt-img" src="${p.quoted_parent_image}" alt="تصویر اصلی" loading="lazy" />` : '';
        bodyHtml =
            `<div class="post-txt">${p.text}</div><div class="quote-container" data-parent-id="${p.quoted_parent_id}" onclick="goToParentPost(${p.quoted_parent_id})"><div class="qt-header"><svg viewBox="0 0 24 24"><path d="M3 10h4v4H3z"/><path d="M17 10h4v4h-4z"/><line x1="7" y1="12" x2="17" y2="12"/></svg> نقل‌قول از ${p.quoted_parent_user || 'کاربر'}</div><div class="qt-user"><div class="qt-av">${p.quoted_parent_avatar || 'ع'}</div><div class="qt-n">${p.quoted_parent_user || 'کاربر'} ${p.quoted_parent_verified?'<span class="v">✓</span>':''} <span class="qt-u">${p.quoted_parent_username || ''}</span></div></div><div class="qt-text">${p.quoted_parent_text || ''}</div>${imgHtml}</div>`;
    } else {
        bodyHtml = `<div class="post-txt">${p.text}</div>${renderCarousel(p.media)}${pollHtml}`;
    }
    return '<div class="post" data-id="' + p.id + '"><div class="post-h"><div class="post-a">' + avatarContent +
        '</div><div class="post-ui" onclick="window.location.href=\'profile.html\'"><div class="post-un">' + p.user +
        ' ' + v + '</div><div class="post-usr">' + p.username +
        '</div></div>' + moreMenu +
        '</div>' + bodyHtml +
        '<div class="post-a2"><button class="btn like ' + isLiked + '" onclick="toggleLike(' + p.id +
        ')"><svg class="i" viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg><span>' +
        p.likes +
        '</span></button><button class="btn" onclick="openComments(' + p.id +
        ')"><svg class="i" viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg><span>' +
        p.comments +
        '</span></button><button class="btn repost-btn ' + isReposted + '" onclick="openRepost(' + p.id +
        ')"><svg class="i" viewBox="0 0 24 24"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg><span>' +
        p.reposts +
        '</span></button><button class="btn bookmark ' + isSaved + '" onclick="toggleBookmark(' + p.id +
        ')"><svg class="i" viewBox="0 0 24 24"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg></button><button class="btn share-btn" onclick="openShareModal(' +
        p.id +
        ')"><svg class="i" viewBox="0 0 24 24"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg></button><span class="views">' +
        t('vi') + ' ' + p.views + '</span></div></div>';
}

function goToParentPost(parentId) {
    const parent = posts.find(p => p.id === parentId);
    if (parent) {
        const el = document.querySelector(`.post[data-id="${parentId}"]`);
        if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            el.style.transition = 'background 0.3s';
            el.style.background = 'var(--gold-bg)';
            setTimeout(() => { el.style.background = ''; }, 1500);
        } else {
            window.location.href = `post_detail.html?id=${parentId}`;
        }
    } else {
        showToast('پست اصلی یافت نشد');
    }
}

function renderPosts() {
    const container = document.getElementById('feedPosts');
    if (!container) return;
    container.innerHTML = '';
    const items = posts.slice(0, page * 5 + 5);
    if (!items.length) {
        container.innerHTML =
            '<div style="text-align:center;padding:60px 20px;color:var(--text3);">' + t('emp') + '</div>';
        return;
    }
    items.forEach((p, i) => {
        container.insertAdjacentHTML('beforeend', createPostHTML(p));
        if ((i + 1) % 4 === 0 && (i + 1) < items.length) container.insertAdjacentHTML('beforeend',
        createAd());
    });
    hasMore = items.length < posts.length;
    const endMsg = document.getElementById('endMessage');
    if (endMsg) {
        if (!hasMore) endMsg.classList.add('show');
        else endMsg.classList.remove('show');
    }
    setTimeout(initVideoPlayers, 300);
    setupObserver();
}

function initVideoPlayers() {
    document.querySelectorAll('.video-wrapper').forEach(wrapper => {
        const video = wrapper.querySelector('video');
        const loader = wrapper.querySelector('.video-loader');
        const playBtn = wrapper.querySelector('.play-btn');
        if (!video || !loader) return;
        video.addEventListener('canplay', () => { loader.classList.add('hidden'); });
        video.addEventListener('canplaythrough', () => { loader.classList.add('hidden'); });
        video.addEventListener('loadeddata', () => { loader.classList.add('hidden'); });
        if (video.readyState >= 3) { loader.classList.add('hidden'); }
        video.addEventListener('error', () => {
            loader.innerHTML = '<span style="color:#fff;font-size:13px;">⚠️ خطا در پخش ویدیو</span>';
            loader.classList.remove('hidden');
        });
        if (playBtn) {
            playBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                if (video.paused) {
                    video.play();
                    this.querySelector('.icon').textContent = '⏸';
                } else {
                    video.pause();
                    this.querySelector('.icon').textContent = '▶';
                }
            });
            video.addEventListener('play', () => {
                playBtn.querySelector('.icon').textContent = '⏸';
            });
            video.addEventListener('pause', () => {
                playBtn.querySelector('.icon').textContent = '▶';
            });
            video.addEventListener('ended', () => {
                playBtn.querySelector('.icon').textContent = '▶';
            });
        }
    });
}

function togglePlay(btn) {
    // توسط listener خود دکمه مدیریت می‌شود
}

async function initPosts() {
    page = 0;
    const data = await fetchPosts(tab, 0);
    if (data && data.length) {
        posts = data.map(p => ({ ...p, liked: false, saved: false, reposted: false }));
    } else {
        posts = getSamplePosts(tab).map(p => ({ ...p, liked: false, saved: false, reposted: false }));
    }
    renderPosts();
}

async function loadMore() {
    if (loading || !hasMore) return;
    loading = true;
    const l = document.getElementById('loaderContainer');
    if (l) l.classList.add('show');
    try {
        const d = await fetchPosts(tab, page + 1);
        let n = [];
        if (d && d.length) n = d.map(p => ({ ...p, liked: false, saved: false, reposted: false }));
        if (!n.length) {
            hasMore = false;
            if (l) l.classList.remove('show');
            const e = document.getElementById('endMessage');
            if (e) e.classList.add('show');
            loading = false;
            return;
        }
        const start = posts.length;
        posts = [...posts, ...n];
        page++;
        const c = document.getElementById('feedPosts');
        n.forEach((p, i) => {
            c.insertAdjacentHTML('beforeend', createPostHTML(p));
            if ((start + i + 1) % 4 === 0 && (start + i + 1) < posts.length) c.insertAdjacentHTML('beforeend',
                createAd());
        });
        if (l) l.classList.remove('show');
        loading = false;
        hasMore = posts.length < page * 5 + 5;
        if (!hasMore) {
            const e = document.getElementById('endMessage');
            if (e) e.classList.add('show');
        }
        setTimeout(initVideoPlayers, 300);
    } catch (e) {
        console.error('loadMore error:', e);
        loading = false;
        if (l) l.classList.remove('show');
    }
}

function setupObserver() {
    if (observer) observer.disconnect();
    const l = document.getElementById('loaderContainer');
    observer = new IntersectionObserver(e => {
        if (e[0].isIntersecting && !loading && hasMore) loadMore();
    }, { threshold: .1 });
    if (l) observer.observe(l);
}

// ===== Interactions =====
async function toggleLike(id) {
    const p = posts.find(x => x.id === id);
    if (!p) return;
    try {
        const data = await API.Posts.like(id);
        p.liked = data.liked;
        p.likes = data.likes;
    } catch (e) {
        p.liked = !p.liked;
        p.likes += p.liked ? 1 : -1;
    }
    renderPosts();
}

async function toggleBookmark(id) {
    const p = posts.find(x => x.id === id);
    if (!p) return;
    try {
        const data = await API.Posts.bookmark(id);
        p.saved = data.saved;
    } catch (e) {
        p.saved = !p.saved;
    }
    renderPosts();
}

function votePoll(postId, optionIndex) {
    const p = posts.find(x => x.id === postId);
    if (!p || !p.poll || p.poll.userVote !== null) return;
    p.poll.userVote = optionIndex;
    p.poll.votes[optionIndex] += 1;
    renderPosts();
}

async function deletePost(id) {
    if (!confirm('آیا از حذف این پست اطمینان دارید؟')) return;
    try {
        await API.Posts.delete(id);
        posts = posts.filter(x => x.id !== id);
        renderPosts();
        showToast('پست حذف شد');
    } catch (e) {
        showToast('خطا در حذف پست');
    }
}

// ===== Comments =====
function openComments(id) {
    currentCommentId = id;
    document.getElementById('commentOverlay').classList.add('open');
    loadComments(id);
}

function closeCommentSheet() {
    document.getElementById('commentOverlay').classList.remove('open');
    currentCommentId = null;
}

async function loadComments(id) {
    const list = document.getElementById('commentsList');
    list.innerHTML = '<div style="text-align:center;padding:20px;color:var(--text3);">در حال بارگذاری...</div>';
    try {
        const data = await API.Posts.getComments(id);
        if (data && data.length) {
            list.innerHTML = data.map(c =>
                `<div class="comment"><div class="comment-a">${c.avatar||'ع'}</div><div class="comment-c"><div class="comment-n">${c.user||'کاربر'}</div><div class="comment-t">${c.text}</div></div></div>`
            ).join('');
        } else {
            list.innerHTML =
            '<div style="text-align:center;padding:20px;color:var(--text3);">هیچ کامنتی وجود ندارد.</div>';
        }
    } catch (e) {
        list.innerHTML =
            '<div style="text-align:center;padding:20px;color:var(--text3);">هیچ کامنتی وجود ندارد.</div>';
    }
}

async function addComment() {
    const inp = document.getElementById('commentInput');
    const txt = inp.value.trim();
    if (!txt) { showToast('لطفاً متن کامنت را وارد کنید.'); return; }
    if (!currentCommentId) { showToast('خطا: شناسه کامنت معتبر نیست.'); return; }
    try {
        await API.Posts.addComment(currentCommentId, txt);
        inp.value = '';
        loadComments(currentCommentId);
        const p = posts.find(x => x.id === currentCommentId);
        if (p) { p.comments = (p.comments || 0) + 1;
            renderPosts(); }
    } catch (e) {
        inp.value = '';
        loadComments(currentCommentId);
        const p = posts.find(x => x.id === currentCommentId);
        if (p) { p.comments = (p.comments || 0) + 1;
            renderPosts(); }
        showToast('✅ کامنت ارسال شد (آفلاین).');
    }
}

// ===== Repost =====
function openRepost(id) {
    currentRepostId = id;
    document.getElementById('repostOverlay').classList.add('open');
}

function closeRepostSheet() {
    document.getElementById('repostOverlay').classList.remove('open');
    currentRepostId = null;
}

function doRepost(type) {
    if (!currentRepostId) return;
    const original = posts.find(x => x.id === currentRepostId);
    if (!original) { showToast('پست اصلی یافت نشد.');
        closeRepostSheet(); return; }
    if (type === 'quote') {
        openQuoteSheet(currentRepostId);
        closeRepostSheet();
        return;
    }
    const user = getUser();
    const newPost = {
        id: Date.now(),
        user: user.name || 'شما',
        username: '@' + (user.name || 'user').replace(/\s/g, ''),
        avatar: user.avatar || getInitials(user.name),
        verified: true,
        time: Date.now(),
        text: '',
        media: [],
        likes: 0, comments: 0, reposts: 0, views: 0,
        liked: false, saved: false, reposted: false,
        owner: true,
        type: 'repost',
        repost_parent_id: original.id,
        repost_parent_user: original.user,
        repost_parent_text: original.text || '',
        repost_parent_avatar: original.avatar,
        repost_parent_image: (original.media && original.media.length > 0 && original.media[0].type === 'image') ?
            original.media[0].url : null,
        repost_parent_verified: original.verified || false,
        repost_parent_username: original.username || ''
    };
    posts.unshift(newPost);
    renderPosts();
    closeRepostSheet();
    showToast(t('reposted'));
    API.Posts.repost(currentRepostId, 'instant').catch(() => {});
}

// ===== Quote =====
function openQuoteSheet(id) {
    quoteParentId = id;
    const p = posts.find(x => x.id === id);
    if (!p) { showToast('پست اصلی یافت نشد.'); return; }
    document.getElementById('quoteOverlay').classList.add('open');
    document.getElementById('quoteContent').value = '';
    const display = document.getElementById('quoteOriginalDisplay');
    let imgHtml = '';
    if (p.media && p.media.length > 0 && p.media[0].type === 'image') {
        imgHtml = `<img class="q-img" src="${p.media[0].url}" alt="تصویر" />`;
    }
    display.innerHTML = `
        <div class="q-header">
            <div class="q-avatar">${p.avatar || getInitials(p.user)}</div>
            <span>${p.user} ${p.verified ? '✓' : ''}</span>
        </div>
        <div class="q-text">${p.text || ''}</div>
        ${imgHtml}
    `;
    document.getElementById('quoteContent').focus();
}

function closeQuoteSheet() {
    document.getElementById('quoteOverlay').classList.remove('open');
    quoteParentId = null;
}

function publishQuote() {
    const text = document.getElementById('quoteContent').value.trim();
    if (!text) { showToast('متن نقل‌قول را بنویسید.'); return; }
    const original = posts.find(x => x.id === quoteParentId);
    if (!original) { showToast('پست اصلی یافت نشد.'); return; }
    const user = getUser();
    const newPost = {
        id: Date.now(),
        user: user.name || 'شما',
        username: '@' + (user.name || 'user').replace(/\s/g, ''),
        avatar: user.avatar || getInitials(user.name),
        verified: true,
        time: Date.now(),
        text: text,
        media: [],
        likes: 0, comments: 0, reposts: 0, views: 0,
        liked: false, saved: false, reposted: false,
        owner: true,
        type: 'quote',
        quoted_parent_id: original.id,
        quoted_parent_user: original.user,
        quoted_parent_text: original.text || '',
        quoted_parent_avatar: original.avatar,
        quoted_parent_image: (original.media && original.media.length > 0 && original.media[0].type === 'image') ?
            original.media[0].url : null,
        quoted_parent_verified: original.verified || false,
        quoted_parent_username: original.username || ''
    };
    posts.unshift(newPost);
    renderPosts();
    closeQuoteSheet();
    showToast(t('quoted'));
    API.Posts.quote(original.id, text).catch(() => {});
}

// ===== Report =====
function openReportSheet(id) {
    reportPostId = id;
    document.getElementById('reportOverlay').classList.add('open', 'show-report');
}

function closeReportSheet() {
    document.getElementById('reportOverlay').classList.remove('open', 'show-report');
    reportPostId = null;
}

async function submitReport(reason) {
    if (!reportPostId) return;
    try {
        await API.Posts.report(reportPostId, reason);
        showToast('✅ گزارش شما ثبت شد.');
    } catch (e) { showToast('✅ گزارش شما ثبت شد.'); }
    closeReportSheet();
}

// ===== Share =====
function openShareModal(id) {
    const p = posts.find(x => x.id === id);
    if (!p) return;
    sharePostId = id;
    shareText = p.text.substring(0, 100) + '...';
    document.getElementById('shareModal').classList.add('show');
}

function closeShareModal() {
    document.getElementById('shareModal').classList.remove('show');
    sharePostId = null;
}

function copyLink() {
    const url = window.location.href + '?post=' + sharePostId;
    navigator.clipboard.writeText(url).then(() => { showToast('✅ لینک کپی شد!');
        closeShareModal(); }).catch(() => {
        const ta = document.createElement('textarea');
        ta.value = url;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        showToast('✅ لینک کپی شد!');
        closeShareModal();
    });
}

function shareNative() {
    if (navigator.share) {
        navigator.share({ title: 'Pulset', text: shareText, url: window.location.href + '?post=' + sharePostId }).catch(
            () => {}).finally(closeShareModal);
    } else { copyLink(); }
}

// ===== Dropdown =====
function toggleDropdown(id) {
    const el = document.getElementById('dropdown-' + id);
    if (!el) return;
    if (openDropdownId === id) {
        el.classList.remove('show');
        openDropdownId = null;
    } else {
        if (openDropdownId) {
            const p = document.getElementById('dropdown-' + openDropdownId);
            if (p) p.classList.remove('show');
        }
        el.classList.add('show');
        openDropdownId = id;
    }
}

document.addEventListener('click', function(e) {
    if (!e.target.closest('.post-right') && openDropdownId) {
        const el = document.getElementById('dropdown-' + openDropdownId);
        if (el) el.classList.remove('show');
        openDropdownId = null;
    }
});

// ===== Switch Tab =====
function switchTab(tab, btn) {
    tab = tab;
    document.querySelectorAll('.tab').forEach(e => e.classList.remove('active'));
    if (btn) btn.classList.add('active');
    page = 0;
    hasMore = true;
    adCounter = 0;
    posts = [];
    const c = document.getElementById('feedPosts');
    if (c) c.innerHTML = '';
    const e = document.getElementById('endMessage');
    if (e) e.classList.remove('show');
    initPosts();
}

// ===== Drawer =====
function toggleDrawer() {
    const o = document.getElementById('drawerOverlay');
    o.classList.toggle('open');
    document.body.style.overflow = o.classList.contains('open') ? 'hidden' : '';
    const u = getUser();
    const av = document.getElementById('drawerAvatar');
    if (u.avatar && u.avatar.startsWith('data:image')) {
        av.innerHTML = `<img src="${u.avatar}" alt="${u.name}">`;
    } else {
        av.textContent = getInitials(u.name);
    }
    const un = document.querySelector('.drawer-un');
    if (un) un.textContent = u.name;
    document.getElementById('drawerFollowers').textContent = u.followers + ' ' + t('fol');
    document.getElementById('drawerFollowing').textContent = u.following + ' ' + t('folc');
}

function closeDrawer() {
    document.getElementById('drawerOverlay').classList.remove('open');
    document.body.style.overflow = '';
}

// ===== Bottom Nav =====
const navs = document.querySelectorAll('.nav'),
    center = document.getElementById('centerBtn');

function goTo(p) {
    const map = { dashboard: 'dashboard.html', signals_feed: 'signals_feed.html', markets: 'markets.html',
        explore: 'explore.html', signal: 'signal-request.html' };
    const url = map[p];
    if (url) window.location.href = url;
}
navs.forEach(n => {
    n.addEventListener('click', function(e) {
        e.preventDefault();
        const p = this.dataset.page;
        if (!p) return;
        navs.forEach(x => x.classList.remove('active'));
        this.classList.add('active');
        center.classList.remove('active');
        if (p === 'signal') center.classList.add('active');
        goTo(p);
    });
});
if (center) {
    center.addEventListener('click', function(e) {
        e.preventDefault();
        navs.forEach(x => x.classList.remove('active'));
        this.classList.add('active');
        goTo('signal');
    });
}

// ===== FAB =====
const fab = document.getElementById('fabPlus'),
    feedC = document.getElementById('feedContainer');
let lastY = 0;
if (fab && feedC) {
    feedC.addEventListener('scroll', function() {
        const c = this.scrollTop;
        if (c > lastY && c > 80) fab.classList.add('hidden');
        else fab.classList.remove('hidden');
        lastY = c;
    });
}

// ===== Create Post =====
function loadCreateProfile() {
    const p = JSON.parse(localStorage.getItem('pulset_profile') || '{"displayName":"علی معامله‌گر","username":"@ali_trades","avatar":""}');
    const avatarEl = document.getElementById('createUserAvatar');
    if (p.avatar && p.avatar.startsWith('data:image')) {
        avatarEl.innerHTML = `<img src="${p.avatar}" alt="${p.displayName}">`;
    } else {
        avatarEl.textContent = getInitials(p.displayName);
    }
    document.getElementById('createUserName').textContent = p.displayName || 'علی معامله‌گر';
    document.getElementById('createUserHandle').textContent = p.username || '@ali_trades';
}

function updateCreateCharCount() {
    document.getElementById('createCharCount').textContent = document.getElementById('createPostContent').value.length;
}

function previewCreateMedia(e, type) {
    const files = Array.from(e.target.files);
    if (type === 'video') {
        if (files[0].size > 50 * 1024 * 1024) { showToast('حجم ویدیو نباید بیشتر از ۵۰ مگابایت باشد.');
            e.target.value = ''; return; }
        const reader = new FileReader();
        reader.onload = function(ev) { createMediaList.push({ type: 'video', url: ev.target.result, file: files[0] });
            renderCreateGallery();
            saveCreateDraft(); };
        reader.readAsDataURL(files[0]);
        e.target.value = '';
        return;
    }
    const remaining = CREATE_MAX_FILES - createMediaList.filter(m => m.type === 'image').length;
    if (files.length > remaining) { showToast('حداکثر ' + CREATE_MAX_FILES + ' فایل مجاز است.');
        e.target.value = ''; return; }
    let processed = 0;
    files.forEach(file => {
        if (file.size > 5 * 1024 * 1024) { showToast('حجم تصویر بیشتر از ۵ مگابایت است.'); return; }
        const reader = new FileReader();
        reader.onload = function(ev) { createMediaList.push({ type: 'image', url: ev.target.result,
                file: file });
            processed++;
            if (processed === files.length) { renderCreateGallery();
                saveCreateDraft(); } };
        reader.readAsDataURL(file);
    });
    e.target.value = '';
}

function renderCreateGallery() {
    const container = document.getElementById('createGalleryPreview');
    if (createMediaList.length === 0) { container.innerHTML = '';
        document.getElementById('createMediaCounter').textContent = '۰ فایل'; return; }
    container.innerHTML = createMediaList.map((item, idx) =>
        `<div class="gallery-item">${item.type==='video'?`<video src="${item.url}" preload="metadata" muted></video>`:`<img src="${item.url}" alt="تصویر ${idx+1}">`}<button class="remove-img" onclick="removeCreateMedia(${idx})"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><span class="order-badge">${idx+1}</span><div class="edit-overlay">${item.type==='image'?`<button onclick="openCropModal(${idx})" title="ویرایش عکس"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="var(--text)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path></svg></button>`:`<button disabled style="background:rgba(255,255,255,0.5);color:#999;cursor:not-allowed;box-shadow:none;"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#999" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path></svg></button>`}<button onclick="replaceCreateMedia(${idx})" title="تعویض فایل"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="var(--text)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg></button></div></div>`
    ).join('');
    document.getElementById('createMediaCounter').textContent = createMediaList.length + ' فایل';
}

function removeCreateMedia(idx) { createMediaList.splice(idx, 1);
    renderCreateGallery();
    saveCreateDraft(); }

function replaceCreateMedia(idx) {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = createMediaList[idx].type === 'image' ? 'image/*' : 'video/*';
    input.onchange = function(e) {
        const file = e.target.files[0];
        if (!file) return;
        if (createMediaList[idx].type === 'video' && file.size > 50 * 1024 * 1024) { showToast('حجم ویدیو نباید بیشتر از ۵۰ مگابایت باشد.'); return; }
        const reader = new FileReader();
        reader.onload = function(ev) { createMediaList[idx].url = ev.target.result;
            createMediaList[idx].file = file;
            renderCreateGallery();
            saveCreateDraft(); };
        reader.readAsDataURL(file);
    };
    input.click();
}

function addCreateTag(e) {
    if (e.key === 'Enter') { e.preventDefault();
        addCreateTagFromInput(); }
}

function addCreateTagOnBlur() { addCreateTagFromInput(); }

function addCreateTagFromInput() {
    const input = document.getElementById('createTagInput');
    const val = input.value.trim();
    if (val) {
        const parts = val.split(',').map(s => s.trim()).filter(s => s);
        parts.forEach(p => { if (p && !createTags.includes(p)) createTags.push(p); });
        input.value = '';
        renderCreateTags();
        saveCreateDraft();
    }
}

function renderCreateTags() {
    const container = document.getElementById('createTagList');
    container.innerHTML = createTags.map(t =>
        `<span class="tag-item">${t} <button class="remove-tag" onclick="removeCreateTag('${t}')"><i class="fas fa-times"></i></button></span>`
        ).join('');
}

function removeCreateTag(tag) { createTags = createTags.filter(t => t !== tag);
    renderCreateTags();
    saveCreateDraft(); }

function saveCreateDraft() {
    const data = {
        content: document.getElementById('createPostContent').value,
        media: createMediaList,
        privacy: document.getElementById('createPrivacySelect').value,
        type: document.getElementById('createTypeSelect').value,
        tags: createTags
    };
    localStorage.setItem('pulset_post_draft', JSON.stringify(data));
    document.getElementById('createDraftIndicator').classList.add('show');
}

function loadCreateDraft() {
    try {
        const raw = localStorage.getItem('pulset_post_draft');
        if (raw) {
            const data = JSON.parse(raw);
            if (data.content) { document.getElementById('createPostContent').value = data.content;
                updateCreateCharCount();
                document.getElementById('createDraftIndicator').classList.add('show'); }
            if (data.media && data.media.length) { createMediaList = data.media;
                renderCreateGallery(); }
            if (data.privacy) document.getElementById('createPrivacySelect').value = data.privacy;
            if (data.type) document.getElementById('createTypeSelect').value = data.type;
            if (data.tags) { createTags = data.tags;
                renderCreateTags(); }
            showToast('پیش‌نویس بازیابی شد.');
        }
    } catch (e) {}
}

function clearCreateDraft() {
    localStorage.removeItem('pulset_post_draft');
    document.getElementById('createDraftIndicator').classList.remove('show');
    document.getElementById('createPostContent').value = '';
    createMediaList = [];
    renderCreateGallery();
    document.getElementById('createPrivacySelect').value = 'public';
    document.getElementById('createTypeSelect').value = 'post';
    createTags = [];
    renderCreateTags();
    showToast('پیش‌نویس پاک شد');
}

function openCreatePostSheet() {
    document.getElementById('createPostOverlay').classList.add('open');
    setTimeout(() => { loadCreateProfile();
        loadCreateDraft(); }, 100);
}

function closeCreatePostSheet() {
    document.getElementById('createPostOverlay').classList.remove('open');
}

async function publishPostFromSheet() {
    const content = document.getElementById('createPostContent').value.trim();
    const btn = document.getElementById('createPublishBtn');
    const overlay = document.getElementById('createLoadingOverlay');
    if (!content && createMediaList.length === 0) {
        showToast('لطفاً متن یا حداقل یک عکس/فیلم وارد کنید.');
        return;
    }
    btn.disabled = true;
    overlay.classList.add('show');
    const data = {
        content: content || '',
        privacy: document.getElementById('createPrivacySelect').value,
        type: document.getElementById('createTypeSelect').value,
        tags: createTags,
        media: createMediaList
    };
    try {
        const newPost = await API.Posts.create(data);
        const post = {
            id: newPost.id || Date.now(),
            user: document.getElementById('createUserName').textContent,
            username: document.getElementById('createUserHandle').textContent,
            avatar: document.querySelector('#createUserAvatar img')?.src || getInitials(document.getElementById(
                'createUserName').textContent),
            verified: true,
            time: Date.now(),
            text: data.content,
            media: data.media || [],
            likes: 0, comments: 0, reposts: 0, views: 0,
            liked: false, saved: false, reposted: false,
            owner: true,
            type: data.type || 'post',
            privacy: data.privacy || 'public',
            tags: data.tags || []
        };
        posts.unshift(post);
        renderPosts();
        overlay.classList.remove('show');
        btn.disabled = false;
        clearCreateDraft();
        closeCreatePostSheet();
        showToast('✅ پست با موفقیت منتشر شد!');
    } catch (e) {
        const post = {
            id: Date.now(),
            user: document.getElementById('createUserName').textContent,
            username: document.getElementById('createUserHandle').textContent,
            avatar: document.querySelector('#createUserAvatar img')?.src || getInitials(document.getElementById(
                'createUserName').textContent),
            verified: true,
            time: Date.now(),
            text: data.content,
            media: data.media || [],
            likes: 0, comments: 0, reposts: 0, views: 0,
            liked: false, saved: false, reposted: false,
            owner: true,
            type: data.type || 'post',
            privacy: data.privacy || 'public',
            tags: data.tags || []
        };
        posts.unshift(post);
        renderPosts();
        overlay.classList.remove('show');
        btn.disabled = false;
        clearCreateDraft();
        closeCreatePostSheet();
        showToast('✅ پست با موفقیت منتشر شد!');
    }
}

// ===== Crop =====
function openCropModal(index) {
    const images = createMediaList.filter(item => item.type === 'image');
    const targetUrl = images[index].url;
    const realIndex = createMediaList.findIndex(item => item.url === targetUrl);
    if (realIndex === -1) return;
    cropRealIndex = realIndex;
    const img = document.getElementById('cropImagePreview');
    img.src = createMediaList[realIndex].url;
    if (cropperInstance) cropperInstance.destroy();
    cropperInstance = new Cropper(img, { aspectRatio: NaN, viewMode: 1, autoCropArea: 0.8, background: false });
    document.getElementById('cropModalOverlay').classList.add('open');
}

function resetCrop() { if (cropperInstance) cropperInstance.reset(); }

function closeCropModal() {
    document.getElementById('cropModalOverlay').classList.remove('open');
    if (cropperInstance) { cropperInstance.destroy();
        cropperInstance = null; }
    cropRealIndex = -1;
}

function applyCrop() {
    if (!cropperInstance || cropRealIndex === -1) return;
    const canvas = cropperInstance.getCroppedCanvas();
    const croppedDataUrl = canvas.toDataURL('image/jpeg');
    createMediaList[cropRealIndex].url = croppedDataUrl;
    closeCropModal();
    renderCreateGallery();
    saveCreateDraft();
    showToast('عکس ویرایش و ذخیره شد');
}

// ===== Edit Post =====
function openEditSheet(id) {
    const p = posts.find(x => x.id === id);
    if (!p) return;
    editPostId = id;
    document.getElementById('editPostContent').value = p.text;
    document.getElementById('editCharCount').textContent = p.text.length;
    document.getElementById('editPrivacySelect').value = p.privacy || 'public';
    document.getElementById('editTypeSelect').value = p.type || 'post';
    editMediaList = p.media ? JSON.parse(JSON.stringify(p.media)) : [];
    renderEditGallery();
    document.getElementById('editPostOverlay').classList.add('open');
}

function closeEditSheet() {
    document.getElementById('editPostOverlay').classList.remove('open');
    editPostId = null;
    editMediaList = [];
}

function updateEditCharCount() {
    document.getElementById('editCharCount').textContent = document.getElementById('editPostContent').value.length;
}

function renderEditGallery() {
    const container = document.getElementById('editGalleryPreview');
    if (editMediaList.length === 0) {
        container.innerHTML = '<div style="color:var(--text3);font-size:12px;padding:8px 0;">هیچ فایلی انتخاب نشده است</div>';
        return;
    }
    container.innerHTML = editMediaList.map((item, idx) =>
        `<div class="gallery-item">${item.type==='video'?`<video src="${item.url}" preload="metadata" muted></video>`:`<img src="${item.url}" alt="تصویر ${idx+1}">`}<button class="remove-img" onclick="removeEditMedia(${idx})"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><span class="order-badge">${idx+1}</span><div class="edit-overlay">${item.type==='image'?`<button onclick="openEditCropModal(${idx})" title="ویرایش عکس"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="var(--text)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path></svg></button>`:`<button disabled style="background:rgba(255,255,255,0.5);color:#999;cursor:not-allowed;box-shadow:none;"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#999" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path></svg></button>`}<button onclick="replaceEditMedia(${idx})" title="تعویض فایل"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="var(--text)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg></button></div></div>`
    ).join('');
}

function removeEditMedia(idx) { editMediaList.splice(idx, 1);
    renderEditGallery(); }

function replaceEditMedia(idx) {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = editMediaList[idx].type === 'image' ? 'image/*' : 'video/*';
    input.onchange = function(e) {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = function(ev) { editMediaList[idx].url = ev.target.result;
            renderEditGallery(); };
        reader.readAsDataURL(file);
    };
    input.click();
}

function editAddMedia(e, type) {
    const files = Array.from(e.target.files);
    if (type === 'video') {
        if (files[0].size > 50 * 1024 * 1024) { showToast('حجم ویدیو نباید بیشتر از ۵۰ مگابایت باشد.');
            e.target.value = ''; return; }
        const reader = new FileReader();
        reader.onload = function(ev) { editMediaList.push({ type: 'video', url: ev.target.result, file: files[0] });
            renderEditGallery(); };
        reader.readAsDataURL(files[0]);
        e.target.value = '';
        return;
    }
    const remaining = CREATE_MAX_FILES - editMediaList.filter(m => m.type === 'image').length;
    if (files.length > remaining) { showToast('حداکثر ' + CREATE_MAX_FILES + ' فایل مجاز است.');
        e.target.value = ''; return; }
    let processed = 0;
    files.forEach(file => {
        if (file.size > 5 * 1024 * 1024) { showToast('حجم تصویر بیشتر از ۵ مگابایت است.'); return; }
        const reader = new FileReader();
        reader.onload = function(ev) { editMediaList.push({ type: 'image', url: ev.target.result,
                file: file });
            processed++;
            if (processed === files.length) renderEditGallery(); };
        reader.readAsDataURL(file);
    });
    e.target.value = '';
}

function openEditCropModal(index) {
    const images = editMediaList.filter(item => item.type === 'image');
    const targetUrl = images[index].url;
    const realIndex = editMediaList.findIndex(item => item.url === targetUrl);
    if (realIndex === -1) return;
    const img = document.getElementById('cropImagePreview');
    img.src = editMediaList[realIndex].url;
    if (cropperInstance) cropperInstance.destroy();
    cropperInstance = new Cropper(img, { aspectRatio: NaN, viewMode: 1, autoCropArea: 0.8, background: false });
    document.getElementById('cropModalOverlay').classList.add('open');
    const origApply = window.applyCrop;
    window.applyCrop = function() {
        if (!cropperInstance) return;
        const canvas = cropperInstance.getCroppedCanvas();
        const croppedDataUrl = canvas.toDataURL('image/jpeg');
        editMediaList[realIndex].url = croppedDataUrl;
        closeCropModal();
        renderEditGallery();
        showToast('عکس ویرایش شد');
        window.applyCrop = origApply;
    };
}

async function saveEditPost() {
    const text = document.getElementById('editPostContent').value.trim();
    if (!text && editMediaList.length === 0) {
        showToast('لطفاً متن یا حداقل یک عکس/فیلم وارد کنید.');
        return;
    }
    const p = posts.find(x => x.id === editPostId);
    if (!p) return;
    const data = {
        content: text || '',
        privacy: document.getElementById('editPrivacySelect').value,
        type: document.getElementById('editTypeSelect').value,
        media: editMediaList
    };
    try {
        const updated = await API.Posts.update(editPostId, data);
        const idx = posts.findIndex(x => x.id === editPostId);
        if (idx !== -1) posts[idx] = { ...posts[idx], ...updated };
        renderPosts();
        closeEditSheet();
        showToast('پست ویرایش شد');
    } catch (e) {
        const idx = posts.findIndex(x => x.id === editPostId);
        if (idx !== -1) {
            posts[idx].text = data.content;
            posts[idx].privacy = data.privacy;
            posts[idx].type = data.type;
            posts[idx].media = data.media;
            renderPosts();
            closeEditSheet();
            showToast('پست ویرایش شد');
        } else showToast('خطا در ویرایش');
    }
}

// ===== Init =====
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    lang = localStorage.getItem('pulset_lang') || 'fa';
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    const ll = document.getElementById('drawerLangLabel');
    if (ll) ll.textContent = lang === 'fa' ? 'فارسی' : 'English';
    updateThemeLabel();
    const cb = document.getElementById('drawerCloseBtn');
    if (cb) {
        cb.innerHTML = lang === 'en' ?
            `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none"><polyline points="9 18 15 12 9 6"/></svg>` :
            `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none"><polyline points="15 18 9 12 15 6"/></svg>`;
    }
    applyTr();
    updateDrawerAvatar();
    initPosts();
    const path = window.location.pathname.split('/').pop() || 'dashboard.html';
    const pm = { dashboard: 'dashboard', signals_feed: 'signals_feed', markets: 'markets', explore: 'explore' };
    const cp = pm[path.split('.')[0]] || 'dashboard';
    document.querySelectorAll('.nav').forEach(n => n.classList.toggle('active', n.dataset.page === cp));
    if (cp === 'signal') center?.classList.add('active');
});

// ===== Expose =====
window.toggleDark = toggleDark;
window.toggleLang = toggleLang;
window.switchTab = switchTab;
window.toggleDrawer = toggleDrawer;
window.closeDrawer = closeDrawer;
window.toggleLike = toggleLike;
window.toggleBookmark = toggleBookmark;
window.votePoll = votePoll;
window.deletePost = deletePost;
window.openComments = openComments;
window.closeCommentSheet = closeCommentSheet;
window.addComment = addComment;
window.openRepost = openRepost;
window.closeRepostSheet = closeRepostSheet;
window.doRepost = doRepost;
window.openQuoteSheet = openQuoteSheet;
window.closeQuoteSheet = closeQuoteSheet;
window.publishQuote = publishQuote;
window.openReportSheet = openReportSheet;
window.closeReportSheet = closeReportSheet;
window.submitReport = submitReport;
window.openShareModal = openShareModal;
window.closeShareModal = closeShareModal;
window.copyLink = copyLink;
window.shareNative = shareNative;
window.toggleDropdown = toggleDropdown;
window.openCreatePostSheet = openCreatePostSheet;
window.closeCreatePostSheet = closeCreatePostSheet;
window.publishPostFromSheet = publishPostFromSheet;
window.updateCreateCharCount = updateCreateCharCount;
window.previewCreateMedia = previewCreateMedia;
window.removeCreateMedia = removeCreateMedia;
window.replaceCreateMedia = replaceCreateMedia;
window.addCreateTag = addCreateTag;
window.removeCreateTag = removeCreateTag;
window.saveCreateDraft = saveCreateDraft;
window.addCreateTagOnBlur = addCreateTagOnBlur;
window.openEditSheet = openEditSheet;
window.closeEditSheet = closeEditSheet;
window.saveEditPost = saveEditPost;
window.updateEditCharCount = updateEditCharCount;
window.renderEditGallery = renderEditGallery;
window.removeEditMedia = removeEditMedia;
window.replaceEditMedia = replaceEditMedia;
window.editAddMedia = editAddMedia;
window.openEditCropModal = openEditCropModal;
window.openCropModal = openCropModal;
window.closeCropModal = closeCropModal;
window.applyCrop = applyCrop;
window.resetCrop = resetCrop;
window.goToParentPost = goToParentPost;
window.togglePlay = togglePlay;
window.showToast = showToast;
