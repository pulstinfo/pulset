// ================================================================
// pulset.js - اسکریپت صفحه ورود/ثبت‌نام
// ================================================================

// ===== ترجمه‌های اختصاصی این صفحه =====
const PAGE_TRANSLATIONS = {
    fa: {
        tagline: 'سیگنال‌های هوشمند، معاملات آگاهانه',
        login: 'ورود',
        register: 'ثبت‌نام',
        login_title: 'ورود به Pulset',
        register_title: 'عضویت در Pulset',
        email_or_username: 'ایمیل یا نام کاربری',
        password: 'رمز عبور',
        login_btn: 'ورود به پلتفرم',
        register_btn: 'ایجاد حساب کاربری',
        forgot_password: 'رمز عبور خود را فراموش کرده‌اید؟',
        forgot_title: 'فراموشی رمز عبور',
        forgot_desc: 'ایمیل یا شماره موبایل خود را وارد کنید تا کد تأیید برای شما ارسال شود.',
        email_or_phone: 'ایمیل یا موبایل',
        send_code: 'ارسال کد تأیید',
        username: 'نام کاربری',
        full_name: 'نام کامل',
        email: 'ایمیل',
        phone: 'شماره موبایل',
        terms_agree: 'با عضویت، ',
        terms_link: 'شرایط و قوانین',
        terms_agree_end: ' را می‌پذیرید.',
        remember: 'مرا به خاطر بسپار',
        loading: 'در حال ارسال...',
        login_error: 'ایمیل یا نام کاربری الزامی است.',
        password_error: 'رمز عبور الزامی است.',
        recovery_error: 'ایمیل یا شماره موبایل الزامی است.',
        username_error: 'نام کاربری الزامی است.',
        name_error: 'نام کامل الزامی است.',
        email_error: 'ایمیل الزامی است.',
        email_invalid: 'لطفاً یک ایمیل معتبر وارد کنید.',
        phone_error: 'شماره موبایل الزامی است.',
        phone_invalid: 'شماره موبایل معتبر نیست (۰۹۱۲۳۴۵۶۷۸۹).',
        password_short: 'رمز عبور باید حداقل ۸ کاراکتر باشد.',
        username_invalid: 'فقط حروف انگلیسی، اعداد و زیرخط مجاز است (۳ تا ۲۰ کاراکتر).',
        success_login: 'ورود با موفقیت انجام شد',
        success_register: 'ثبت‌نام با موفقیت انجام شد',
        success_code: 'کد تأیید ارسال شد.',
        support: 'پشتیبانی'
    },
    en: {
        tagline: 'Smart signals, informed trades',
        login: 'Login',
        register: 'Sign up',
        login_title: 'Login to Pulset',
        register_title: 'Join Pulset',
        email_or_username: 'Email or username',
        password: 'Password',
        login_btn: 'Login to platform',
        register_btn: 'Create account',
        forgot_password: 'Forgot password?',
        forgot_title: 'Reset password',
        forgot_desc: 'Enter your email or phone to receive a verification code.',
        email_or_phone: 'Email or phone',
        send_code: 'Send verification code',
        username: 'Username',
        full_name: 'Full name',
        email: 'Email',
        phone: 'Phone number',
        terms_agree: 'By signing up, you agree to our ',
        terms_link: 'Terms of Service',
        terms_agree_end: '',
        remember: 'Remember me',
        loading: 'Sending...',
        login_error: 'Email or username is required.',
        password_error: 'Password is required.',
        recovery_error: 'Email or phone is required.',
        username_error: 'Username is required.',
        name_error: 'Full name is required.',
        email_error: 'Email is required.',
        email_invalid: 'Please enter a valid email.',
        phone_error: 'Phone number is required.',
        phone_invalid: 'Invalid phone number (09123456789).',
        password_short: 'Password must be at least 8 characters.',
        username_invalid: 'Only letters, numbers and underscore allowed (3-20 characters).',
        success_login: 'Login successful',
        success_register: 'Registration successful',
        success_code: 'Verification code sent.',
        support: 'Support'
    }
};

// ===== اعمال ترجمه‌های اختصاصی =====
function applyPageTranslations() {
    const lang = getCurrentLang();
    const t = PAGE_TRANSLATIONS[lang];
    if (!t) return;
    document.getElementById('tagline').textContent = t.tagline;
    document.getElementById('loginBtn').textContent = t.login;
    document.getElementById('registerBtn').textContent = t.register;
    document.getElementById('loginTitle').textContent = t.login_title;
    document.getElementById('registerTitle').textContent = t.register_title;
    document.getElementById('loginEmailLabel').textContent = t.email_or_username;
    document.getElementById('loginPasswordLabel').textContent = t.password;
    document.getElementById('loginSubmitBtn').textContent = t.login_btn;
    document.getElementById('registerSubmitBtn').textContent = t.register_btn;
    document.getElementById('forgotLink').textContent = t.forgot_password;
    document.getElementById('forgotTitle').textContent = t.forgot_title;
    document.getElementById('forgotDesc').textContent = t.forgot_desc;
    document.getElementById('recoveryLabel').textContent = t.email_or_phone;
    document.getElementById('forgotSubmitBtn').textContent = t.send_code;
    document.getElementById('regUsernameLabel').textContent = t.username;
    document.getElementById('regNameLabel').textContent = t.full_name;
    document.getElementById('regEmailLabel').textContent = t.email;
    document.getElementById('regPhoneLabel').textContent = t.phone;
    document.getElementById('regPasswordLabel').textContent = t.password;
    document.getElementById('rememberLabel').textContent = t.remember;
    document.getElementById('termsText').textContent = t.terms_agree;
    document.getElementById('termsLink').textContent = t.terms_link;
    document.getElementById('termsEnd').textContent = t.terms_agree_end;
    document.getElementById('supportLabel').textContent = t.support;
    document.getElementById('langLabel').textContent = lang === 'fa' ? 'فارسی' : 'English';
}
window.applyPageTranslations = applyPageTranslations;

// ===== رویدادها =====
document.addEventListener('DOMContentLoaded', function() {
    applyPageTranslations();

    // دکمه تغییر زبان
    document.getElementById('langToggle').addEventListener('click', function() {
        toggleLang();
        applyPageTranslations();
    });

    // دکمه‌های گیت
    document.querySelector('[data-action="login"]').addEventListener('click', function() {
        showScreen('loginScreen');
    });
    document.querySelector('[data-action="register"]').addEventListener('click', function() {
        showScreen('registerScreen');
    });

    // دکمه‌های بازگشت
    document.querySelectorAll('[data-action="back-to-gate"]').forEach(function(btn) {
        btn.addEventListener('click', function() {
            showScreen('gateScreen');
        });
    });
    document.querySelector('[data-action="back-to-login"]').addEventListener('click', function() {
        showScreen('loginScreen');
    });

    // نمایش/مخفی کردن رمز
    document.querySelectorAll('.toggle-password').forEach(function(btn) {
        btn.addEventListener('click', function() {
            const input = document.getElementById(this.dataset.target);
            if (!input) return;
            if (input.type === 'password') {
                input.type = 'text';
                this.innerHTML = `<svg viewBox="0 0 24 24"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`;
            } else {
                input.type = 'password';
                this.innerHTML = `<svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`;
            }
        });
    });

    // دکمه‌های فرم
    document.querySelector('[data-action="login-submit"]').addEventListener('click', handleLogin);
    document.querySelector('[data-action="register-submit"]').addEventListener('click', handleRegister);
    document.querySelector('[data-action="forgot-submit"]').addEventListener('click', handleForgotPassword);
    document.querySelector('[data-action="forgot-password"]').addEventListener('click', function(e) {
        e.preventDefault();
        showScreen('forgotScreen');
    });

    // کلید Enter
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            const activeScreen = document.querySelector('.screen.active');
            if (activeScreen) {
                const submitBtn = activeScreen.querySelector('[data-action$="-submit"]');
                if (submitBtn) submitBtn.click();
            }
        }
    });

    // نمایش گیت
    showScreen('gateScreen');

    // بازیابی "مرا به خاطر بسپار"
    const remembered = localStorage.getItem('pulset_remember');
    if (remembered) {
        document.getElementById('loginEmail').value = remembered;
        document.getElementById('rememberMe').checked = true;
    }

    console.log('✅ pulset.js loaded');
});

// ===== مدیریت صفحه‌ها =====
const footer = document.getElementById('authFooter');
const topButtons = document.getElementById('topButtons');

function showScreen(screenId) {
    document.querySelectorAll('.screen').forEach(function(s) {
        s.classList.remove('active');
    });
    document.getElementById(screenId).classList.add('active');
    if (screenId === 'gateScreen') {
        footer.classList.remove('hidden');
        topButtons.classList.remove('hidden');
    } else {
        footer.classList.add('hidden');
        topButtons.classList.add('hidden');
    }
}
window.showScreen = showScreen;

// ===== توابع اعتبارسنجی =====
function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
function isValidUsername(username) {
    return /^[a-zA-Z0-9_]{3,20}$/.test(username);
}
function isValidPassword(password) {
    return password.length >= 8;
}
function isValidIranPhone(phone) {
    return /^09\d{9}$/.test(phone);
}

function showError(inputId, message) {
    const el = document.getElementById(inputId + 'Error');
    if (el) {
        el.textContent = message;
        el.classList.add('show');
    }
}
function clearAllErrors() {
    document.querySelectorAll('.error-message').forEach(function(el) {
        el.classList.remove('show');
    });
}
function setLoading(btn, loading) {
    const t = PAGE_TRANSLATIONS[getCurrentLang()] || PAGE_TRANSLATIONS.fa;
    if (loading) {
        btn.classList.add('btn-loading');
        btn.innerHTML = `<span class="spinner"></span> ${t.loading || 'در حال ارسال...'}`;
        btn.disabled = true;
    } else {
        btn.classList.remove('btn-loading');
        if (btn.id === 'loginSubmitBtn') btn.textContent = t.login_btn || 'ورود به پلتفرم';
        else if (btn.id === 'registerSubmitBtn') btn.textContent = t.register_btn || 'ایجاد حساب کاربری';
        else if (btn.id === 'forgotSubmitBtn') btn.textContent = t.send_code || 'ارسال کد تأیید';
        btn.disabled = false;
    }
}

// ===== ورود =====
async function handleLogin() {
    clearAllErrors();
    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value.trim();
    const remember = document.getElementById('rememberMe').checked;
    const btn = document.getElementById('loginSubmitBtn');
    const t = PAGE_TRANSLATIONS[getCurrentLang()] || PAGE_TRANSLATIONS.fa;
    let valid = true;

    if (!email) {
        showError('loginEmail', t.login_error);
        valid = false;
    }
    if (!password) {
        showError('loginPassword', t.password_error);
        valid = false;
    }
    if (!valid) return;

    setLoading(btn, true);
    try {
        const response = await API.Auth.login(email, password);
        if (response && response.token) {
            API.setToken(response.token);
            if (response.refreshToken) {
                localStorage.setItem('pulset_refresh_token', response.refreshToken);
            }
            localStorage.setItem('pulset_profile', JSON.stringify(response.user));
            if (response.user && response.user.role) {
                localStorage.setItem('pulset_user_role', response.user.role);
            }
            if (remember) {
                localStorage.setItem('pulset_remember', email);
            } else {
                localStorage.removeItem('pulset_remember');
            }
            setLoading(btn, false);
            showToast(t.success_login);
            setTimeout(function() {
                window.location.href = 'dashboard.html';
            }, 500);
        } else {
            throw new Error('Invalid response');
        }
    } catch (error) {
        setLoading(btn, false);
        showToast('❌ ' + (error.message || 'خطا در ورود'), 3000);
        showError('loginEmail', error.message || 'نام کاربری یا رمز عبور اشتباه است');
    }
}
window.handleLogin = handleLogin;

// ===== ثبت‌نام =====
async function handleRegister() {
    clearAllErrors();
    const username = document.getElementById('regUsername').value.trim();
    const name = document.getElementById('regName').value.trim();
    const email = document.getElementById('regEmail').value.trim();
    const phone = document.getElementById('regPhone').value.trim();
    const password = document.getElementById('regPassword').value.trim();
    const btn = document.getElementById('registerSubmitBtn');
    const t = PAGE_TRANSLATIONS[getCurrentLang()] || PAGE_TRANSLATIONS.fa;
    let valid = true;

    if (!username) {
        showError('regUsername', t.username_error);
        valid = false;
    } else if (!isValidUsername(username)) {
        showError('regUsername', t.username_invalid);
        valid = false;
    }
    if (!name) {
        showError('regName', t.name_error);
        valid = false;
    }
    if (!email) {
        showError('regEmail', t.email_error);
        valid = false;
    } else if (!isValidEmail(email)) {
        showError('regEmail', t.email_invalid);
        valid = false;
    }
    if (!phone) {
        showError('regPhone', t.phone_error);
        valid = false;
    } else if (!isValidIranPhone(phone)) {
        showError('regPhone', t.phone_invalid);
        valid = false;
    }
    if (!password) {
        showError('regPassword', t.password_error);
        valid = false;
    } else if (!isValidPassword(password)) {
        showError('regPassword', t.password_short);
        valid = false;
    }
    if (!valid) return;

    setLoading(btn, true);
    try {
        const response = await API.Auth.register({
            username: username,
            name: name,
            email: email,
            phone: phone,
            password: password
        });
        if (response && response.token) {
            API.setToken(response.token);
            localStorage.setItem('pulset_profile', JSON.stringify(response.user));
            if (response.user && response.user.role) {
                localStorage.setItem('pulset_user_role', response.user.role);
            }
            setLoading(btn, false);
            showToast(t.success_register);
            setTimeout(function() {
                window.location.href = 'dashboard.html';
            }, 500);
        } else {
            throw new Error('Invalid response');
        }
    } catch (error) {
        setLoading(btn, false);
        showToast('❌ ' + (error.message || 'خطا در ثبت‌نام'), 3000);
        showError('regEmail', error.message || 'خطا در ثبت‌نام');
    }
}
window.handleRegister = handleRegister;

// ===== فراموشی رمز =====
async function handleForgotPassword() {
    clearAllErrors();
    const input = document.getElementById('recoveryInput').value.trim();
    const btn = document.getElementById('forgotSubmitBtn');
    const t = PAGE_TRANSLATIONS[getCurrentLang()] || PAGE_TRANSLATIONS.fa;

    if (!input) {
        showError('recovery', t.recovery_error);
        return;
    }

    setLoading(btn, true);
    try {
        await API.Auth.forgotPassword(input);
        setLoading(btn, false);
        showToast(t.success_code);
        setTimeout(function() {
            showScreen('loginScreen');
        }, 3000);
    } catch (error) {
        setLoading(btn, false);
        showToast('❌ ' + (error.message || 'خطا در ارسال کد'), 3000);
        showError('recovery', error.message || 'خطا در ارسال کد');
    }
}
window.handleForgotPassword = handleForgotPassword;
