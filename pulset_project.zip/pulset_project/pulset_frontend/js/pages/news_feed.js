// ================================================================
// news_feed.js - اسکریپت صفحه اخبار مالی
// ================================================================

// ===== ترجمه =====
const PAGE_TR = {
    fa: {
        news_title: 'اخبار مالی',
        all: 'همه',
        economy: 'اقتصاد کلان',
        crypto: 'رمز ارزها',
        stock: 'بورس و بازار',
        analysis: 'تحلیل و گزارش',
        tech: 'فناوری',
        international: 'بین‌الملل',
        empty: 'خبری یافت نشد',
        empty_desc: 'با تغییر فیلتر یا جستجو، اخبار را پیدا کنید.',
        loading: 'در حال بارگذاری...',
        impact_high: 'بالا',
        impact_medium: 'متوسط',
        impact_low: 'پایین'
    },
    en: {
        news_title: 'Financial News',
        all: 'All',
        economy: 'Economy',
        crypto: 'Crypto',
        stock: 'Stocks',
        analysis: 'Analysis',
        tech: 'Tech',
        international: 'International',
        empty: 'No news found',
        empty_desc: 'Try changing filters or search.',
        impact_high: 'High',
        impact_medium: 'Medium',
        impact_low: 'Low'
    }
};

// ===== متغیرها =====
let currentCategory = 'all';
let newsItems = [];
let currentNewsId = null;
let wsUnsubscribe = null;

// ===== اعمال ترجمه =====
function applyPageTranslations() {
    const lang = getCurrentLang();
    const t = PAGE_TR[lang] || PAGE_TR.fa;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        if (t[key]) el.textContent = t[key];
    });
}
window.applyPageTranslations = applyPageTranslations;

// ===== تابع t محلی =====
function t(key) {
    const lang = getCurrentLang();
    return PAGE_TR[lang]?.[key] || key;
}

// ===== داده‌های نمونه =====
function getFallbackNews(category, query) {
    const now = Date.now();
    const allNews = [
        { id: 1, title: 'بیت‌کوین به مقاومت ۶۸ هزار دلاری رسید', summary: 'بیت‌کوین امروز با رشد ۲.۳۴ درصدی به قیمت ۶۷,۲۴۵ دلار رسید. تحلیلگران معتقدند در صورت شکست مقاومت ۶۸ هزار دلاری، هدف بعدی ۷۲ هزار دلار خواهد بود. حجم معاملات در ۲۴ ساعت گذشته ۲۴.۸ میلیارد دلار گزارش شده است.', category: 'crypto', source: 'پولست نیوز', time: now - 120000, views: 1245, likes: 89, comments: 0, reposts: 12, liked: false, saved: false, image: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=400&h=300&fit=crop', content: 'بیت‌کوین امروز با رشد ۲.۳۴ درصدی به قیمت ۶۷,۲۴۵ دلار رسید. تحلیلگران معتقدند در صورت شکست مقاومت ۶۸ هزار دلاری، هدف بعدی ۷۲ هزار دلار خواهد بود.' },
        { id: 2, title: 'افزایش نرخ بهره توسط فدرال رزرو', summary: 'فدرال رزرو آمریکا نرخ بهره را ۰.۲۵ درصد افزایش داد. این تصمیم در واکنش به تورم ۳.۲ درصدی ماه گذشته گرفته شده است. بازارها به این خبر با افت مواجه شدند و شاخص‌های اصلی بین ۰.۵ تا ۱.۲ درصد کاهش یافتند.', category: 'economy', source: 'پولست نیوز', time: now - 480000, views: 876, likes: 45, comments: 0, reposts: 7, liked: false, saved: false, image: 'https://images.unsplash.com/photo-1591696204402-a7cf6a7be5da?w=400&h=300&fit=crop', content: 'فدرال رزرو آمریکا نرخ بهره را ۰.۲۵ درصد افزایش داد. این تصمیم در واکنش به تورم ۳.۲ درصدی ماه گذشته گرفته شده است.' },
        { id: 3, title: 'ETF بیت‌کوین رکورد ورود سرمایه را شکست', summary: 'صندوق‌های ETF بیت‌کوین در آمریکا روز گذشته ۱.۲ میلیارد دلار ورود سرمایه ثبت کردند. این بیشترین میزان ورود سرمایه از زمان راه‌اندازی این صندوق‌ها در ژانویه ۲۰۲۴ است.', category: 'crypto', source: 'پولست نیوز', time: now - 900000, views: 2341, likes: 156, comments: 0, reposts: 28, liked: false, saved: false, image: 'https://images.unsplash.com/photo-1620321023374-d1a68fbc720d?w=400&h=300&fit=crop', content: 'صندوق‌های ETF بیت‌کوین در آمریکا روز گذشته ۱.۲ میلیارد دلار ورود سرمایه ثبت کردند.' },
        { id: 4, title: 'تسلا گزارش سود سه‌ماهه را منتشر کرد', summary: 'شرکت تسلا گزارش سود سه‌ماهه خود را منتشر کرد و از سود ۰.۹۸ دلار به ازای هر سهم خبر داد. این رقم بالاتر از پیش‌بینی تحلیلگران بوده و باعث رشد ۴.۵ درصدی قیمت سهام این شرکت در بازار پس از ساعات کاری شد.', category: 'stock', source: 'پولست نیوز', time: now - 1500000, views: 567, likes: 34, comments: 0, reposts: 6, liked: false, saved: false, image: 'https://images.unsplash.com/photo-1617704548623-340376564e68?w=400&h=300&fit=crop', content: 'تسلا سود ۰.۹۸ دلاری به ازای هر سهم گزارش کرد.' },
        { id: 5, title: 'تحلیل هفتگی بازار رمزارزها', summary: 'در هفته گذشته، بیت‌کوین با رشد ۱۲ درصدی همراه بود. اتریوم نیز با افزایش ۸ درصدی به مقاومت ۳,۵۰۰ دلاری نزدیک شده است. تحلیلگران معتقدند بازار در فاز صعودی قرار دارد.', category: 'analysis', source: 'پولست نیوز', time: now - 1800000, views: 890, likes: 67, comments: 0, reposts: 15, liked: false, saved: false, image: null, content: 'تحلیل هفتگی بازار رمزارزها نشان از رشد ۱۲ درصدی بیت‌کوین دارد.' }
    ];
    let filtered = allNews;
    if (category !== 'all') filtered = filtered.filter(n => n.category === category);
    if (query) filtered = filtered.filter(n => n.title.includes(query) || n.summary.includes(query));
    return filtered;
}

// ===== دریافت از API =====
async function fetchNews(category = 'all', query = '') {
    try {
        const data = await API.News.get(category, query);
        if (data && data.length) {
            return data.map(n => ({
                id: n.id || Date.now() + Math.random(),
                title: n.title || 'بدون عنوان',
                summary: n.summary || n.description || '',
                category: n.category || 'general',
                source: n.source || 'پولست نیوز',
                time: n.time || n.publishedAt || Date.now(),
                views: n.views || 0,
                likes: n.likes || 0,
                comments: n.comments || 0,
                reposts: n.reposts || 0,
                liked: n.liked || false,
                saved: n.saved || false,
                image: n.image || n.urlToImage || null,
                content: n.content || n.summary || ''
            }));
        }
        return getFallbackNews(category, query);
    } catch (e) {
        console.warn('News API error, using fallback:', e);
        return getFallbackNews(category, query);
    }
}

// ===== رندر اخبار =====
function renderNews() {
    const list = document.getElementById('newsList');
    const search = document.getElementById('searchInput').value.trim().toLowerCase();
    let filtered = newsItems.filter(n => currentCategory === 'all' || n.category === currentCategory);
    if (search) filtered = filtered.filter(n => n.title.includes(search) || n.summary.includes(search));
    if (!filtered.length) {
        list.innerHTML = `
            <div class="empty-state">
                <span class="icon">📰</span>
                <div class="text">${t('empty')}<br><span style="font-size:12px;color:var(--text3);">${t('empty_desc')}</span></div>
            </div>
        `;
        return;
    }
    const catMap = { economy: 'اقتصاد کلان', crypto: 'رمز ارزها', stock: 'بورس و بازار', analysis: 'تحلیل و گزارش', tech: 'فناوری', international: 'بین‌الملل', general: 'عمومی' };
    list.innerHTML = filtered.map(n => {
        const isLiked = n.liked ? 'liked' : '';
        const isSaved = n.saved ? 'saved' : '';
        return `
            <div class="news-card" onclick="openDetail(${n.id})">
                <div class="category-tag">${catMap[n.category] || n.category}</div>
                <div class="title">${n.title}</div>
                <div class="summary">${n.summary}</div>
                <div class="meta"><span class="source">${n.source}</span><span>${formatTime(n.time)}</span><span>👁️ ${n.views}</span></div>
                <div class="actions" onclick="event.stopPropagation();">
                    <button class="btn like ${isLiked}" onclick="toggleLike(${n.id})"><svg class="i" viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg><span>${n.likes}</span></button>
                    <button class="btn bookmark ${isSaved}" onclick="toggleBookmark(${n.id})"><svg class="i" viewBox="0 0 24 24"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg></button>
                    <button class="btn-ai" onclick="openAnalysis(${n.id})"><i class="fas fa-robot"></i> تحلیل AI</button>
                    <span class="views">${n.views}</span>
                </div>
            </div>
        `;
    }).join('');
}

async function loadNews() {
    const data = await fetchNews(currentCategory);
    newsItems = data.map(n => ({ ...n, liked: false, saved: false }));
    renderNews();
    connectWebSocket();
}

// ===== WebSocket =====
function connectWebSocket() {
    if (wsUnsubscribe) {
        wsUnsubscribe();
        wsUnsubscribe = null;
    }
    const token = API.getToken();
    if (!token) return;
    wsUnsubscribe = API.WS.subscribe('news', (data) => {
        if (data.type === 'new_news' && data.news) {
            const newItem = { id: Date.now(), ...data.news, liked: false, saved: false };
            newsItems.unshift(newItem);
            renderNews();
            showToast('📰 خبر جدید: ' + newItem.title);
        }
    });
}

// ===== تعاملات =====
function toggleLike(id) {
    const n = newsItems.find(x => x.id === id);
    if (!n) return;
    n.liked = !n.liked;
    n.likes += n.liked ? 1 : -1;
    renderNews();
    API.News.like ? API.News.like(id).catch(() => {}) : null;
}

function toggleBookmark(id) {
    const n = newsItems.find(x => x.id === id);
    if (!n) return;
    n.saved = !n.saved;
    renderNews();
    showToast(n.saved ? 'ذخیره شد' : 'حذف از ذخیره‌ها');
    API.News.bookmark ? API.News.bookmark(id).catch(() => {}) : null;
}

function filterNews() {
    renderNews();
}

function setCategory(cat, btn) {
    currentCategory = cat;
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    loadNews();
}

// ===== شیت جزئیات =====
function openDetail(id) {
    currentNewsId = id;
    const n = newsItems.find(x => x.id === id);
    if (!n) return;
    n.views = (n.views || 0) + 1;
    renderNews();
    const body = document.getElementById('detailBody');
    const catMap = { economy: 'اقتصاد کلان', crypto: 'رمز ارزها', stock: 'بورس و بازار', analysis: 'تحلیل و گزارش', tech: 'فناوری', international: 'بین‌الملل', general: 'عمومی' };
    const isLiked = n.liked ? 'liked' : '';
    const isSaved = n.saved ? 'saved' : '';
    body.innerHTML = `
        ${n.image ? `<img class="news-detail-image" src="${n.image}" alt="${n.title}" loading="lazy" />` : ''}
        <div class="news-detail-title">${n.title}</div>
        <div class="news-detail-meta">
            <span class="source">${n.source}</span>
            <span>${catMap[n.category] || n.category}</span>
            <span>${formatTime(n.time)}</span>
            <span>👁️ ${n.views}</span>
        </div>
        <div class="news-detail-content">${n.content || n.summary}</div>
        <div class="news-detail-actions">
            <button class="btn like ${isLiked}" onclick="toggleLikeFromDetail(${n.id})"><i class="fas fa-heart"></i> <span>${n.likes}</span></button>
            <button class="btn bookmark ${isSaved}" onclick="toggleBookmarkFromDetail(${n.id})"><i class="fas fa-bookmark"></i></button>
            <button class="btn primary" onclick="openAnalysisFromDetail(${n.id})"><i class="fas fa-robot"></i> تحلیل AI</button>
        </div>
    `;
    document.getElementById('detailOverlay').classList.add('open');
}

function closeDetailSheet() {
    document.getElementById('detailOverlay').classList.remove('open');
}

function toggleLikeFromDetail(id) {
    toggleLike(id);
    openDetail(id);
}

function toggleBookmarkFromDetail(id) {
    toggleBookmark(id);
    openDetail(id);
}

function openAnalysisFromDetail(id) {
    closeDetailSheet();
    setTimeout(() => openAnalysis(id), 300);
}

// ===== تحلیل AI =====
function openAnalysis(id) {
    currentNewsId = id;
    document.getElementById('analysisOverlay').classList.add('open');
    document.getElementById('analysisLoading').classList.add('show');
    document.getElementById('analysisResult').classList.remove('show');
    document.getElementById('analysisError').classList.remove('show');
    const n = newsItems.find(x => x.id === id);
    if (!n) { showAnalysisError(); return; }
    fetchAnalysisFromAI(n.title, n.summary);
}

function closeAnalysis() {
    document.getElementById('analysisOverlay').classList.remove('open');
    currentNewsId = null;
}

function showAnalysisError() {
    document.getElementById('analysisLoading').classList.remove('show');
    document.getElementById('analysisError').classList.add('show');
}

async function fetchAnalysisFromAI(title, summary) {
    try {
        const data = await API.News.analyze(title, summary);
        document.getElementById('analysisLoading').classList.remove('show');
        document.getElementById('analysisResult').classList.add('show');
        document.getElementById('analysisSummary').textContent = data.summary || 'خلاصه‌ای یافت نشد.';
        document.getElementById('analysisText').textContent = data.analysis || 'تحلیلی یافت نشد.';
        document.getElementById('analysisPrediction').textContent = data.prediction || 'پیش‌بینی‌ای یافت نشد.';
        const impact = data.impact || 'medium';
        const impactMap = { high: t('impact_high'), medium: t('impact_medium'), low: t('impact_low') };
        const el = document.getElementById('analysisImpact');
        el.textContent = impactMap[impact] || impact;
        el.className = 'impact ' + impact;
    } catch (err) {
        console.error('AI Analysis error:', err);
        fallbackAnalysis(title, summary);
    }
}

function fallbackAnalysis(title, summary) {
    document.getElementById('analysisLoading').classList.remove('show');
    document.getElementById('analysisResult').classList.add('show');
    const impacts = ['high', 'medium', 'low'];
    const impactLabels = { high: t('impact_high'), medium: t('impact_medium'), low: t('impact_low') };
    const randImpact = impacts[Math.floor(Math.random() * 3)];
    document.getElementById('analysisSummary').textContent = summary.length > 100 ? summary.substring(0, 100) + '...' : summary;
    document.getElementById('analysisText').textContent = '📊 این خبر نشان‌دهنده تغییرات قابل توجه در بازار است. با توجه به داده‌های موجود، سرمایه‌گذاران باید با دقت بیشتری به این موضوع نگاه کنند. تحلیل تکنیکال نشان می‌دهد که این خبر می‌تواند تأثیر قابل توجهی بر روند قیمت‌ها داشته باشد.';
    document.getElementById('analysisPrediction').textContent = '🎯 در کوتاه‌مدت، احتمال نوسان قیمت وجود دارد. توصیه می‌شود با مدیریت ریسک و استفاده از حد ضرر، معاملات خود را کنترل کنید.';
    const el = document.getElementById('analysisImpact');
    el.textContent = impactLabels[randImpact];
    el.className = 'impact ' + randImpact;
}

// ===== مقداردهی اولیه =====
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    const lang = getCurrentLang();
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.body.classList.toggle('lang-en', lang === 'en');
    document.body.classList.toggle('lang-fa', lang === 'fa');
    applyPageTranslations();
    loadNews();
    console.log('✅ news_feed.js loaded');
});

// ===== خروجی توابع =====
window.setCategory = setCategory;
window.filterNews = filterNews;
window.toggleLike = toggleLike;
window.toggleBookmark = toggleBookmark;
window.openDetail = openDetail;
window.closeDetailSheet = closeDetailSheet;
window.toggleLikeFromDetail = toggleLikeFromDetail;
window.toggleBookmarkFromDetail = toggleBookmarkFromDetail;
window.openAnalysisFromDetail = openAnalysisFromDetail;
window.openAnalysis = openAnalysis;
window.closeAnalysis = closeAnalysis;
window.showToast = showToast;
window.toggleDark = toggleDark;
window.toggleLang = toggleLang;
