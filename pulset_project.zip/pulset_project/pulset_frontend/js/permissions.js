// ================================================================
// permissions.js - مدیریت دسترسی‌ها، محدودیت‌ها و اشتراک‌ها
// ================================================================

const PERMISSIONS_KEY = 'pulset_permissions';

// ===== 1. دسترسی‌های پیش‌فرض =====
function getDefaultPermissions() {
    return {
        // دسترسی‌های هوش مصنوعی
        ai: {
            model: 'openai',           // openai | deepseek | xai
            dailyLimit: 5,             // تعداد پیام در روز برای کاربر عادی
            unlimited: false,          // آیا نامحدود است؟
            messagesToday: 0,          // تعداد پیام‌های امروز
            lastReset: Date.now()      // تاریخ آخرین ریست
        },
        // دسترسی‌های سیگنال
        signals: {
            free: true,                // سیگنال رایگان (همیشه فعال)
            premium: false,            // سیگنال پلاس (فعال با اشتراک)
            pro: false                 // سیگنال پرو (فعال با اشتراک سالانه)
        },
        // دسترسی مشاوره
        consulting: {
            active: false,
            remaining: 0               // تعداد جلسات باقی‌مانده
        },
        // بسته‌های آموزشی خریداری‌شده
        education: {
            packages: []               // لیست شناسه‌های بسته‌های آموزشی
        },
        // وضعیت اشتراک
        subscription: {
            type: 'free',              // free | monthly | quarterly | yearly
            expiresAt: null            // تاریخ انقضا
        }
    };
}

// ===== 2. دریافت و ذخیره دسترسی‌ها =====
function getPermissions() {
    try {
        const data = localStorage.getItem(PERMISSIONS_KEY);
        if (data) {
            const parsed = JSON.parse(data);
            // ریست کردن شمارنده روزانه (هر روز)
            const today = new Date().toDateString();
            const lastReset = new Date(parsed.ai?.lastReset || 0).toDateString();
            if (today !== lastReset) {
                parsed.ai.messagesToday = 0;
                parsed.ai.lastReset = Date.now();
            }
            return parsed;
        }
    } catch (e) {
        console.warn('Error loading permissions:', e);
    }
    // اگر چیزی نبود، پیش‌فرض رو ذخیره کن
    const def = getDefaultPermissions();
    localStorage.setItem(PERMISSIONS_KEY, JSON.stringify(def));
    return def;
}

function savePermissions(data) {
    localStorage.setItem(PERMISSIONS_KEY, JSON.stringify(data));
}

// ===== 3. توابع دسترسی به سیگنال‌ها =====
function hasPremiumSignalAccess() {
    const p = getPermissions();
    return p.signals.premium || p.signals.pro;
}

function hasProSignalAccess() {
    const p = getPermissions();
    return p.signals.pro;
}

function getSignalAccessLevel() {
    const p = getPermissions();
    if (p.signals.pro) return 'pro';
    if (p.signals.premium) return 'premium';
    return 'free';
}

// ===== 4. توابع دسترسی به هوش مصنوعی =====
function getAIModel() {
    const p = getPermissions();
    // اگر کاربر پریمیوم یا پرو هست، مدل انتخابی خودش رو داره
    if (p.ai.unlimited || p.signals.premium || p.signals.pro) {
        return p.ai.model || 'openai';
    }
    return 'openai'; // کاربر عادی فقط OpenAI
}

function getAIDailyLimit() {
    const p = getPermissions();
    if (p.ai.unlimited) return Infinity;
    if (p.signals.premium) return 30;
    if (p.signals.pro) return Infinity;
    return p.ai.dailyLimit || 5;
}

function getAIMessagesToday() {
    const p = getPermissions();
    return p.ai.messagesToday || 0;
}

function incrementAIMessages() {
    const p = getPermissions();
    p.ai.messagesToday = (p.ai.messagesToday || 0) + 1;
    savePermissions(p);
    return p.ai.messagesToday;
}

function canUseAI() {
    const p = getPermissions();
    if (p.ai.unlimited) return true;
    if (p.signals.pro) return true;
    return (p.ai.messagesToday || 0) < getAIDailyLimit();
}

function getRemainingAIChats() {
    const limit = getAIDailyLimit();
    if (limit === Infinity) return Infinity;
    const used = getAIMessagesToday();
    return Math.max(0, limit - used);
}

function getAvailableAIModels() {
    const p = getPermissions();
    const models = ['openai'];
    // اگر پریمیوم یا پرو باشد، DeepSeek هم اضافه می‌شود
    if (p.signals.premium || p.signals.pro || p.ai.dailyLimit >= 30) {
        models.push('deepseek');
    }
    // اگر پرو باشد یا نامحدود، xAI هم اضافه می‌شود
    if (p.signals.pro || p.ai.unlimited) {
        models.push('xai');
    }
    return models;
}

// ===== 5. توابع مشاوره =====
function hasConsultingAccess() {
    const p = getPermissions();
    return p.consulting.active && p.consulting.remaining > 0;
}

function getConsultingRemaining() {
    const p = getPermissions();
    return p.consulting.remaining || 0;
}

function useConsulting() {
    const p = getPermissions();
    if (!p.consulting.active || p.consulting.remaining <= 0) return false;
    p.consulting.remaining -= 1;
    if (p.consulting.remaining === 0) p.consulting.active = false;
    savePermissions(p);
    return true;
}

// ===== 6. توابع آموزشی =====
function hasEducationPackage(packageId) {
    const p = getPermissions();
    return p.education.packages.includes(packageId);
}

function getEducationPackages() {
    const p = getPermissions();
    return p.education.packages || [];
}

// ===== 7. توابع اشتراک =====
function getSubscriptionType() {
    const p = getPermissions();
    return p.subscription.type || 'free';
}

function isSubscriptionActive() {
    const p = getPermissions();
    if (p.subscription.type === 'free') return false;
    if (!p.subscription.expiresAt) return false;
    return new Date(p.subscription.expiresAt) > new Date();
}

function getSubscriptionExpiry() {
    const p = getPermissions();
    return p.subscription.expiresAt;
}

function getSubscriptionLabel() {
    const type = getSubscriptionType();
    const map = {
        free: 'رایگان',
        monthly: 'ماهانه',
        quarterly: '۳ ماهه',
        yearly: 'سالانه'
    };
    return map[type] || 'رایگان';
}

// ===== 8. اعمال خرید (اتصال به فروشگاه) =====
function applyPurchase(productId) {
    const p = getPermissions();
    const map = {
        // ===== هوش مصنوعی =====
        'ai_premium': function() {
            p.ai.dailyLimit = 50;
            p.ai.model = 'deepseek';
        },
        'ai_pro': function() {
            p.ai.unlimited = true;
            p.ai.model = 'xai';
            p.signals.premium = true;
        },
        // ===== اشتراک‌ها =====
        'sub_monthly': function() {
            p.subscription.type = 'monthly';
            p.subscription.expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
            p.signals.premium = true;
            p.ai.dailyLimit = 30;
        },
        'sub_quarterly': function() {
            p.subscription.type = 'quarterly';
            p.subscription.expiresAt = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString();
            p.signals.premium = true;
            p.ai.dailyLimit = 50;
        },
        'sub_yearly': function() {
            p.subscription.type = 'yearly';
            p.subscription.expiresAt = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString();
            p.signals.pro = true;
            p.signals.premium = true;
            p.ai.unlimited = true;
        },
        // ===== مشاوره =====
        'consulting_30': function() {
            p.consulting.active = true;
            p.consulting.remaining = (p.consulting.remaining || 0) + 1;
        },
        'consulting_60': function() {
            p.consulting.active = true;
            p.consulting.remaining = (p.consulting.remaining || 0) + 2;
        },
        // ===== آموزشی =====
        'edu_basic': function() {
            if (!p.education.packages.includes('basic')) {
                p.education.packages.push('basic');
            }
        },
        'edu_advanced': function() {
            if (!p.education.packages.includes('advanced')) {
                p.education.packages.push('advanced');
            }
        }
    };
    if (map[productId]) {
        map[productId]();
        savePermissions(p);
        return true;
    }
    return false;
}

// ===== 9. تابع کمکی برای لاگین/ثبت‌نام =====
function resetPermissions() {
    const def = getDefaultPermissions();
    savePermissions(def);
    return def;
}

// ===== 10. تابع برای دیباگ =====
function debugPermissions() {
    console.log('📋 Current Permissions:', getPermissions());
    console.log('🔓 Premium Access:', hasPremiumSignalAccess());
    console.log('🔓 Pro Access:', hasProSignalAccess());
    console.log('📨 AI Remaining:', getRemainingAIChats());
    console.log('📨 AI Models:', getAvailableAIModels());
    console.log('📅 Subscription:', getSubscriptionLabel(), isSubscriptionActive() ? '✅' : '❌');
    console.log('💬 Consulting Remaining:', getConsultingRemaining());
    console.log('📚 Education Packages:', getEducationPackages());
}

// ================================================================
// 11. صادر کردن برای استفاده در صفحات
// ================================================================
window.Permissions = {
    // توابع اصلی
    get: getPermissions,
    save: savePermissions,
    reset: resetPermissions,
    debug: debugPermissions,

    // سیگنال‌ها
    hasPremiumSignalAccess: hasPremiumSignalAccess,
    hasProSignalAccess: hasProSignalAccess,
    getSignalAccessLevel: getSignalAccessLevel,

    // هوش مصنوعی
    getAIModel: getAIModel,
    getAIDailyLimit: getAIDailyLimit,
    getAIMessagesToday: getAIMessagesToday,
    incrementAIMessages: incrementAIMessages,
    canUseAI: canUseAI,
    getRemainingAIChats: getRemainingAIChats,
    getAvailableAIModels: getAvailableAIModels,

    // مشاوره
    hasConsultingAccess: hasConsultingAccess,
    getConsultingRemaining: getConsultingRemaining,
    useConsulting: useConsulting,

    // آموزشی
    hasEducationPackage: hasEducationPackage,
    getEducationPackages: getEducationPackages,

    // اشتراک
    getSubscriptionType: getSubscriptionType,
    isSubscriptionActive: isSubscriptionActive,
    getSubscriptionExpiry: getSubscriptionExpiry,
    getSubscriptionLabel: getSubscriptionLabel,

    // خرید
    applyPurchase: applyPurchase,

    // پیش‌فرض
    defaultPermissions: getDefaultPermissions
};

// ================================================================
// 12. مقداردهی اولیه و دیباگ
// ================================================================
console.log('✅ Permissions module loaded');

// اگر در محیط توسعه هستیم، دیباگ رو نمایش بده
if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
    console.log('🔧 Debug mode enabled');
    window.Permissions.debug();
}