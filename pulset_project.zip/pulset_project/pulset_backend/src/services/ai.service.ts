import axios from 'axios';
import logger from '../utils/logger';

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const DEEPSEEK_API_KEY = process.env.DEEPSEEK_API_KEY;
const XAI_API_KEY = process.env.XAI_API_KEY;

interface SignalResponse {
  type: 'buy' | 'sell' | 'neutral';
  entry: number;
  tp: number;
  sl: number;
  confidence: number;
  analysis: string;
}

export const getQuickSignal = async (symbol: string, name: string, price: number): Promise<SignalResponse> => {
  try {
    const response = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: 'gpt-4-turbo',
        messages: [
          {
            role: 'system',
            content: `تو یک تحلیلگر حرفه‌ای بازارهای مالی با ۱۰ سال تجربه هستی. پاسخ‌هایت باید دقیق، مختصر و کاربردی باشد. برای سیگنال‌ها، حتماً نوع (خرید/فروش)، قیمت ورود، حد سود، حد ضرر و درصد اطمینان را مشخص کن.`,
          },
          { role: 'user', content: `برای ${name} (${symbol}) با قیمت ${price} یک سیگنال خرید یا فروش با حد سود و ضرر مشخص بده.` },
        ],
        temperature: 0.7,
        max_tokens: 500,
      },
      {
        headers: {
          'Authorization': `Bearer ${OPENAI_API_KEY}`,
          'Content-Type': 'application/json',
        },
      }
    );

    const reply = response.data.choices?.[0]?.message?.content || '';
    return parseSignalResponse(reply, price);
  } catch (error) {
    logger.error('AI quick signal error:', error);
    return getFallbackSignal(symbol, name, price);
  }
};

export const getPremiumSignal = async (symbol: string, name: string, price: number, timeframe: string): Promise<SignalResponse> => {
  try {
    const response = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: 'gpt-4-turbo',
        messages: [
          {
            role: 'system',
            content: `تو یک تحلیلگر ارشد بازارهای مالی با ۱۵ سال تجربه هستی. پاسخ‌هایت باید بسیار دقیق، با تحلیل عمیق تکنیکال و فاندامنتال باشد.`,
          },
          {
            role: 'user',
            content: `برای ${name} (${symbol}) با قیمت ${price} و بازه ${timeframe} یک سیگنال حرفه‌ای با تحلیل عمیق، نسبت ریسک/ریوارد دقیق، سطوح کلیدی و استراتژی ورود/خروج ارائه بده.`,
          },
        ],
        temperature: 0.5,
        max_tokens: 800,
      },
      {
        headers: {
          'Authorization': `Bearer ${OPENAI_API_KEY}`,
          'Content-Type': 'application/json',
        },
      }
    );

    const reply = response.data.choices?.[0]?.message?.content || '';
    return parseSignalResponse(reply, price);
  } catch (error) {
    logger.error('AI premium signal error:', error);
    return getFallbackSignal(symbol, name, price);
  }
};

const parseSignalResponse = (reply: string, price: number): SignalResponse => {
  try {
    const type = reply.includes('خرید') ? 'buy' : reply.includes('فروش') ? 'sell' : 'neutral';
    const entry = parseFloat(reply.match(/ورود[:\s]*([\d,]+)/)?.[1]?.replace(/,/g, '') || price);
    const tp = parseFloat(reply.match(/حد سود[:\s]*([\d,]+)/)?.[1]?.replace(/,/g, '') || price * 1.03);
    const sl = parseFloat(reply.match(/حد ضرر[:\s]*([\d,]+)/)?.[1]?.replace(/,/g, '') || price * 0.98);
    const confidence = parseInt(reply.match(/اطمینان[:\s]*(\d+)/)?.[1] || '70');

    return {
      type: type as 'buy' | 'sell' | 'neutral',
      entry,
      tp,
      sl,
      confidence: Math.min(Math.max(confidence, 50), 98),
      analysis: reply,
    };
  } catch (e) {
    return getFallbackSignal('', '', price);
  }
};

const getFallbackSignal = (symbol: string, name: string, price: number): SignalResponse => {
  const isBuy = Math.random() > 0.5;
  return {
    type: isBuy ? 'buy' : 'sell',
    entry: price,
    tp: isBuy ? price * 1.03 : price * 0.97,
    sl: isBuy ? price * 0.98 : price * 1.02,
    confidence: Math.floor(Math.random() * 20 + 70),
    analysis: `تحلیل ${name}: ${isBuy ? 'خرید' : 'فروش'} در قیمت ${price}. این تحلیل بر اساس داده‌های لحظه‌ای بازار تولید شده است.`,
  };
};
⁵5⁵5555⁵x