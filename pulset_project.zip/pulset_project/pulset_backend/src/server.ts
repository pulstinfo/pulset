import app from './app';
import logger from './utils/logger';
import { createServer } from 'http';

const PORT = process.env.PORT || 5000;

const server = createServer(app);

server.listen(PORT, () => {
  logger.info(`🚀 Server is running on port ${PORT} in ${process.env.NODE_ENV} mode`);
});

process.on('SIGTERM', () => {
  logger.info('SIGTERM received, closing server...');
  server.close(() => {
    logger.info('Server closed');
    process.exit(0);
  });
});
