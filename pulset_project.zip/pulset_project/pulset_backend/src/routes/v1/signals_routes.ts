import express from 'express';
import {
  getSignals,
  createPublicSignal,
  createMarketSignal,
  purchaseSignal,
  updateSignal,
  likeSignal,
  bookmarkSignal,
} from '../../controllers/signals.controller';
import { authenticate } from '../../middlewares/auth.middleware';

const router = express.Router();

router.get('/', authenticate, getSignals);
router.post('/', authenticate, createPublicSignal);
router.post('/market', authenticate, createMarketSignal);
router.post('/:id/purchase', authenticate, purchaseSignal);
router.put('/:id', authenticate, updateSignal);
router.post('/:id/like', authenticate, likeSignal);
router.post('/:id/bookmark', authenticate, bookmarkSignal);

export default router;
