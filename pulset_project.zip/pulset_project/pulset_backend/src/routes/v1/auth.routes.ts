import express from 'express';
import { login, register, logout, getMe, refreshToken } from '../../controllers/auth.controller';
import { authenticate } from '../../middlewares/auth.middleware';
import { authLimiter } from '../../middlewares/rate-limit';
import { validate } from '../../middlewares/validation';
import { z } from 'zod';

const router = express.Router();

const loginSchema = z.object({ body: z.object({ email: z.string().email(), password: z.string().min(8) }) });
const registerSchema = z.object({
  body: z.object({
    username: z.string().min(3).max(20).regex(/^[a-zA-Z0-9_]+$/),
    name: z.string().min(1),
    email: z.string().email(),
    phone: z.string().regex(/^09\d{9}$/),
    password: z.string().min(8),
  }),
});

router.post('/login', authLimiter, validate(loginSchema), login);
router.post('/register', authLimiter, validate(registerSchema), register);
router.post('/logout', authenticate, logout);
router.get('/me', authenticate, getMe);
router.post('/refresh', refreshToken);

export default router;
