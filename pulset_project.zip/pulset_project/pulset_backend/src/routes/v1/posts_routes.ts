import express from 'express';
import {
  getPosts,
  createPost,
  updatePost,
  deletePost,
  likePost,
  bookmarkPost,
  getComments,
  addComment,
  repostPost,
  reportPost,
} from '../../controllers/posts.controller';
import { authenticate } from '../../middlewares/auth.middleware';

const router = express.Router();

router.get('/', authenticate, getPosts);
router.post('/', authenticate, createPost);
router.put('/:id', authenticate, updatePost);
router.delete('/:id', authenticate, deletePost);
router.post('/:id/like', authenticate, likePost);
router.post('/:id/bookmark', authenticate, bookmarkPost);
router.get('/:id/comments', authenticate, getComments);
router.post('/:id/comments', authenticate, addComment);
router.post('/:id/repost', authenticate, repostPost);
router.post('/:id/report', authenticate, reportPost);

export default router;
