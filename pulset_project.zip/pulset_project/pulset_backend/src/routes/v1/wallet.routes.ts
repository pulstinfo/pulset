import express from 'express';
import { getWallet, deposit, withdraw, buyStars, sellStars } from '../../controllers/wallet.controller';
import { authenticate } from '../../middlewares/auth.middleware';
import { walletLimiter } from '../../middlewares/rate-limit';
import { validate } from '../../middlewares/validation';
import { z } from 'zod';

const router = express.Router();

const depositSchema = z.object({ body: z.object({ amount: z.number().positive() }) });
const withdrawSchema = z.object({
  body: z.object({ sheba: z.string().min(10), name: z.string().min(1), amount: z.number().positive() }),
});
const starsSchema = z.object({ body: z.object({ stars: z.number().positive() }) });

router.get('/', authenticate, getWallet);
router.post('/deposit', authenticate, walletLimiter, validate(depositSchema), deposit);
router.post('/withdraw', authenticate, walletLimiter, validate(withdrawSchema), withdraw);
router.post('/buy-stars', authenticate, walletLimiter, validate(starsSchema), buyStars);
router.post('/sell-stars', authenticate, walletLimiter, validate(starsSchema), sellStars);

export default router;
