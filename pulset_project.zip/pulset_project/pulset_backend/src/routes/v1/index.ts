import express from 'express';
import authRoutes from './auth.routes';
import walletRoutes from './wallet.routes';
import postsRoutes from './posts.routes';
import signalsRoutes from './signals.routes';
import marketsRoutes from './markets.routes';
import chatRoutes from './chat.routes';
import notificationsRoutes from './notifications.routes';
import profileRoutes from './profile.routes';
import settingsRoutes from './settings.routes';
import supportRoutes from './support.routes';
import shopRoutes from './shop.routes';
import adminRoutes from './admin.routes';

const router = express.Router();

router.use('/auth', authRoutes);
router.use('/wallet', walletRoutes);
router.use('/posts', postsRoutes);
router.use('/signals', signalsRoutes);
router.use('/markets', marketsRoutes);
router.use('/chat', chatRoutes);
router.use('/notifications', notificationsRoutes);
router.use('/profile', profileRoutes);
router.use('/settings', settingsRoutes);
router.use('/support', supportRoutes);
router.use('/shop', shopRoutes);
router.use('/admin', adminRoutes);

export default router;
