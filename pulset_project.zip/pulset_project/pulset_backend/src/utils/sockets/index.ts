import { Server as SocketServer } from 'socket.io';
import { Server as HttpServer } from 'http';
import { verifyAccessToken } from '../utils/jwt';
import logger from '../utils/logger';
import prisma from '../config/database';

export const initSocket = (server: HttpServer) => {
  const io = new SocketServer(server, {
    cors: {
      origin: process.env.FRONTEND_URL || 'http://localhost:3000',
      credentials: true,
    },
    path: '/ws',
  });

  // Middleware احراز هویت Socket
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth.token;
      if (!token) {
        return next(new Error('Authentication error'));
      }
      const decoded = verifyAccessToken(token);
      if (!decoded) {
        return next(new Error('Invalid token'));
      }
      const user = await prisma.user.findUnique({ where: { id: decoded.sub }, select: { id: true } });
      if (!user) {
        return next(new Error('User not found'));
      }
      socket.data.userId = user.id;
      next();
    } catch (err) {
      next(new Error('Authentication error'));
    }
  });

  io.on('connection', (socket) => {
    logger.info(`🔌 User ${socket.data.userId} connected`);

    // 1. چت
    socket.on('join_chat', (chatId) => {
      socket.join(`chat_${chatId}`);
    });
    socket.on('send_message', async (data) => {
      // ذخیره در دیتابیس و پخش به اتاق
      const newMessage = await prisma.message.create({
        data: {
          chatId: data.chatId,
          senderId: socket.data.userId,
          receiverId: data.receiverId,
          text: data.text,
        },
      });
      io.to(`chat_${data.chatId}`).emit('new_message', newMessage);
    });

    // 2. بازار و قیمت‌ها
    socket.on('subscribe_market', (symbol) => {
      socket.join(`market_${symbol}`);
    });
    // تابع برای پخش قیمت‌ها (هر چند ثانیه یک‌بار از Redis یا API خارجی)

    socket.on('disconnect', () => {
      logger.info(`🔌 User ${socket.data.userId} disconnected`);
    });
  });

  return io;
};
