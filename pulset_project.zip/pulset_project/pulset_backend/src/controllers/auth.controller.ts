import { Request, Response } from 'express';
import bcrypt from 'bcrypt';
import prisma from '../config/database';
import { generateTokens, setAuthCookies, clearAuthCookies } from '../utils/jwt';
import logger from '../utils/logger';

export const login = async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    const user = await prisma.user.findUnique({ where: { email }, include: { wallet: true } });
    if (!user) return res.status(401).json({ message: 'Invalid credentials' });

    const isValid = await bcrypt.compare(password, user.passwordHash);
    if (!isValid) return res.status(401).json({ message: 'Invalid credentials' });

    const { accessToken, refreshToken } = generateTokens(user.id, user.role);
    setAuthCookies(res, accessToken, refreshToken);

    const { passwordHash, ...userData } = user;
    res.status(200).json({ message: 'Login successful', user: userData });
  } catch (error) {
    logger.error('Login error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const register = async (req: Request, res: Response) => {
  try {
    const { username, name, email, phone, password } = req.body;

    const existing = await prisma.user.findFirst({
      where: { OR: [{ email }, { username }, { phone }] },
    });
    if (existing) return res.status(409).json({ message: 'User already exists' });

    const passwordHash = await bcrypt.hash(password, parseInt(process.env.BCRYPT_SALT_ROUNDS || '12'));

    const user = await prisma.$transaction(async (tx) => {
      const newUser = await tx.user.create({
        data: { username, displayName: name, email, phone, passwordHash, role: 'user' },
      });
      await tx.wallet.create({ data: { userId: newUser.id, balance: 0, stars: 0 } });
      return newUser;
    });

    const { accessToken, refreshToken } = generateTokens(user.id, user.role);
    setAuthCookies(res, accessToken, refreshToken);

    const { passwordHash: _, ...userData } = user;
    res.status(201).json({ message: 'Registration successful', user: userData });
  } catch (error) {
    logger.error('Register error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const logout = async (req: Request, res: Response) => {
  clearAuthCookies(res);
  res.status(200).json({ message: 'Logged out successfully' });
};

export const getMe = async (req: any, res: Response) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user.id },
      include: { wallet: true, _count: { select: { posts: true, followers: true, following: true } } },
    });
    if (!user) return res.status(404).json({ message: 'User not found' });

    const { passwordHash, ...userData } = user;
    res.status(200).json(userData);
  } catch (error) {
    logger.error('GetMe error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const refreshToken = async (req: Request, res: Response) => {
  try {
    const refreshToken = req.cookies?.refreshToken;
    if (!refreshToken) return res.status(401).json({ message: 'Refresh token not found' });

    const decoded = verifyRefreshToken(refreshToken);
    if (!decoded) return res.status(401).json({ message: 'Invalid refresh token' });

    const user = await prisma.user.findUnique({ where: { id: decoded.sub } });
    if (!user) return res.status(401).json({ message: 'User not found' });

    const { accessToken, refreshToken: newRefreshToken } = generateTokens(user.id, user.role);
    setAuthCookies(res, accessToken, newRefreshToken);

    res.status(200).json({ message: 'Token refreshed' });
  } catch (error) {
    logger.error('Refresh error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};
