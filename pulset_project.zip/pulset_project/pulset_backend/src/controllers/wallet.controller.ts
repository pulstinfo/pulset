import { Request, Response } from 'express';
import prisma from '../config/database';
import logger from '../utils/logger';

export const getWallet = async (req: any, res: Response) => {
  try {
    const wallet = await prisma.wallet.findUnique({ where: { userId: req.user.id } });
    if (!wallet) return res.status(404).json({ message: 'Wallet not found' });

    const transactions = await prisma.transaction.findMany({
      where: { userId: req.user.id },
      orderBy: { createdAt: 'desc' },
      take: 20,
    });

    res.status(200).json({ ...wallet, transactions });
  } catch (error) {
    logger.error('Get wallet error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const deposit = async (req: any, res: Response) => {
  try {
    const { amount } = req.body;
    if (!amount || amount <= 0) return res.status(400).json({ message: 'Invalid amount' });

    const result = await prisma.$transaction(async (tx) => {
      const wallet = await tx.wallet.update({
        where: { userId: req.user.id },
        data: { balance: { increment: amount }, totalIncome: { increment: amount } },
      });
      await tx.transaction.create({
        data: { userId: req.user.id, type: 'deposit', amount, title: 'واریز به کیف پول', status: 'completed' },
      });
      return wallet;
    });

    res.status(200).json({ message: 'Deposit successful', balance: result.balance });
  } catch (error) {
    logger.error('Deposit error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const withdraw = async (req: any, res: Response) => {
  try {
    const { sheba, name, amount } = req.body;
    if (!amount || amount <= 0) return res.status(400).json({ message: 'Invalid amount' });

    const wallet = await prisma.wallet.findUnique({ where: { userId: req.user.id } });
    if (!wallet || wallet.balance < amount) return res.status(400).json({ message: 'Insufficient balance' });

    const result = await prisma.$transaction(async (tx) => {
      const updatedWallet = await tx.wallet.update({
        where: { userId: req.user.id },
        data: { balance: { decrement: amount }, totalExpense: { increment: amount } },
      });
      await tx.transaction.create({
        data: {
          userId: req.user.id,
          type: 'withdraw',
          amount,
          title: `برداشت به حساب ${name}`,
          description: `شماره شبا: ${sheba}`,
          status: 'pending',
        },
      });
      return updatedWallet;
    });

    res.status(200).json({ message: 'Withdrawal request submitted', balance: result.balance });
  } catch (error) {
    logger.error('Withdraw error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const buyStars = async (req: any, res: Response) => {
  try {
    const { stars } = req.body;
    if (!stars || stars <= 0) return res.status(400).json({ message: 'Invalid stars count' });

    const price = stars * 70;
    const wallet = await prisma.wallet.findUnique({ where: { userId: req.user.id } });
    if (!wallet || wallet.balance < price) return res.status(400).json({ message: 'Insufficient balance' });

    const result = await prisma.$transaction(async (tx) => {
      const updatedWallet = await tx.wallet.update({
        where: { userId: req.user.id },
        data: { balance: { decrement: price }, stars: { increment: stars }, totalExpense: { increment: price } },
      });
      await tx.transaction.create({
        data: {
          userId: req.user.id,
          type: 'star_buy',
          amount: price,
          starsAmount: stars,
          title: `خرید ${stars} ستاره`,
          status: 'completed',
        },
      });
      return updatedWallet;
    });

    res.status(200).json({ message: 'Stars purchased', stars: result.stars, balance: result.balance });
  } catch (error) {
    logger.error('Buy stars error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const sellStars = async (req: any, res: Response) => {
  try {
    const { stars } = req.body;
    if (!stars || stars <= 0) return res.status(400).json({ message: 'Invalid stars count' });

    const wallet = await prisma.wallet.findUnique({ where: { userId: req.user.id } });
    if (!wallet || wallet.stars < stars) return res.status(400).json({ message: 'Insufficient stars' });

    const price = stars * 70;
    const result = await prisma.$transaction(async (tx) => {
      const updatedWallet = await tx.wallet.update({
        where: { userId: req.user.id },
        data: { stars: { decrement: stars }, balance: { increment: price }, totalIncome: { increment: price } },
      });
      await tx.transaction.create({
        data: {
          userId: req.user.id,
          type: 'star_sell',
          amount: price,
          starsAmount: stars,
          title: `فروش ${stars} ستاره`,
          status: 'completed',
        },
      });
      return updatedWallet;
    });

    res.status(200).json({ message: 'Stars sold', stars: result.stars, balance: result.balance });
  } catch (error) {
    logger.error('Sell stars error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};
