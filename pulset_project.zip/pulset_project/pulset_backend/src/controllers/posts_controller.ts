import { Request, Response } from 'express';
import prisma from '../config/database';
import logger from '../utils/logger';

export const getPosts = async (req: any, res: Response) => {
  try {
    const { tab = 'for-you', page = 1, limit = 10 } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);

    const where: any = { privacy: 'public' };
    if (tab === 'following' && req.user) {
      const following = await prisma.follow.findMany({
        where: { followerId: req.user.id },
        select: { followingId: true },
      });
      where.userId = { in: following.map(f => f.followingId) };
    }

    const posts = await prisma.post.findMany({
      where,
      include: {
        user: { select: { id: true, displayName: true, username: true, avatar: true, verified: true } },
        _count: { select: { likes: true, comments: true } },
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take: parseInt(limit),
    });

    const total = await prisma.post.count({ where });

    res.status(200).json({ posts, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (error) {
    logger.error('Get posts error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const createPost = async (req: any, res: Response) => {
  try {
    const { content, privacy, type, tags, taggedUsers, location, media, disableComments, hideLikes, hideReposts } = req.body;

    const post = await prisma.post.create({
      data: {
        userId: req.user.id,
        content,
        privacy: privacy || 'public',
        type: type || 'post',
        tags: tags || [],
        taggedUsers: taggedUsers || [],
        location,
        media,
        disableComments: disableComments || false,
        hideLikes: hideLikes || false,
        hideReposts: hideReposts || false,
      },
      include: {
        user: { select: { id: true, displayName: true, username: true, avatar: true, verified: true } },
      },
    });

    // ارسال نوتیفیکیشن به کاربران تگ شده
    if (taggedUsers && taggedUsers.length) {
      // await sendNotifications(taggedUsers, 'tag', post.id);
    }

    res.status(201).json(post);
  } catch (error) {
    logger.error('Create post error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const updatePost = async (req: any, res: Response) => {
  try {
    const { id } = req.params;
    const post = await prisma.post.findUnique({ where: { id } });
    if (!post) return res.status(404).json({ message: 'Post not found' });
    if (post.userId !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Forbidden' });
    }

    const updated = await prisma.post.update({
      where: { id },
      data: req.body,
      include: {
        user: { select: { id: true, displayName: true, username: true, avatar: true, verified: true } },
      },
    });

    res.status(200).json(updated);
  } catch (error) {
    logger.error('Update post error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const deletePost = async (req: any, res: Response) => {
  try {
    const { id } = req.params;
    const post = await prisma.post.findUnique({ where: { id } });
    if (!post) return res.status(404).json({ message: 'Post not found' });
    if (post.userId !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Forbidden' });
    }

    await prisma.post.delete({ where: { id } });
    res.status(200).json({ message: 'Post deleted' });
  } catch (error) {
    logger.error('Delete post error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const likePost = async (req: any, res: Response) => {
  try {
    const { id } = req.params;
    const existing = await prisma.like.findUnique({
      where: { userId_postId: { userId: req.user.id, postId: id } },
    });

    if (existing) {
      await prisma.like.delete({ where: { id: existing.id } });
      await prisma.post.update({ where: { id }, data: { likesCount: { decrement: 1 } } });
      return res.status(200).json({ liked: false, likes: (await prisma.post.findUnique({ where: { id } }))?.likesCount });
    }

    await prisma.like.create({ data: { userId: req.user.id, postId: id } });
    await prisma.post.update({ where: { id }, data: { likesCount: { increment: 1 } } });
    const post = await prisma.post.findUnique({ where: { id } });

    res.status(200).json({ liked: true, likes: post?.likesCount });
  } catch (error) {
    logger.error('Like post error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const bookmarkPost = async (req: any, res: Response) => {
  try {
    const { id } = req.params;
    const existing = await prisma.bookmark.findUnique({
      where: { userId_postId: { userId: req.user.id, postId: id } },
    });

    if (existing) {
      await prisma.bookmark.delete({ where: { id: existing.id } });
      return res.status(200).json({ saved: false });
    }

    await prisma.bookmark.create({ data: { userId: req.user.id, postId: id } });
    res.status(200).json({ saved: true });
  } catch (error) {
    logger.error('Bookmark post error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const getComments = async (req: any, res: Response) => {
  try {
    const { id } = req.params;
    const comments = await prisma.comment.findMany({
      where: { postId: id, parentId: null },
      include: {
        user: { select: { id: true, displayName: true, avatar: true } },
        replies: {
          include: { user: { select: { id: true, displayName: true, avatar: true } } },
        },
      },
      orderBy: { createdAt: 'asc' },
    });

    res.status(200).json(comments);
  } catch (error) {
    logger.error('Get comments error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const addComment = async (req: any, res: Response) => {
  try {
    const { id } = req.params;
    const { text, parentId } = req.body;

    const comment = await prisma.comment.create({
      data: {
        userId: req.user.id,
        postId: id,
        text,
        parentId: parentId || null,
      },
      include: {
        user: { select: { id: true, displayName: true, avatar: true } },
      },
    });

    await prisma.post.update({ where: { id }, data: { commentsCount: { increment: 1 } } });

    res.status(201).json(comment);
  } catch (error) {
    logger.error('Add comment error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const repostPost = async (req: any, res: Response) => {
  try {
    const { id } = req.params;
    const { type = 'instant' } = req.body;

    const original = await prisma.post.findUnique({ where: { id } });
    if (!original) return res.status(404).json({ message: 'Post not found' });

    const repost = await prisma.post.create({
      data: {
        userId: req.user.id,
        content: type === 'quote' ? req.body.text || '' : '',
        type: type === 'quote' ? 'quote' : 'post',
        repostedFromId: id,
        privacy: 'public',
      },
      include: {
        user: { select: { id: true, displayName: true, username: true, avatar: true, verified: true } },
      },
    });

    await prisma.post.update({ where: { id }, data: { repostsCount: { increment: 1 } } });

    res.status(201).json(repost);
  } catch (error) {
    logger.error('Repost error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const reportPost = async (req: any, res: Response) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;

    // ذخیره گزارش در دیتابیس (جدول Reports نیاز است)
    // فعلاً فقط لاگ می‌کنیم
    logger.warn(`Post ${id} reported by user ${req.user.id}: ${reason}`);

    res.status(200).json({ message: 'Report submitted' });
  } catch (error) {
    logger.error('Report error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};
