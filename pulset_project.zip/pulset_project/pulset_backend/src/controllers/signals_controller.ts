import { Request, Response } from 'express';
import prisma from '../config/database';
import logger from '../utils/logger';
import { getAISignal } from '../services/ai.service';

export const getSignals = async (req: any, res: Response) => {
  try {
    const { tab = 'public', page = 1, limit = 10 } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);

    const where: any = {};
    if (tab === 'public') where.isMarket = false;
    else if (tab === 'market') where.isMarket = true;

    const signals = await prisma.signal.findMany({
      where,
      include: {
        user: { select: { id: true, displayName: true, username: true, avatar: true, verified: true } },
        _count: { select: { likes: true, comments: true } },
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take: parseInt(limit),
    });

    // اگر سیگنال بازار است و کاربر خرید نکرده، اطلاعات حساس رو مخفی کن
    const processed = signals.map(s => {
      if (s.isMarket && !s.isPurchased && s.userId !== req.user?.id) {
        return { ...s, entry: '🔒', tp: '🔒', sl: '🔒' };
      }
      return s;
    });

    const total = await prisma.signal.count({ where });

    res.status(200).json({ signals: processed, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (error) {
    logger.error('Get signals error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const createPublicSignal = async (req: any, res: Response) => {
  try {
    const { coin, type, entry, tp, sl, confidence, desc } = req.body;

    const signal = await prisma.signal.create({
      data: {
        userId: req.user.id,
        coin,
        type,
        entry,
        tp,
        sl,
        confidence: confidence || 70,
        desc,
        isMarket: false,
        isAI: false,
      },
      include: {
        user: { select: { id: true, displayName: true, username: true, avatar: true, verified: true } },
      },
    });

    res.status(201).json(signal);
  } catch (error) {
    logger.error('Create public signal error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const createMarketSignal = async (req: any, res: Response) => {
  try {
    const { coin, type, entry, tp, sl, price, desc } = req.body;

    // بررسی موجودی کیف پول برای کارمزد
    const wallet = await prisma.wallet.findUnique({ where: { userId: req.user.id } });
    const fee = 10000; // کارمزد ثابت
    if (!wallet || wallet.balance < fee) {
      return res.status(400).json({ message: 'Insufficient balance for listing fee' });
    }

    const signal = await prisma.$transaction(async (tx) => {
      // کسر کارمزد
      await tx.wallet.update({
        where: { userId: req.user.id },
        data: { balance: { decrement: fee } },
      });

      // ایجاد سیگنال
      const newSignal = await tx.signal.create({
        data: {
          userId: req.user.id,
          coin,
          type,
          entry,
          tp,
          sl,
          price,
          desc,
          isMarket: true,
          isAI: false,
        },
        include: {
          user: { select: { id: true, displayName: true, username: true, avatar: true, verified: true } },
        },
      });

      return newSignal;
    });

    res.status(201).json(signal);
  } catch (error) {
    logger.error('Create market signal error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const purchaseSignal = async (req: any, res: Response) => {
  try {
    const { id } = req.params;
    const signal = await prisma.signal.findUnique({ where: { id } });
    if (!signal) return res.status(404).json({ message: 'Signal not found' });
    if (!signal.isMarket) return res.status(400).json({ message: 'Not a market signal' });
    if (signal.isPurchased) return res.status(400).json({ message: 'Already purchased' });
    if (signal.userId === req.user.id) return res.status(400).json({ message: 'You cannot buy your own signal' });

    const wallet = await prisma.wallet.findUnique({ where: { userId: req.user.id } });
    if (!wallet || wallet.balance < (signal.price || 0)) {
      return res.status(400).json({ message: 'Insufficient balance' });
    }

    const result = await prisma.$transaction(async (tx) => {
      // کسر از خریدار
      await tx.wallet.update({
        where: { userId: req.user.id },
        data: { balance: { decrement: signal.price || 0 }, totalExpense: { increment: signal.price || 0 } },
      });

      // افزودن به فروشنده
      await tx.wallet.update({
        where: { userId: signal.userId },
        data: { balance: { increment: signal.price || 0 }, totalIncome: { increment: signal.price || 0 } },
      });

      // ثبت تراکنش‌ها
      await tx.transaction.create({
        data: {
          userId: req.user.id,
          type: 'expense',
          amount: signal.price || 0,
          title: `خرید سیگنال ${signal.coin}`,
          status: 'completed',
        },
      });
      await tx.transaction.create({
        data: {
          userId: signal.userId,
          type: 'income',
          amount: signal.price || 0,
          title: `فروش سیگنال ${signal.coin}`,
          status: 'completed',
        },
      });

      // به‌روزرسانی سیگنال
      const updated = await tx.signal.update({
        where: { id },
        data: { isPurchased: true },
      });

      return updated;
    });

    res.status(200).json({ message: 'Signal purchased successfully', signal: result });
  } catch (error) {
    logger.error('Purchase signal error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const updateSignal = async (req: any, res: Response) => {
  try {
    const { id } = req.params;
    const signal = await prisma.signal.findUnique({ where: { id } });
    if (!signal) return res.status(404).json({ message: 'Signal not found' });
    if (signal.userId !== req.user.id) return res.status(403).json({ message: 'Forbidden' });

    const updated = await prisma.signal.update({
      where: { id },
      data: req.body,
      include: {
        user: { select: { id: true, displayName: true, username: true, avatar: true, verified: true } },
      },
    });

    res.status(200).json(updated);
  } catch (error) {
    logger.error('Update signal error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const likeSignal = async (req: any, res: Response) => {
  try {
    const { id } = req.params;
    const existing = await prisma.like.findUnique({
      where: { userId_signalId: { userId: req.user.id, signalId: id } },
    });

    if (existing) {
      await prisma.like.delete({ where: { id: existing.id } });
      await prisma.signal.update({ where: { id }, data: { likesCount: { decrement: 1 } } });
      const signal = await prisma.signal.findUnique({ where: { id } });
      return res.status(200).json({ liked: false, likes: signal?.likesCount });
    }

    await prisma.like.create({ data: { userId: req.user.id, signalId: id } });
    await prisma.signal.update({ where: { id }, data: { likesCount: { increment: 1 } } });
    const signal = await prisma.signal.findUnique({ where: { id } });

    res.status(200).json({ liked: true, likes: signal?.likesCount });
  } catch (error) {
    logger.error('Like signal error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const bookmarkSignal = async (req: any, res: Response) => {
  try {
    const { id } = req.params;
    const existing = await prisma.bookmark.findUnique({
      where: { userId_signalId: { userId: req.user.id, signalId: id } },
    });

    if (existing) {
      await prisma.bookmark.delete({ where: { id: existing.id } });
      return res.status(200).json({ saved: false });
    }

    await prisma.bookmark.create({ data: { userId: req.user.id, signalId: id } });
    res.status(200).json({ saved: true });
  } catch (error) {
    logger.error('Bookmark signal error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};
